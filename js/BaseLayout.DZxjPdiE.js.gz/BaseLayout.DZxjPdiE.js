import { c as createAstro, a as createComponent, m as maybeRenderHead, e as addAttribute, d as renderTemplate, r as renderComponent, g as renderSlot, k as renderHead, b as renderScript, s as spreadAttributes, u as unescapeHTML } from "./astro/server.CiUvenb_.js";
/* empty css                         */
import "kleur/colors";
import "clsx";
const $$Astro$3 = createAstro("https://findforce.io");
const $$LogoIcon = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$LogoIcon;
  var { class: className = "" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<svg${addAttribute(className, "class")} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg"> <rect width="40" height="40" rx="10" fill="url(#gradient)"></rect> <text x="50%" y="50%" text-anchor="middle" dominant-baseline="central" fill="white" font-weight="bold" font-size="18" font-family="system-ui, sans-serif">
@
</text> <defs> <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%"> <stop offset="0%" stop-color="#3b82f6"></stop> <stop offset="100%" stop-color="#2563eb"></stop> </linearGradient> </defs> </svg>`;
}, "/home/runner/work/landing-page/landing-page/src/components/LogoIcon.astro", void 0);
const $$Astro$2 = createAstro("https://findforce.io");
const $$Logo = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$Logo;
  var { size = "md", href = "/", clickable = true } = Astro2.props;
  var sizeClasses = {
    sm: "text-lg gap-2",
    md: "text-xl gap-2",
    lg: "text-2xl gap-3"
  };
  var iconSizes = {
    sm: "w-8 h-8",
    md: "w-10 h-10",
    lg: "w-12 h-12"
  };
  return renderTemplate`${clickable ? renderTemplate`${maybeRenderHead()}<a${addAttribute(href, "href")}${addAttribute(`inline-flex items-center font-bold text-gray-900 no-underline transition-opacity duration-200 ease-in-out hover:opacity-80 ${sizeClasses[size]}`, "class")}>${renderComponent($$result, "LogoIcon", $$LogoIcon, { "class": iconSizes[size] })}<span>FindForce</span></a>` : renderTemplate`<div${addAttribute(`inline-flex items-center font-bold text-gray-900 ${sizeClasses[size]}`, "class")}>${renderComponent($$result, "LogoIcon", $$LogoIcon, { "class": iconSizes[size] })}<span>FindForce</span></div>`}`;
}, "/home/runner/work/landing-page/landing-page/src/components/Logo.astro", void 0);
var __freeze$1 = Object.freeze;
var __defProp$1 = Object.defineProperty;
var __template$1 = (cooked, raw) => __freeze$1(__defProp$1(cooked, "raw", { value: __freeze$1(cooked.slice()) }));
var _a$1;
const $$Astro$1 = createAstro("https://findforce.io");
const $$Header = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$Header;
  return renderTemplate(_a$1 || (_a$1 = __template$1(["", '<header role="banner" style="\n    background: #fff;\n    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);\n    position: sticky;\n    top: 0;\n    z-index: 100;\n  " data-astro-cid-3ef6ksr2> <div class="container" data-astro-cid-3ef6ksr2> <div class="header-content" data-astro-cid-3ef6ksr2> <div class="logo-section" data-astro-cid-3ef6ksr2> <a href="/" style="text-decoration: none; display: flex; align-items: center" aria-label="FindForce Home" data-astro-cid-3ef6ksr2> ', ' </a> </div> <nav aria-label="Primary Navigation" class="desktop-nav" data-astro-cid-3ef6ksr2> <a href="/#pricing" style="\n            color: #4b5563;\n            text-decoration: none;\n            font-weight: 500;\n            font-size: 14px;\n          " data-astro-cid-3ef6ksr2>Pricing</a> <a href="/compare" style="\n            color: #4b5563;\n            text-decoration: none;\n            font-weight: 500;\n            font-size: 14px;\n          " data-astro-cid-3ef6ksr2>Comparison</a> <a href="/#faq-heading" style="\n            color: #4b5563;\n            text-decoration: none;\n            font-weight: 500;\n            font-size: 14px;\n          " data-astro-cid-3ef6ksr2>FAQ</a> <a href="/blog" style="\n            color: #4b5563;\n            text-decoration: none;\n            font-weight: 500;\n            font-size: 14px;\n          " data-astro-cid-3ef6ksr2>Blog</a> <a href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=web&utm_campaign=header&utm_content=install_extension" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="header_desktop"', ' data-pirsch-non-interactive class="btn-primary" style="font-size: 12px; padding: 8px 16px" target="_blank" rel="noopener" data-astro-cid-3ef6ksr2>\nInstall Extension →\n</a> </nav> <button class="hamburger" id="hamburger-btn" aria-label="Toggle mobile menu" aria-expanded="false" data-astro-cid-3ef6ksr2> <span data-astro-cid-3ef6ksr2></span> <span data-astro-cid-3ef6ksr2></span> <span data-astro-cid-3ef6ksr2></span> </button> </div> </div> <div class="mobile-menu" id="mobileMenu" data-astro-cid-3ef6ksr2> <div style="display: flex; flex-direction: column; gap: 20px" data-astro-cid-3ef6ksr2> <a href="#faq-heading" style="\n          color: #1a1a1a;\n          text-decoration: none;\n          font-weight: 500;\n          padding: 15px 0;\n          border-bottom: 1px solid #e5e7eb;\n          font-size: 16px;\n        " class="mobile-link" data-astro-cid-3ef6ksr2>FAQ</a> <a href="#pricing" style="\n          color: #1a1a1a;\n          text-decoration: none;\n          font-weight: 500;\n          padding: 15px 0;\n          border-bottom: 1px solid #e5e7eb;\n          font-size: 16px;\n        " class="mobile-link" data-astro-cid-3ef6ksr2>Pricing</a> <a href="/blog" style="\n          color: #1a1a1a;\n          text-decoration: none;\n          font-weight: 500;\n          padding: 15px 0;\n          border-bottom: 1px solid #e5e7eb;\n          font-size: 16px;\n        " class="mobile-link" data-astro-cid-3ef6ksr2>Blog</a> <a href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=mobile_web&utm_campaign=header&utm_content=install_extension" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="header_mobile"', ' data-pirsch-non-interactive class="btn-primary" style="margin-top: 10px; font-size: 16px; padding: 14px 20px" target="_blank" rel="noopener" data-astro-cid-3ef6ksr2>\nInstall Extension →\n</a> </div> </div> </header> <script type="module">\n  function initializeHeader() {\n    var menu = document.getElementById("mobileMenu");\n    var hamburger = document.getElementById("hamburger-btn");\n    var mobileLinks = document.querySelectorAll(".mobile-link");\n\n    if (!menu || !hamburger) {\n      return;\n    }\n\n    function toggleMobileMenu() {\n      var isActive = menu.classList.contains("active");\n      menu.classList.toggle("active");\n      hamburger.classList.toggle("active");\n      hamburger.setAttribute("aria-expanded", (!isActive).toString());\n    }\n\n    function closeMobileMenu() {\n      menu.classList.remove("active");\n      hamburger.classList.remove("active");\n      hamburger.setAttribute("aria-expanded", "false");\n    }\n\n    hamburger.addEventListener("click", toggleMobileMenu, { passive: true });\n\n    mobileLinks.forEach(function addListener(link) {\n      link.addEventListener("click", closeMobileMenu, { passive: true });\n    });\n\n    document.addEventListener(\n      "click",\n      function handleOutsideClick(event) {\n        var isClickInsideMenu = menu.contains(event.target);\n        var isClickOnHamburger = hamburger.contains(event.target);\n\n        if (\n          !isClickInsideMenu &&\n          !isClickOnHamburger &&\n          menu.classList.contains("active")\n        ) {\n          closeMobileMenu();\n        }\n      },\n      { passive: true }\n    );\n  }\n\n  if (document.readyState === "loading") {\n    document.addEventListener("DOMContentLoaded", initializeHeader);\n  } else {\n    initializeHeader();\n  }\n<\/script> '])), maybeRenderHead(), renderComponent($$result, "Logo", $$Logo, { "size": "md", "data-astro-cid-3ef6ksr2": true }), addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url"), addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url"));
}, "/home/runner/work/landing-page/landing-page/src/components/Header.astro", void 0);
const $$Footer = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<footer class="footer" data-astro-cid-sz7xmlte> <div class="container" data-astro-cid-sz7xmlte> <p class="copyright" data-astro-cid-sz7xmlte>
© FindForce by Developer Friendly OÜ. All rights reserved.
<span class="flag" data-astro-cid-sz7xmlte>🇪🇪</span> </p> <div class="footer-links" data-astro-cid-sz7xmlte> <div class="footer-column" data-astro-cid-sz7xmlte> <h4 class="column-title" data-astro-cid-sz7xmlte>Legal & Policies</h4> <a href="/terms" class="footer-link" data-astro-cid-sz7xmlte>Terms</a> <a href="/privacy" class="footer-link" data-astro-cid-sz7xmlte>Privacy</a> <a href="/dpa" class="footer-link" data-astro-cid-sz7xmlte>Data Processing Agreement</a> <a href="/cookie-policy" class="footer-link" data-astro-cid-sz7xmlte>Cookie Policy</a> <a href="/security" class="footer-link" data-astro-cid-sz7xmlte>Security</a> </div> <div class="footer-column" data-astro-cid-sz7xmlte> <h4 class="column-title" data-astro-cid-sz7xmlte>Comparisons</h4> <a href="/compare/findforce-vs-apollo" class="footer-link" data-astro-cid-sz7xmlte>FindForce vs Apollo.io</a> <a href="/compare/findforce-vs-hunter" class="footer-link" data-astro-cid-sz7xmlte>FindForce vs Hunter.io</a> <a href="/compare/findforce-vs-lusha" class="footer-link" data-astro-cid-sz7xmlte>FindForce vs Lusha</a> <a href="/compare/findforce-vs-snov" class="footer-link" data-astro-cid-sz7xmlte>FindForce vs Snov.io</a> <a href="/compare/findforce-vs-rocketreach" class="footer-link" data-astro-cid-sz7xmlte>FindForce vs RocketReach</a> <a href="/compare/findforce-vs-clearbit" class="footer-link" data-astro-cid-sz7xmlte>FindForce vs Clearbit</a> </div> <div class="footer-column" data-astro-cid-sz7xmlte> <h4 class="column-title" data-astro-cid-sz7xmlte>Free Resources</h4> <a href="/complete-gdpr-compliant-guide" class="footer-link" data-astro-cid-sz7xmlte>Complete GDPR Email Finding Guide 2025</a> <a href="/roi-calculator" class="footer-link" data-astro-cid-sz7xmlte>Sales Productivity ROI Calculator</a> <a href="/benchmark-report" class="footer-link" data-astro-cid-sz7xmlte>Sales Productivity Benchmark Report</a> <a href="/download-gdpr-checklist" class="footer-link" data-astro-cid-sz7xmlte>Download GDPR Checklist</a> </div> <div class="footer-column" data-astro-cid-sz7xmlte> <h4 class="column-title" data-astro-cid-sz7xmlte>Connect</h4> <a href="mailto:contact@findforce.io" class="footer-link" data-astro-cid-sz7xmlte>contact@findforce.io</a> <a href="/blog" class="footer-link" data-astro-cid-sz7xmlte>Blog</a> <a href="/changelog" class="footer-link" data-astro-cid-sz7xmlte>Changelog</a> <a href="/rss.xml" class="footer-link" type="application/rss+xml" data-astro-cid-sz7xmlte>RSS Feed</a> <a href="https://www.youtube.com/@findforce" class="footer-link" rel="noopener" target="_blank" data-astro-cid-sz7xmlte>YouTube</a> <a href="https://blog.findforce.io" class="footer-link" rel="noopener" target="_blank" data-astro-cid-sz7xmlte>Medium</a> <a href="https://x.com/findforce" class="footer-link" rel="noopener" target="_blank" data-astro-cid-sz7xmlte>X</a> <a href="http://linkedin.com/company/findforce" class="footer-link" rel="noopener" target="_blank" data-astro-cid-sz7xmlte>LinkedIn</a> </div> </div> </div> </footer> `;
}, "/home/runner/work/landing-page/landing-page/src/components/Footer.astro", void 0);
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://findforce.io");
const $$BaseLayout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$BaseLayout;
  var {
    title = "FindForce - Verified Business Emails with 95% Accuracy Guarantee",
    description = "Find and verify business emails in seconds with 95% accuracy guarantee. Unlimited verifications, flat rate pricing. No credits, no limits.",
    keywords = "email finder, email verification, sales prospecting, business email finder, GDPR compliant email finder",
    ogImage = "https://findforce.io/og-image.png",
    ogTitle,
    ogDescription,
    twitterCard = "summary_large_image",
    twitterTitle,
    twitterDescription,
    twitterImage,
    twitterImageAlt = "FindForce - Email finder Chrome extension preview",
    canonical = "https://findforce.io/",
    noindex = false,
    additionalMeta = [],
    structuredData
  } = Astro2.props;
  var finalOgTitle = ogTitle || title;
  var finalOgDescription = ogDescription || description;
  var finalTwitterTitle = twitterTitle || title;
  var finalTwitterDescription = twitterDescription || description;
  var finalTwitterImage = twitterImage || ogImage;
  return renderTemplate`<html lang="en" data-astro-cid-37fxchfa> <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>${title}</title><link rel="dns-prefetch" href="//chromewebstore.google.com"><link rel="dns-prefetch" href="//analytics.findforce.io"><link rel="preconnect" href="https://analytics.findforce.io" crossorigin><meta name="description"${addAttribute(description, "content")}><meta name="keywords"${addAttribute(keywords, "content")}><meta name="robots"${addAttribute(noindex ? "noindex, nofollow" : "index, follow", "content")}><link rel="canonical"${addAttribute(canonical || Astro2.url.href, "href")}><link rel="sitemap" href="/sitemap-index.xml"><link rel="alternate" type="application/rss+xml" title="FindForce RSS Feed" href="/rss.xml"><meta property="og:title"${addAttribute(finalOgTitle, "content")}><meta property="og:description"${addAttribute(finalOgDescription, "content")}><meta property="og:image"${addAttribute(ogImage, "content")}><meta property="og:image:width" content="1200"><meta property="og:image:height" content="630"><meta property="og:type" content="website"><meta property="og:url"${addAttribute(Astro2.url.href, "content")}><meta property="og:site_name" content="FindForce"><meta name="twitter:card"${addAttribute(twitterCard, "content")}><meta name="twitter:title"${addAttribute(finalTwitterTitle, "content")}><meta name="twitter:description"${addAttribute(finalTwitterDescription, "content")}><meta name="twitter:image"${addAttribute(finalTwitterImage, "content")}><meta name="twitter:image:alt"${addAttribute(twitterImageAlt, "content")}><meta name="twitter:site" content="@findforce"><meta name="twitter:creator" content="@findforce">${additionalMeta.map(function renderMeta(meta) {
    return renderTemplate`<meta${spreadAttributes(meta, void 0, { "class": "astro-37fxchfa" })}>`;
  })}<link rel="icon" type="image/x-icon" href="/favicon.ico"><link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png"><link rel="manifest" href="/site.webmanifest"><meta name="theme-color" content="#2563eb"><meta name="msapplication-TileColor" content="#2563eb">${structuredData && renderTemplate(_a || (_a = __template(['<script type="application/ld+json">', "<\/script>"])), unescapeHTML(JSON.stringify(structuredData)))}${renderSlot($$result, $$slots["head"])}${renderHead()}</head> <body data-astro-cid-37fxchfa> <div class="page-wrapper" data-astro-cid-37fxchfa> ${renderComponent($$result, "Header", $$Header, { "data-astro-cid-37fxchfa": true })} <main class="main-content" role="main" id="main-content" data-astro-cid-37fxchfa> ${renderSlot($$result, $$slots["default"])} </main> ${renderComponent($$result, "Footer", $$Footer, { "data-astro-cid-37fxchfa": true })} </div> ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/layouts/BaseLayout.astro?astro&type=script&index=0&lang.ts")} ${renderSlot($$result, $$slots["scripts"])} </body></html>`;
}, "/home/runner/work/landing-page/landing-page/src/layouts/BaseLayout.astro", void 0);
export {
  $$BaseLayout as $,
  $$Logo as a
};
