import { c as createAstro, a as createComponent, d as renderTemplate, e as addAttribute, r as renderComponent, m as maybeRenderHead } from "./astro/server.CiUvenb_.js";
import "kleur/colors";
/* empty css                                         */
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://findforce.io");
const $$Newsletter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$Newsletter;
  var {
    title = "Get weekly email deliverability tips",
    subtitle = "Join 2,000+ sales professionals improving their email performance.",
    variant = "default",
    source = "newsletter",
    buttonText = "Subscribe Free",
    colorScheme = "blue",
    className = ""
  } = Astro2.props;
  var gradientMap = {
    blue: "linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)",
    green: "linear-gradient(135deg, #10b981 0%, #059669 100%)",
    purple: "linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%)",
    orange: "linear-gradient(135deg, #f59e0b 0%, #d97706 100%)"
  };
  var buttonColorMap = {
    blue: "#1d4ed8",
    green: "#059669",
    purple: "#7c3aed",
    orange: "#d97706"
  };
  var gradient = gradientMap[colorScheme];
  var buttonColor = buttonColorMap[colorScheme];
  return renderTemplate(_a || (_a = __template(["", "<div", "", "", " data-astro-cid-motrwrji> <h3 data-astro-cid-motrwrji>", "</h3> <p data-astro-cid-motrwrji>", '</p> <form class="newsletter-form listmonk-form" data-pirsch-event="subscribe"', "", "", ' data-pirsch-non-interactive action="https://newsletter.meysam.io/subscription/form" method="post" data-astro-cid-motrwrji> <input type="hidden" name="nonce" data-astro-cid-motrwrji> <input id="00a2c" type="hidden" name="l" value="af1061e5-e92f-4e04-a852-44b2a71864fc" data-astro-cid-motrwrji> <input type="text" name="name" value="" class="honeypot-field" tabindex="-1" autocomplete="off" aria-hidden="true" data-astro-cid-motrwrji> <input type="text" name="company" value="" class="honeypot-field" tabindex="-1" autocomplete="off" aria-hidden="true" data-astro-cid-motrwrji> <input type="text" name="website" value="" class="honeypot-field" tabindex="-1" autocomplete="off" aria-hidden="true" data-astro-cid-motrwrji> <div class="form-group" data-astro-cid-motrwrji> <input type="email" name="email" placeholder="your@email.com" required aria-label="Email address" class="email-input" data-astro-cid-motrwrji> </div> ', ' <button type="submit" class="btn btn-primary submit-button"', ' data-astro-cid-motrwrji> <span class="button-text" data-astro-cid-motrwrji>', `</span> <span class="button-loader hidden" data-astro-cid-motrwrji> <svg class="spinner" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" data-astro-cid-motrwrji> <path d="M21 12a9 9 0 1 1-6.219-8.56" data-astro-cid-motrwrji></path> </svg>
Subscribing...
</span> </button> <p class="form-note" data-astro-cid-motrwrji>No spam. Unsubscribe anytime. Privacy respected.</p> </form> <div class="success-message hidden" data-astro-cid-motrwrji> <div class="success-icon" data-astro-cid-motrwrji> <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-motrwrji> <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" data-astro-cid-motrwrji></path> <polyline points="22 4 12 14.01 9 11.01" data-astro-cid-motrwrji></polyline> </svg> </div> <h4 data-astro-cid-motrwrji>You're all set!</h4> <p data-astro-cid-motrwrji>Thanks for subscribing. You'll receive our best tips and insights directly in your inbox.</p> </div> </div> <script type="module" src="https://newsletter.meysam.io/public/static/altcha.umd.js" async defer><\/script> <script>
  document.addEventListener("DOMContentLoaded", function initNewsletterForms() {
    document.querySelectorAll(".newsletter-form").forEach(function setupForm(form) {
      form.addEventListener("submit", function handleSubmit(e) {
        var submitBtn = form.querySelector(".submit-button");
        var buttonText = form.querySelector(".button-text");
        var buttonLoader = form.querySelector(".button-loader");
        var successMessage = form.closest(".newsletter-section").querySelector(".success-message");

        buttonText.classList.add("hidden");
        buttonLoader.classList.remove("hidden");
        submitBtn.disabled = true;

        var formData = new FormData(form);

        fetch(form.action, {
          method: "POST",
          body: formData,
        })
          .then(function handleResponse(response) {
            if (response.ok || response.redirected) {
              form.classList.add("hidden");
              successMessage.classList.remove("hidden");

              if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
                window.pirsch("newsletter_subscribed", {
                  meta: {
                    variant: form.dataset.pirschMetaVariant,
                    source: form.dataset.pirschMetaSource,
                  },
                });
              }
            } else {
              throw new Error("Subscription failed");
            }
          })
          .catch(function handleError(error) {
            buttonText.classList.remove("hidden");
            buttonLoader.classList.add("hidden");
            submitBtn.disabled = false;
            alert("Something went wrong. Please try again.");
          });

        e.preventDefault();
      });
    });
  });
<\/script> `])), maybeRenderHead(), addAttribute(`newsletter-section ${className}`, "class"), addAttribute(`background: ${gradient}`, "style"), addAttribute(variant, "data-variant"), title, subtitle, addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url"), addAttribute(variant, "data-pirsch-meta-variant"), addAttribute(source, "data-pirsch-meta-source"), renderComponent($$result, "altcha-widget", "altcha-widget", { "class": "altcha-widget", "challengeurl": "https://newsletter.meysam.io/api/public/captcha/altcha", "auto": "onfocus", "data-astro-cid-motrwrji": true }), addAttribute(`--button-color: ${buttonColor}`, "style"), buttonText);
}, "/home/runner/work/landing-page/landing-page/src/components/Newsletter.astro", void 0);
export {
  $$Newsletter as $
};
