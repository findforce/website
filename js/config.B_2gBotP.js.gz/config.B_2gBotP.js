var API_URL = "https://api.findforce.io";
var CAP_BASE_URL = "https://cap.findforce.io";
var CAP_SITE_KEY = "05eac8212f";
var FOUNDER_SPOT_REMAINING = 100;
export {
  API_URL as A,
  CAP_BASE_URL as C,
  FOUNDER_SPOT_REMAINING as F,
  CAP_SITE_KEY as a
};
