import { c as createAstro, a as createComponent, r as renderComponent, b as renderScript, d as renderTemplate, F as Fragment, m as maybeRenderHead, e as addAttribute } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { $ as $$BaseLayout, a as $$Logo } from "../js/BaseLayout.Ci_Dh1rG.js";
/* empty css                          */
import { renderers } from "../renderers.mjs";
const $$Astro = createAstro("https://findforce.io");
const $$404 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$404;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "404 - Page Not Found | FindForce.io", "description": "The page you're looking for isn't here, but FindForce's 95% email accuracy guarantee is always available.", "canonical": "https://findforce.io/404", "noindex": true, "data-astro-cid-zetdm5md": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="error-page" data-astro-cid-zetdm5md> <div class="container" data-astro-cid-zetdm5md> <div class="error-content" data-astro-cid-zetdm5md> <div class="error-visual" data-astro-cid-zetdm5md> <div class="error-number" data-astro-cid-zetdm5md>404</div> ${renderComponent($$result2, "Logo", $$Logo, { "data-astro-cid-zetdm5md": true })} </div> <h1 data-astro-cid-zetdm5md>Page Not Found</h1> <div class="error-message" data-astro-cid-zetdm5md> <p class="lead" data-astro-cid-zetdm5md>
This page doesn't exist, but our 95% email accuracy guarantee does.
</p> <p data-astro-cid-zetdm5md>
While you're here, consider this: we built FindForce to compete
            directly with Apollo and Hunter.io — and we're confident enough to <strong data-astro-cid-zetdm5md>guarantee our results</strong>. That's not something you'll find from the established players.
</p> </div> <div class="stats-mini" data-astro-cid-zetdm5md> <div class="stat-item" data-astro-cid-zetdm5md> <div class="stat-value" data-astro-cid-zetdm5md>95%</div> <div class="stat-label" data-astro-cid-zetdm5md>Accuracy Rate</div> </div> <div class="stat-item" data-astro-cid-zetdm5md> <div class="stat-value" data-astro-cid-zetdm5md>2s</div> <div class="stat-label" data-astro-cid-zetdm5md>Find Time</div> </div> <div class="stat-item" data-astro-cid-zetdm5md> <div class="stat-value" data-astro-cid-zetdm5md>100%</div> <div class="stat-label" data-astro-cid-zetdm5md>Guaranteed</div> </div> </div> <div class="error-actions" data-astro-cid-zetdm5md> <a href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=web&utm_campaign=404_page&utm_content=get_findforce" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="404_primary_cta"${addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url")} data-pirsch-non-interactive class="btn-primary" target="_blank" rel="noopener" data-astro-cid-zetdm5md>
Try FindForce Now →
</a> <a href="/" class="btn-secondary" data-astro-cid-zetdm5md> Back to Homepage </a> </div> <div class="error-suggestion" data-astro-cid-zetdm5md> <h2 data-astro-cid-zetdm5md>What You Might Be Looking For:</h2> <div class="suggestion-links" data-astro-cid-zetdm5md> <a href="/blog" class="suggestion-link" data-astro-cid-zetdm5md> <div class="suggestion-icon" data-astro-cid-zetdm5md>📖</div> <div class="suggestion-content" data-astro-cid-zetdm5md> <div class="suggestion-title" data-astro-cid-zetdm5md>Email Finding Insights</div> <div class="suggestion-desc" data-astro-cid-zetdm5md>
Professional prospecting strategies
</div> </div> </a> <a href="/complete-gdpr-compliant-guide" class="suggestion-link" data-astro-cid-zetdm5md> <div class="suggestion-icon" data-astro-cid-zetdm5md>⚖️</div> <div class="suggestion-content" data-astro-cid-zetdm5md> <div class="suggestion-title" data-astro-cid-zetdm5md>GDPR Compliance</div> <div class="suggestion-desc" data-astro-cid-zetdm5md>
Stay compliant while prospecting
</div> </div> </a> <a href="/privacy" class="suggestion-link" data-astro-cid-zetdm5md> <div class="suggestion-icon" data-astro-cid-zetdm5md>🔒</div> <div class="suggestion-content" data-astro-cid-zetdm5md> <div class="suggestion-title" data-astro-cid-zetdm5md>Privacy & Security</div> <div class="suggestion-desc" data-astro-cid-zetdm5md>How we protect your data</div> </div> </a> </div> </div> <div class="competitor-note" data-astro-cid-zetdm5md> <p class="competitor-text" data-astro-cid-zetdm5md>
Unlike our competitors, we're transparent about our success rates
            and
<a href="/" class="inline-link" data-astro-cid-zetdm5md>back them with guarantees</a>.
            That's the FindForce difference.
</p> </div> </div> </div> </main>  `, "scripts": ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "scripts" }, { "default": ($$result3) => renderTemplate` ${renderScript($$result3, "/home/runner/work/landing-page/landing-page/src/pages/404.astro?astro&type=script&index=0&lang.ts")} ` })}` })} ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/404.astro?astro&type=script&index=1&lang.ts")} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/404.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/404.astro";
const $$url = "/404.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$404,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
