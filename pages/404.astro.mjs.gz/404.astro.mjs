import { c as createAstro, a as createComponent, r as renderComponent, b as renderScript, d as renderTemplate, m as maybeRenderHead, e as addAttribute } from "../js/astro/server.DeFkX6hJ.js";
import "kleur/colors";
import { $ as $$BaseLayout } from "../js/BaseLayout.BcN4qwMm.js";
/* empty css                          */
import { renderers } from "../renderers.mjs";
const $$Astro = createAstro("https://findforce.io");
const $$404 = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$404;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "404 - Page Not Found | FindForce.io", "description": "Oops! The page you're looking for doesn't exist. But don't worry - our email finding still works perfectly.", "canonical": "https://findforce.io/404", "noindex": true, "data-astro-cid-zetdm5md": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="error-page" data-astro-cid-zetdm5md> <div class="container" data-astro-cid-zetdm5md> <div class="error-content" data-astro-cid-zetdm5md> <div class="error-visual" data-astro-cid-zetdm5md> <div class="error-number" data-astro-cid-zetdm5md>404</div> <div class="findforce-icon" data-astro-cid-zetdm5md> <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 128 128" width="80" height="80" data-astro-cid-zetdm5md> <path d="M50.4 78.5a75.1 75.1 0 0 0-28.5 6.9l24.2-65.7c.7-2 1.9-3.2 3.4-3.2h29c1.5 0 2.7 1.2 3.4 3.2l24.2 65.7s-11.6-7-28.5-7L67 45.5c-.4-1.7-1.6-2.8-2.9-2.8-1.3 0-2.5 1.1-2.9 2.7L50.4 78.5Zm-1.1 28.2Zm-4.2-20.2c-2 6.6-.6 15.8 4.2 20.2a17.5 17.5 0 0 1 .2-.7 5.5 5.5 0 0 1 5.7-4.5c2.8.1 4.3 1.5 4.7 4.7.2 1.1.2 2.3.2 3.5v.4c0 2.7.7 5.2 2.2 7.4a13 13 0 0 0 5.7 4.9v-.3l-.2-.3c-1.8-5.6-.5-9.5 4.4-12.8l1.5-1a73 73 0 0 0 3.2-2.2 16 16 0 0 0 6.8-11.4c.3-2 .1-4-.6-6l-.8.6-1.6 1a37 37 0 0 1-22.4 2.7c-5-.7-9.7-2-13.2-6.2Z" data-astro-cid-zetdm5md></path> </svg> </div> </div> <h1 data-astro-cid-zetdm5md>Well, This Is Awkward</h1> <div class="error-message" data-astro-cid-zetdm5md> <p class="lead" data-astro-cid-zetdm5md>
You're looking for a page that doesn't exist. But hey, at least our email finder works 95% of the time.
</p> <p data-astro-cid-zetdm5md>
Unlike this page, our email verification never fails to deliver. While you're here anyway,
            why not grab the tool that actually <strong data-astro-cid-zetdm5md>does</strong> what it promises?
</p> </div> <div class="stats-mini" data-astro-cid-zetdm5md> <div class="stat-item" data-astro-cid-zetdm5md> <div class="stat-value" data-astro-cid-zetdm5md>95%</div> <div class="stat-label" data-astro-cid-zetdm5md>Success Rate</div> </div> <div class="stat-item" data-astro-cid-zetdm5md> <div class="stat-value" data-astro-cid-zetdm5md>2 sec</div> <div class="stat-label" data-astro-cid-zetdm5md>Find Time</div> </div> <div class="stat-item" data-astro-cid-zetdm5md> <div class="stat-value" data-astro-cid-zetdm5md>0%</div> <div class="stat-label" data-astro-cid-zetdm5md>404 Errors</div> </div> </div> <div class="error-actions" data-astro-cid-zetdm5md> <a href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=404_page&utm_campaign=error_recovery" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="404_primary_cta"${addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url")} data-pirsch-non-interactive class="btn-primary" target="_blank" rel="noopener" data-astro-cid-zetdm5md>
Get FindForce Instead →
</a> <a href="/" class="btn-secondary" data-astro-cid-zetdm5md>
Back to Homepage
</a> </div> <div class="error-suggestion" data-astro-cid-zetdm5md> <h2 data-astro-cid-zetdm5md>Or Maybe You're Looking For:</h2> <div class="suggestion-links" data-astro-cid-zetdm5md> <a href="/blog" class="suggestion-link" data-astro-cid-zetdm5md> <div class="suggestion-icon" data-astro-cid-zetdm5md>📝</div> <div class="suggestion-content" data-astro-cid-zetdm5md> <div class="suggestion-title" data-astro-cid-zetdm5md>Blog</div> <div class="suggestion-desc" data-astro-cid-zetdm5md>Email finding tips & insights</div> </div> </a> <a href="/complete-gdpr-compliant-guide" class="suggestion-link" data-astro-cid-zetdm5md> <div class="suggestion-icon" data-astro-cid-zetdm5md>⚖️</div> <div class="suggestion-content" data-astro-cid-zetdm5md> <div class="suggestion-title" data-astro-cid-zetdm5md>GDPR Guide</div> <div class="suggestion-desc" data-astro-cid-zetdm5md>Stay compliant while prospecting</div> </div> </a> <a href="/privacy" class="suggestion-link" data-astro-cid-zetdm5md> <div class="suggestion-icon" data-astro-cid-zetdm5md>🔒</div> <div class="suggestion-content" data-astro-cid-zetdm5md> <div class="suggestion-title" data-astro-cid-zetdm5md>Privacy Policy</div> <div class="suggestion-desc" data-astro-cid-zetdm5md>How we protect your data</div> </div> </a> </div> </div> <div class="easter-egg" data-astro-cid-zetdm5md> <p class="easter-text" data-astro-cid-zetdm5md>
Fun fact: You have a better chance of finding this missing page than getting 95% accuracy
            from our competitors.
<span class="highlight" data-astro-cid-zetdm5md>Just saying.</span> </p> </div> </div> </div> </main> ` })} ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/404.astro?astro&type=script&index=0&lang.ts")} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/404.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/404.astro";
const $$url = "/404.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$404,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
