import { c as createAstro, a as createComponent, d as renderTemplate, f as defineScriptVars, b as renderScript, r as renderComponent, m as maybeRenderHead } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { $ as $$BaseLayout, a as $$Logo } from "../js/BaseLayout.Ci_Dh1rG.js";
import { A as API_URL, $ as $$StatsGrid, a as $$FormLayout } from "../js/FormLayout.BwOmYaGA.js";
/* empty css                                       */
import { renderers } from "../renderers.mjs";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://findforce.io");
const $$BenchmarkReport = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$BenchmarkReport;
  const stats = [
    {
      value: "38%",
      label: "Email addresses are invalid on submission",
      color: "#3b82f6"
    },
    {
      value: "28%",
      label: "Annual email list decay rate",
      color: "#3b82f6"
    },
    {
      value: "95%",
      label: "Bounce rate reduction achieved",
      color: "#3b82f6"
    },
    {
      value: "$750",
      label: "ROI per dollar on verification",
      color: "#3b82f6"
    }
  ];
  const reportSvg = `
<svg width="80" height="100" viewBox="0 0 80 100" fill="none">
  <rect width="80" height="100" rx="4" fill="#f8fafc" stroke="#e2e8f0" stroke-width="2"></rect>
  <rect x="10" y="10" width="60" height="8" rx="2" fill="#3b82f6"></rect>
  <rect x="10" y="25" width="40" height="4" rx="1" fill="#cbd5e1"></rect>
  <rect x="10" y="35" width="50" height="4" rx="1" fill="#cbd5e1"></rect>
  <rect x="10" y="45" width="45" height="4" rx="1" fill="#cbd5e1"></rect>
  <rect x="10" y="60" width="25" height="15" rx="2" fill="#10b981" opacity="0.2"></rect>
  <rect x="45" y="55" width="25" height="20" rx="2" fill="#f59e0b" opacity="0.2"></rect>
</svg>
`;
  return renderTemplate(_a || (_a = __template(["", ' <script defer src="https://cdn.jsdelivr.net/npm/@cap.js/widget@0.1.25/cap.min.js" integrity="sha256-EVDBSxDzIDhC7nt00kXfCs1D1/4Hdv+JDsXx+tzS9ls=" crossorigin="anonymous"><\/script> ', " ", " ", " <script>(function(){", '\n  function main() {\n    var formHandler = window.createFormHandler(\n      API_URL,\n      "Get My Free Report →",\n      "Sending report...",\n      window.validateBenchmarkForm\n    );\n\n    var cap = document.getElementById("cap");\n    cap.addEventListener("solve", formHandler.handleCaptchaSuccess);\n    cap.addEventListener("reset", formHandler.handleCaptchaError);\n    cap.addEventListener("error", formHandler.handleCaptchaError);\n\n    document.getElementById("report-form").addEventListener("submit", formHandler.submitForm);\n  }\n\n  if (document.readyState == "loading") {\n    document.addEventListener("DOMContentLoaded", main);\n  } else {\n    main();\n  }\n})();<\/script> '])), renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "Sales Team Productivity Benchmark Report - FindForce", "description": "Get your free Sales Team Productivity Benchmark Report and discover exactly where your team is bleeding time and money.", "canonical": "https://findforce.io/benchmark-report", "data-astro-cid-ixpev2dj": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="benchmark-page" data-astro-cid-ixpev2dj> <div class="container" data-astro-cid-ixpev2dj> <div class="left-section" data-astro-cid-ixpev2dj> ${renderComponent($$result2, "Logo", $$Logo, { "size": "lg", "data-astro-cid-ixpev2dj": true })} <h1 data-astro-cid-ixpev2dj>Stop Losing $32,760 Per SDR Annually</h1> <p class="subtitle" data-astro-cid-ixpev2dj>
Get your Sales Team Productivity Benchmark Report and discover exactly
          where your team is bleeding time and money. Only 62% of submitted
          emails are valid while lists decay at 28% annually.
</p> ${renderComponent($$result2, "StatsGrid", $$StatsGrid, { "stats": stats, "data-astro-cid-ixpev2dj": true })} </div> ${renderComponent($$result2, "FormLayout", $$FormLayout, { "title": "Get Your Free Report", "description": "Compare your team's performance against industry benchmarks. Average deliverability is only 83.1% - discover where you stand.", "formId": "report-form", "pageUrl": Astro2.url.pathname, "reportType": "sales-productivity-benchmark", "submitText": "Get My Free Report →", "visualDesc": "Industry benchmarks, ROI calculations, and 60-day implementation roadmap", "visualSvg": reportSvg, "visualTitle": "4-Page Custom Analysis", "data-astro-cid-ixpev2dj": true }, { "trust-signal-2": ($$result3) => renderTemplate`<span data-astro-cid-ixpev2dj>No spam, guaranteed</span>` })} </div> </section> ` }), renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/benchmark-report.astro?astro&type=script&index=0&lang.ts"), renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/benchmark-report.astro?astro&type=script&index=1&lang.ts"), renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/benchmark-report.astro?astro&type=script&index=2&lang.ts"), defineScriptVars({ API_URL }));
}, "/home/runner/work/landing-page/landing-page/src/pages/benchmark-report.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/benchmark-report.astro";
const $$url = "/benchmark-report.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$BenchmarkReport,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
