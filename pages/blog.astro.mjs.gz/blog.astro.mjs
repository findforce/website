import { a as createComponent, m as maybeRenderHead, b as renderScript, d as renderTemplate, r as renderComponent } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { g as getCollection } from "../js/_astro_content.DcebcUzF.js";
import { $ as $$BaseLayout } from "../js/BaseLayout.Ci_Dh1rG.js";
import "clsx";
/* empty css                            */
import { $ as $$BlogContainer } from "../js/BlogContainer.Bu5pxP50.js";
import { renderers } from "../renderers.mjs";
const $$Search = createComponent(async ($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div id="search-container" data-astro-cid-otpdt6jm> <input type="search" id="search-input" placeholder="Search blog posts..." aria-label="Search blog posts" data-astro-cid-otpdt6jm> <div id="search-results" data-astro-cid-otpdt6jm></div> </div> ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/components/Search.astro?astro&type=script&index=0&lang.ts")} `;
}, "/home/runner/work/landing-page/landing-page/src/components/Search.astro", void 0);
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  var posts = await getCollection("posts", function filterDrafts({ data }) {
    return data.draft !== true;
  });
  posts.sort(function sortByDate(a, b) {
    return b.data.publishDate.valueOf() - a.data.publishDate.valueOf();
  });
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "Blog",
    "name": "FindForce Blog",
    "description": "Expert insights on email finding, sales prospecting, and GDPR compliance for modern sales teams",
    "url": "https://findforce.io/blog",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": "https://findforce.io/blog"
    },
    "blogPost": posts.slice(0, 10).map(function createStructuredData(post) {
      return {
        "@type": "BlogPosting",
        "headline": post.data.title,
        "description": post.data.description,
        "datePublished": post.data.publishDate.toISOString(),
        "url": `https://findforce.io/blog/${post.slug}`,
        "image": post.data.coverImage ? `https://findforce.io${post.data.coverImage}` : "https://findforce.io/og-image.png",
        "author": {
          "@type": "Person",
          "name": post.data.author || "FindForce Team"
        }
      };
    })
  };
  var blogIndexMeta = [
    { property: "og:type", content: "website" },
    { name: "robots", content: "index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" }
  ];
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "FindForce Blog - Email Finding & Sales Prospecting Insights", "description": "Expert insights on email finding, sales prospecting, and GDPR compliance for modern sales teams. Tips, strategies, and tools to boost your sales performance.", "keywords": "email finding blog, sales prospecting tips, GDPR compliance, sales tools, email verification", "ogTitle": "FindForce Blog - Expert Sales & Email Finding Insights", "ogDescription": "Get expert insights on email finding, sales prospecting, and GDPR compliance. Practical tips and strategies for modern sales teams.", "canonical": "https://findforce.io/blog", "additionalMeta": blogIndexMeta, "structuredData": structuredData, "data-astro-cid-5tznm7mj": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<main class="blog-index" role="main" data-astro-cid-5tznm7mj> <header class="header" data-astro-cid-5tznm7mj> <h1 data-astro-cid-5tznm7mj>Our Blog</h1> <p class="subtitle" data-astro-cid-5tznm7mj>Insights, tips, and updates from the FindForce team</p> <a href="/blog/tags" class="browse-tags" data-astro-cid-5tznm7mj>Browse by tags</a> </header> ${renderComponent($$result2, "Search", $$Search, { "data-astro-cid-5tznm7mj": true })} ${renderComponent($$result2, "BlogContainer", $$BlogContainer, { "posts": posts, "layout": "list", "imagePosition": "left", "showImages": true, "showTags": true, "showAuthor": true, "showDescription": true, "className": "blog-index-container", "data-astro-cid-5tznm7mj": true })} </main> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/blog/index.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/blog/index.astro";
const $$url = "/blog.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
