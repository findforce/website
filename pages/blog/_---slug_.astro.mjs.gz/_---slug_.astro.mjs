import { c as createAstro, a as createComponent, m as maybeRenderHead, r as renderComponent, d as renderTemplate, e as addAttribute, F as Fragment } from "../../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { g as getCollection } from "../../js/_astro_content.DcebcUzF.js";
import { $ as $$BaseLayout } from "../../js/BaseLayout.1vF3xYnp.js";
import { $ as $$StartFreeTrial } from "../../js/StartFreeTrial.EngssTd9.js";
/* empty css                                */
import "clsx";
import { statSync } from "fs";
import { renderers } from "../../renderers.mjs";
const $$Astro$3 = createAstro("https://findforce.io");
const $$BlogFooter = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$BlogFooter;
  var { author = "FindForce Team" } = Astro2.props;
  var slug = Astro2.url.pathname.split("/").filter(Boolean).pop() || "blog";
  var slugUndescores = slug.replace(/-/g, "_");
  return renderTemplate`${maybeRenderHead()}<footer class="blog-footer" data-astro-cid-pasjzvzq> <div class="footer-divider" data-astro-cid-pasjzvzq></div> <div class="footer-content" data-astro-cid-pasjzvzq> <div class="about-summary" data-astro-cid-pasjzvzq> <h3 data-astro-cid-pasjzvzq>About FindForce</h3> <p data-astro-cid-pasjzvzq> <strong data-astro-cid-pasjzvzq>FindForce</strong> is the European alternative to Apollo.io, built
        specifically for GDPR-compliant B2B email verification. Founded in Estonia
        and serving 500+ European sales teams, we believe in transparent pricing,
        exceptional support, and privacy-first architecture.
</p> </div> <p class="compliance-text" data-astro-cid-pasjzvzq> <em data-astro-cid-pasjzvzq>
FindForce is a GDPR-native email verification service built for European
        sales teams. Based in Estonia (EU), we process all data within EU borders.
        For compliance inquiries, contact our Data Protection Officer at${" "} <a href="mailto:dpo@findforce.io" data-astro-cid-pasjzvzq>dpo@findforce.io</a> </em> </p> <div class="footer-meta" data-astro-cid-pasjzvzq> <span class="author" data-astro-cid-pasjzvzq><strong data-astro-cid-pasjzvzq>Author:</strong> ${author}</span> <span class="registration" data-astro-cid-pasjzvzq><strong data-astro-cid-pasjzvzq>Company Registration:</strong> 16511866</span> <span class="location" data-astro-cid-pasjzvzq><strong data-astro-cid-pasjzvzq>Based in:</strong> Tallinn, Estonia (EU) 🇪🇪</span> </div> </div> </footer> ${renderComponent($$result, "StartFreeTrial", $$StartFreeTrial, { "utm_source": "website", "utm_medium": "blog", "utm_campaign": slugUndescores, "data-astro-cid-pasjzvzq": true })} `;
}, "/home/runner/work/landing-page/landing-page/src/components/BlogFooter.astro", void 0);
const $$Astro$2 = createAstro("https://findforce.io");
const $$BlogOpeningHook = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$BlogOpeningHook;
  var { content, publishDate, updateDate, notes, filePath } = Astro2.props;
  function calculateReadingTime(content2) {
    var wordsPerMinute = 200;
    var wordCount = content2.split(/\s+/).length;
    var readingTime = Math.ceil(wordCount / wordsPerMinute);
    return Math.max(1, readingTime);
  }
  function formatDate(date) {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
  }
  function getFileModificationDate(filePath2) {
    try {
      var stats = statSync(filePath2);
      return stats.mtime;
    } catch (error) {
      return null;
    }
  }
  var readTime = calculateReadingTime(content);
  var fileModDate = filePath ? getFileModificationDate(filePath) : null;
  var lastUpdated = updateDate || fileModDate || publishDate;
  var formattedDate = formatDate(lastUpdated);
  return renderTemplate`${maybeRenderHead()}<div class="blog-opening-hook" data-astro-cid-2fbfsbss> <em data-astro-cid-2fbfsbss>
Last updated: ${formattedDate} | ${readTime} min read
${notes && ` | ${notes}`} </em> </div> `;
}, "/home/runner/work/landing-page/landing-page/src/components/BlogOpeningHook.astro", void 0);
const $$Astro$1 = createAstro("https://findforce.io");
const $$BlogTOC = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$BlogTOC;
  var { content } = Astro2.props;
  function extractHeadings(content2) {
    var headingRegex = /^## (.+)$/gm;
    var headings2 = [];
    var match;
    while ((match = headingRegex.exec(content2)) !== null) {
      var title = match[1].trim();
      var slug = title.toLowerCase().replace(/[^\w\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").trim();
      headings2.push({
        title,
        slug
      });
    }
    return headings2;
  }
  var headings = extractHeadings(content);
  return renderTemplate`${headings.length > 0 && renderTemplate`${maybeRenderHead()}<div class="blog-toc" data-astro-cid-t2ynpync><h3 data-astro-cid-t2ynpync>Table of Contents</h3><nav data-astro-cid-t2ynpync><ul data-astro-cid-t2ynpync>${headings.map(function createTOCItem(heading) {
    return renderTemplate`<li data-astro-cid-t2ynpync><a${addAttribute(`#${heading.slug}`, "href")} data-astro-cid-t2ynpync>${heading.title}</a></li>`;
  })}</ul></nav></div>`}`;
}, "/home/runner/work/landing-page/landing-page/src/components/BlogTOC.astro", void 0);
const $$Astro = createAstro("https://findforce.io");
async function getStaticPaths() {
  var posts = await getCollection("posts", function filterDrafts({ data }) {
    return data.draft !== true;
  });
  return posts.map(function createPath(post) {
    return {
      params: { slug: post.slug },
      props: { post }
    };
  });
}
const $$ = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  var { post } = Astro2.props;
  var { Content } = await post.render();
  var socialImage = post.data.coverImage || "/og-image.png";
  var blogCanonical = `https://findforce.io/blog/${post.slug}`;
  var postAuthor = post.data.author || "FindForce Team";
  var defaultBlogStructuredData = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "headline": post.data.title,
    "description": post.data.description,
    "image": socialImage,
    "datePublished": post.data.publishDate.toISOString(),
    "dateModified": post.data.updateDate?.toISOString() || post.data.publishDate.toISOString(),
    "author": {
      "@type": "Person",
      "name": postAuthor
    },
    "publisher": {
      "@type": "Organization",
      "name": "FindForce",
      "logo": {
        "@type": "ImageObject",
        "url": "https://findforce.io/findforce-192px.png"
      }
    },
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": `https://findforce.io/blog/${post.slug}`
    }
  };
  var blogStructuredData = post.data.structuredData || defaultBlogStructuredData;
  var blogAdditionalMeta = [
    { property: "article:published_time", content: post.data.publishDate.toISOString() },
    { property: "article:author", content: postAuthor }
  ];
  if (post.data.tags) {
    post.data.tags.forEach(function addTagMeta(tag) {
      blogAdditionalMeta.push({ property: "article:tag", content: tag });
    });
  }
  if (post.data.updateDate) {
    blogAdditionalMeta.push({ property: "article:modified_time", content: post.data.updateDate.toISOString() });
  }
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": post.data.title, "description": post.data.description, "keywords": post.data.tags ? post.data.tags.join(", ") : void 0, "ogImage": socialImage, "ogTitle": post.data.seoTitle || post.data.title, "ogDescription": post.data.seoDescription || post.data.description, "twitterCard": "summary_large_image", "twitterTitle": post.data.title, "twitterDescription": post.data.description, "twitterImage": socialImage, "canonical": blogCanonical, "additionalMeta": blogAdditionalMeta, "structuredData": blogStructuredData, "data-astro-cid-7jjqptxk": true }, { "default": async ($$result2) => renderTemplate`  ${maybeRenderHead()}<article class="blog-post" data-pagefind-body data-astro-cid-7jjqptxk> <header class="post-header" data-pagefind-meta="title" data-astro-cid-7jjqptxk> ${post.data.coverImage && renderTemplate`<div class="cover-image" data-astro-cid-7jjqptxk> <img${addAttribute(post.data.coverImage, "src")}${addAttribute(post.data.title, "alt")} width="800" height="400" loading="eager" data-astro-cid-7jjqptxk> </div>`} <h1 data-astro-cid-7jjqptxk>${post.data.title}</h1> <div class="post-meta" data-astro-cid-7jjqptxk> <time${addAttribute(post.data.publishDate.toISOString(), "datetime")} data-astro-cid-7jjqptxk> ${post.data.publishDate.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  })} </time> ${renderTemplate`<span data-astro-cid-7jjqptxk>by ${postAuthor}</span>`} </div> ${post.data.tags && renderTemplate`<div class="tags" data-astro-cid-7jjqptxk> ${post.data.tags.map(function createTagLink(tag) {
    return renderTemplate`<a${addAttribute(`/blog/tags/${tag}`, "href")} class="tag"${addAttribute(`View posts tagged with ${tag}`, "aria-label")} data-astro-cid-7jjqptxk>${tag}</a>`;
  })} </div>`} </header> ${renderComponent($$result2, "BlogOpeningHook", $$BlogOpeningHook, { "content": post.body, "publishDate": post.data.publishDate, "updateDate": post.data.updateDate, "notes": post.data.notes, "data-astro-cid-7jjqptxk": true })} ${renderComponent($$result2, "BlogTOC", $$BlogTOC, { "content": post.body, "data-astro-cid-7jjqptxk": true })} <div class="prose" data-astro-cid-7jjqptxk> ${renderComponent($$result2, "Content", Content, { "data-astro-cid-7jjqptxk": true })} </div> ${renderComponent($$result2, "BlogFooter", $$BlogFooter, { "author": postAuthor, "data-astro-cid-7jjqptxk": true })} </article> `, "head": async ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "head" }, { "default": async ($$result3) => renderTemplate` <meta property="og:type" content="article"> ${post.data.tags && renderTemplate`<meta name="news_keywords"${addAttribute(post.data.tags.join(", "), "content")}>`}` })}` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/blog/[...slug].astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/blog/[...slug].astro";
const $$url = "/blog/[...slug].html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
