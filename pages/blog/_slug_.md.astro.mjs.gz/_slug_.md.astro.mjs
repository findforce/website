import { g as getCollection } from "../../js/_astro_content.D8IhLt8N.js";
import { renderers } from "../../renderers.mjs";
const getStaticPaths = async () => {
  var posts = await getCollection("posts", function filterDrafts({ data }) {
    return data.draft !== true;
  });
  return posts.map(function createPath(post) {
    return { params: { slug: post.slug }, props: { post } };
  });
};
const GET = ({ props }) => {
  var post = props.post;
  var body = `# ${post.data.title}

${post.data.description}

${post.body}
`;
  return new Response(body, {
    headers: { "Content-Type": "text/markdown; charset=utf-8" }
  });
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET,
  getStaticPaths
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
