import { a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, e as addAttribute } from "../../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { g as getCollection } from "../../js/_astro_content.DEq6b1HM.js";
import { $ as $$BaseLayout } from "../../js/BaseLayout.Iez5vTa9.js";
import { $ as $$BlogContainer } from "../../js/BlogContainer.Bu5pxP50.js";
/* empty css                               */
import { renderers } from "../../renderers.mjs";
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  const posts = await getCollection("posts", function filterPosts({ data }) {
    return data.draft !== true;
  });
  posts.sort(function sortPosts(a, b) {
    return b.data.publishDate.valueOf() - a.data.publishDate.valueOf();
  });
  var tagMap = /* @__PURE__ */ new Map();
  posts.forEach(function processTags(post) {
    if (post.data.tags) {
      post.data.tags.forEach(function addTag(tag) {
        if (!tagMap.has(tag)) {
          tagMap.set(tag, []);
        }
        tagMap.get(tag).push(post);
      });
    }
  });
  var sortedTags = Array.from(tagMap.entries()).sort(function sortByCount(a, b) {
    return b[1].length - a[1].length;
  });
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "Blog Tags", "description": "Browse blog posts by tags", "data-astro-cid-sfsyb3ip": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="tags-index" data-astro-cid-sfsyb3ip> <div class="header" data-astro-cid-sfsyb3ip> <h1 data-astro-cid-sfsyb3ip>Browse by Tags</h1> <p class="subtitle" data-astro-cid-sfsyb3ip>Find posts organized by topics</p> <a href="/blog" class="back-link" data-astro-cid-sfsyb3ip>← Back to all posts</a> </div> <div class="tags-grid" data-astro-cid-sfsyb3ip> ${sortedTags.map(function renderTag([tag, tagPosts]) {
    return renderTemplate`<div class="tag-group" data-astro-cid-sfsyb3ip> <h2 data-astro-cid-sfsyb3ip> <a${addAttribute(`/blog/tags/${tag}`, "href")} data-astro-cid-sfsyb3ip>${tag}</a> <span class="count" data-astro-cid-sfsyb3ip>(${tagPosts.length})</span> </h2> ${renderComponent($$result2, "BlogContainer", $$BlogContainer, { "posts": tagPosts, "maxPosts": 3, "layout": "compact", "showImages": false, "showTags": false, "showAuthor": false, "showDescription": false, "className": "tag-posts", "data-astro-cid-sfsyb3ip": true })} ${tagPosts.length > 3 && renderTemplate`<a${addAttribute(`/blog/tags/${tag}`, "href")} class="view-all" data-astro-cid-sfsyb3ip>
View all ${tagPosts.length} posts →
</a>`} </div>`;
  })} </div> </div> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/blog/tags/index.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/blog/tags/index.astro";
const $$url = "/blog/tags.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
