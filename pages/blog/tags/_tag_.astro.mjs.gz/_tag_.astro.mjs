import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from "../../../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { g as getCollection } from "../../../js/_astro_content.DEq6b1HM.js";
import { $ as $$BaseLayout } from "../../../js/BaseLayout.Iez5vTa9.js";
import { $ as $$BlogContainer } from "../../../js/BlogContainer.Bu5pxP50.js";
/* empty css                                  */
import { renderers } from "../../../renderers.mjs";
const $$Astro = createAstro("https://findforce.io");
async function getStaticPaths() {
  const posts = await getCollection("posts", function filterPosts({ data }) {
    return data.draft !== true;
  });
  var allTags = /* @__PURE__ */ new Set();
  posts.forEach(function collectTags(post) {
    if (post.data.tags) {
      post.data.tags.forEach(function addTag(tag) {
        allTags.add(tag);
      });
    }
  });
  return Array.from(allTags).map(function createPath(tag) {
    var tagPosts = posts.filter(function filterByTag(post) {
      return post.data.tags && post.data.tags.includes(tag);
    });
    tagPosts.sort(function sortPosts(a, b) {
      return b.data.publishDate.valueOf() - a.data.publishDate.valueOf();
    });
    return {
      params: { tag },
      props: { tag, posts: tagPosts }
    };
  });
}
const $$tag = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$tag;
  var { tag, posts } = Astro2.props;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": `Posts tagged "${tag}"`, "description": `All blog posts tagged with ${tag}`, "data-astro-cid-nm6udwxr": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<div class="tag-page" data-astro-cid-nm6udwxr> <div class="header" data-astro-cid-nm6udwxr> <h1 data-astro-cid-nm6udwxr>Posts tagged "${tag}"</h1> <p class="subtitle" data-astro-cid-nm6udwxr>${posts.length} post${posts.length !== 1 ? "s" : ""} found</p> <div class="navigation" data-astro-cid-nm6udwxr> <a href="/blog" class="nav-link" data-astro-cid-nm6udwxr>← All posts</a> <a href="/blog/tags" class="nav-link" data-astro-cid-nm6udwxr>Browse all tags</a> </div> </div> ${renderComponent($$result2, "BlogContainer", $$BlogContainer, { "posts": posts, "layout": "list", "imagePosition": "left", "showImages": true, "showTags": true, "showAuthor": true, "showDescription": true, "className": "tag-page-container", "data-astro-cid-nm6udwxr": true })} </div> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/blog/tags/[tag].astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/blog/tags/[tag].astro";
const $$url = "/blog/tags/[tag].html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$tag,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
