import { a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, e as addAttribute } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { g as getCollection } from "../js/_astro_content.Ch7aehur.js";
import { $ as $$BaseLayout } from "../js/BaseLayout.Iez5vTa9.js";
/* empty css                            */
import { renderers } from "../renderers.mjs";
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  var changelogs = await getCollection("changelogs", function filterDrafts({ data }) {
    return data.draft !== true;
  });
  changelogs.sort(function sortByDate(a, b) {
    return b.data.releaseDate.valueOf() - a.data.releaseDate.valueOf();
  });
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": "FindForce Changelog",
    "description": "All FindForce updates, new features, and improvements",
    "url": "https://findforce.io/changelog"
  };
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "FindForce Changelog - All Updates & New Features", "description": "Stay up to date with all FindForce updates, new features, bug fixes, and improvements. See what's new in your favorite email finder.", "canonical": "https://findforce.io/changelog", "structuredData": structuredData, "data-astro-cid-b3ixuhka": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="changelog-index" data-astro-cid-b3ixuhka> <div class="container" data-astro-cid-b3ixuhka> <div class="header" data-astro-cid-b3ixuhka> <a href="/" class="back-link" data-astro-cid-b3ixuhka> <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor" data-astro-cid-b3ixuhka> <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" data-astro-cid-b3ixuhka></path> </svg>
Back to FindForce
</a> <h1 class="main-title" data-astro-cid-b3ixuhka>Changelog</h1> <p class="subtitle" data-astro-cid-b3ixuhka>Track all updates and improvements to FindForce</p> </div> <div class="changelog-list" data-astro-cid-b3ixuhka> ${changelogs.map(function renderChangelog(changelog) {
    var formattedDate = changelog.data.releaseDate.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric"
    });
    return renderTemplate`<article class="changelog-item" data-astro-cid-b3ixuhka> <div class="changelog-header" data-astro-cid-b3ixuhka> <div class="version-info" data-astro-cid-b3ixuhka> <div class="title-row" data-astro-cid-b3ixuhka> <h2 class="title" data-astro-cid-b3ixuhka>${changelog.data.title}</h2> <span${addAttribute(`status-badge status-${changelog.data.status}`, "class")} data-astro-cid-b3ixuhka> ${changelog.data.status === "development" ? "In Development" : changelog.data.status === "beta" ? "Beta" : "Released"} </span> </div> <time class="date"${addAttribute(changelog.data.releaseDate.toISOString(), "datetime")} data-astro-cid-b3ixuhka> ${formattedDate} </time> </div> <a${addAttribute(`/changelog/${changelog.data.version}`, "href")} class="view-details" data-astro-cid-b3ixuhka>
View Details →
</a> </div> <p class="description" data-astro-cid-b3ixuhka>${changelog.data.description}</p> ${changelog.data.highlights && renderTemplate`<ul class="highlights" data-astro-cid-b3ixuhka> ${changelog.data.highlights.slice(0, 3).map(function renderHighlight(highlight) {
      return renderTemplate`<li data-astro-cid-b3ixuhka>${highlight}</li>`;
    })} ${changelog.data.highlights.length > 3 && renderTemplate`<li class="more" data-astro-cid-b3ixuhka>
and ${changelog.data.highlights.length - 3} more improvements...
</li>`} </ul>`} </article>`;
  })} </div> </div> </section> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/changelog/index.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/changelog/index.astro";
const $$url = "/changelog.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
