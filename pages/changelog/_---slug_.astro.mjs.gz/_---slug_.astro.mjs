import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, e as addAttribute, g as renderSlot } from "../../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { g as getCollection } from "../../js/_astro_content.DmYddt9G.js";
import { $ as $$BaseLayout } from "../../js/BaseLayout.1vF3xYnp.js";
/* empty css                                */
import { renderers } from "../../renderers.mjs";
const $$Astro$1 = createAstro("https://findforce.io");
const $$ChangelogLayout = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$ChangelogLayout;
  var {
    version,
    title,
    description,
    releaseDate,
    downloadUrl,
    seoTitle,
    seoDescription,
    status = "released"
  } = Astro2.props;
  var formattedDate = releaseDate.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  });
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": title,
    "description": description,
    "datePublished": releaseDate.toISOString(),
    "author": {
      "@type": "Organization",
      "name": "FindForce"
    },
    "publisher": {
      "@type": "Organization",
      "name": "FindForce",
      "logo": {
        "@type": "ImageObject",
        "url": "https://findforce.io/findforce-192px.png"
      }
    }
  };
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": seoTitle || title, "description": seoDescription || description, "structuredData": structuredData, "data-astro-cid-ga5rcy22": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="changelog-page" data-astro-cid-ga5rcy22> <div class="container" data-astro-cid-ga5rcy22> <div class="changelog-header" data-astro-cid-ga5rcy22> <a href="/changelog" class="back-link" data-astro-cid-ga5rcy22> <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor" data-astro-cid-ga5rcy22> <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" data-astro-cid-ga5rcy22></path> </svg>
Back to Changelog
</a> <h1 class="main-title" data-astro-cid-ga5rcy22> ${title} <span${addAttribute(`status-badge status-${status}`, "class")} data-astro-cid-ga5rcy22> ${status === "development" ? "In Development" : status === "beta" ? "Beta" : "Released"} </span> </h1> <p class="release-date" data-astro-cid-ga5rcy22>Released ${formattedDate}</p> </div> <div class="changelog-content" data-astro-cid-ga5rcy22> <div class="prose" data-astro-cid-ga5rcy22> ${renderSlot($$result2, $$slots["default"])} </div> </div> ${downloadUrl && renderTemplate`<div class="footer-nav" data-astro-cid-ga5rcy22> <a${addAttribute(downloadUrl, "href")} class="btn-primary" target="_blank" rel="noopener" data-astro-cid-ga5rcy22>
Update Extension →
</a> </div>`} </div> </section> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/layouts/ChangelogLayout.astro", void 0);
const $$Astro = createAstro("https://findforce.io");
async function getStaticPaths() {
  var changelogs = await getCollection("changelogs", function filterDrafts({ data }) {
    return data.draft !== true;
  });
  return changelogs.map(function createPath(changelog) {
    return {
      params: { slug: changelog.data.version },
      props: { changelog }
    };
  });
}
const $$ = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  var { changelog } = Astro2.props;
  var { Content } = await changelog.render();
  return renderTemplate`${renderComponent($$result, "ChangelogLayout", $$ChangelogLayout, { "version": changelog.data.version, "title": changelog.data.title, "description": changelog.data.description, "releaseDate": changelog.data.releaseDate, "downloadUrl": changelog.data.downloadUrl, "seoTitle": changelog.data.seoTitle, "seoDescription": changelog.data.seoDescription, "status": changelog.data.status }, { "default": async ($$result2) => renderTemplate` ${renderComponent($$result2, "Content", Content, {})} ` })}`;
}, "/home/runner/work/landing-page/landing-page/src/pages/changelog/[...slug].astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/changelog/[...slug].astro";
const $$url = "/changelog/[...slug].html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
