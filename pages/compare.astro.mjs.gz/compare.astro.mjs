import { a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, e as addAttribute } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { g as getCollection } from "../js/_astro_content.Ch7aehur.js";
import { $ as $$BaseLayout, a as $$Logo } from "../js/BaseLayout.Iez5vTa9.js";
/* empty css                            */
import { renderers } from "../renderers.mjs";
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  var comparisons = await getCollection("comparisons", function filterDrafts({ data }) {
    return data.draft !== true;
  });
  comparisons.sort(function sortByDate(a, b) {
    return a.data.publishDate.valueOf() - b.data.publishDate.valueOf();
  });
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": "FindForce Comparisons",
    "description": "Compare FindForce with other email finder tools and see why we're the best choice for your business",
    "url": "https://findforce.io/compare"
  };
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "Compare FindForce with Other Email Finder Tools", "description": "See how FindForce compares to other email finder tools. Detailed comparisons of features, pricing, and performance to help you choose the best solution.", "canonical": "https://findforce.io/compare", "structuredData": structuredData, "data-astro-cid-neplck24": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="compare-index" data-astro-cid-neplck24> <div class="container" data-astro-cid-neplck24> <div class="header" data-astro-cid-neplck24> <a href="/" class="back-link" data-astro-cid-neplck24> <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor" data-astro-cid-neplck24> <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" data-astro-cid-neplck24></path> </svg>
Back to FindForce
</a> <h1 class="main-title" data-astro-cid-neplck24>Compare FindForce</h1> <p class="subtitle" data-astro-cid-neplck24>See how FindForce stacks up against the competition</p> </div> <div class="comparisons-grid" data-astro-cid-neplck24> ${comparisons.map(function renderComparison(comparison) {
    return renderTemplate`<article class="comparison-card" data-astro-cid-neplck24> <a${addAttribute(`/compare/${comparison.slug}`, "href")} class="card-link"${addAttribute(`Compare FindForce with ${comparison.data.competitor}: ${comparison.data.title}`, "aria-label")} data-astro-cid-neplck24> <div class="vs-header" data-astro-cid-neplck24> <div class="logo-section" data-astro-cid-neplck24> ${renderComponent($$result2, "Logo", $$Logo, { "size": "sm", "clickable": false, "data-astro-cid-neplck24": true })} <span class="vs-text" data-astro-cid-neplck24>VS</span> ${comparison.data.competitorLogo ? renderTemplate`<img${addAttribute(comparison.data.competitorLogo, "src")}${addAttribute(comparison.data.competitor, "alt")} class="competitor-logo" data-astro-cid-neplck24>` : renderTemplate`<div class="competitor-placeholder" data-astro-cid-neplck24>${comparison.data.competitor}</div>`} </div> </div> <div class="comparison-content" data-astro-cid-neplck24> <h2 data-astro-cid-neplck24>${comparison.data.title}</h2> <p class="description" data-astro-cid-neplck24>${comparison.data.description}</p> ${comparison.data.verdict && renderTemplate`<div${addAttribute(`verdict-badge ${comparison.data.verdict.winner}`, "class")} data-astro-cid-neplck24> ${comparison.data.verdict.winner === "findforce" && "FindForce Wins"} ${comparison.data.verdict.winner === "competitor" && `${comparison.data.competitor} Wins`} ${comparison.data.verdict.winner === "tie" && "It's a Tie"} </div>`} <div class="card-footer" data-astro-cid-neplck24> <span class="view-text" data-astro-cid-neplck24>View Comparison</span> <svg class="arrow-icon" width="20" height="20" viewBox="0 0 20 20" fill="currentColor" data-astro-cid-neplck24> <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" data-astro-cid-neplck24></path> </svg> </div> </div> </a> </article>`;
  })} </div> ${comparisons.length === 0 && renderTemplate`<div class="empty-state" data-astro-cid-neplck24> <h2 data-astro-cid-neplck24>No Comparisons Available</h2> <p data-astro-cid-neplck24>We're working on adding detailed comparisons. Check back soon!</p> </div>`} </div> </section> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/compare/index.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/compare/index.astro";
const $$url = "/compare.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
