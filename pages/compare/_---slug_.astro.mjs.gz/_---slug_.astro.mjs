import { c as createAstro, a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, e as addAttribute } from "../../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { g as getCollection } from "../../js/_astro_content.FXD7aPeX.js";
import { $ as $$BaseLayout, a as $$Logo } from "../../js/BaseLayout.1vF3xYnp.js";
import { $ as $$StartFreeTrial } from "../../js/StartFreeTrial.EngssTd9.js";
/* empty css                                */
import { renderers } from "../../renderers.mjs";
const $$Astro = createAstro("https://findforce.io");
async function getStaticPaths() {
  var comparisons = await getCollection("comparisons", function filterDrafts({ data }) {
    return data.draft !== true;
  });
  return comparisons.map(function createPath(comparison) {
    return {
      params: { slug: comparison.slug },
      props: { comparison }
    };
  });
}
const $$ = createComponent(async ($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$;
  var { comparison } = Astro2.props;
  var { Content } = await comparison.render();
  var pageTitle = comparison.data.seoTitle || comparison.data.title;
  var pageDescription = comparison.data.seoDescription || comparison.data.description;
  var canonical = `https://findforce.io/compare/${comparison.slug}`;
  var slugUnderscore = comparison.slug.replace(/-/g, "_");
  var ogImage = comparison.data.ogImage;
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "ComparisonPage",
    "name": comparison.data.title,
    "description": comparison.data.description,
    "url": canonical,
    "datePublished": comparison.data.publishDate.toISOString(),
    "dateModified": comparison.data.updateDate?.toISOString() || comparison.data.publishDate.toISOString(),
    "author": {
      "@type": "Organization",
      "name": "FindForce"
    },
    "publisher": {
      "@type": "Organization",
      "name": "FindForce",
      "logo": {
        "@type": "ImageObject",
        "url": "https://findforce.io/findforce-192px.png"
      }
    }
  };
  var additionalMeta = [
    { property: "article:published_time", content: comparison.data.publishDate.toISOString() },
    { name: "robots", content: "index, follow" }
  ];
  if (comparison.data.updateDate) {
    additionalMeta.push({ property: "article:modified_time", content: comparison.data.updateDate.toISOString() });
  }
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": pageTitle, "description": pageDescription, "canonical": canonical, "structuredData": structuredData, "additionalMeta": additionalMeta, "ogImage": ogImage, "data-astro-cid-kbcyrxd5": true }, { "default": async ($$result2) => renderTemplate` ${maybeRenderHead()}<article class="comparison-page" data-astro-cid-kbcyrxd5> <header class="comparison-header" data-astro-cid-kbcyrxd5> <div class="breadcrumb" data-astro-cid-kbcyrxd5> <a href="/" data-astro-cid-kbcyrxd5>Home</a> <span data-astro-cid-kbcyrxd5>›</span> <a href="/compare" data-astro-cid-kbcyrxd5>Comparison</a> <span data-astro-cid-kbcyrxd5>›</span> <span data-astro-cid-kbcyrxd5>${comparison.data.competitor}</span> </div> <div class="vs-logos" data-astro-cid-kbcyrxd5> <div class="logo-item" data-astro-cid-kbcyrxd5> ${renderComponent($$result2, "Logo", $$Logo, { "size": "sm", "href": "/", "data-astro-cid-kbcyrxd5": true })} </div> <div class="vs-divider" data-astro-cid-kbcyrxd5>VS</div> <div class="logo-item" data-astro-cid-kbcyrxd5> ${comparison.data.competitorLogo ? renderTemplate`<img${addAttribute(comparison.data.competitorLogo, "src")}${addAttribute(comparison.data.competitor, "alt")} width="120" height="40" data-astro-cid-kbcyrxd5>` : renderTemplate`<div class="logo-placeholder" data-astro-cid-kbcyrxd5>${comparison.data.competitor}</div>`} </div> </div> <h1 data-astro-cid-kbcyrxd5>${comparison.data.title}</h1> <p class="description" data-astro-cid-kbcyrxd5>${comparison.data.description}</p> <div class="meta" data-astro-cid-kbcyrxd5> <time${addAttribute(comparison.data.publishDate.toISOString(), "datetime")} data-astro-cid-kbcyrxd5>
Updated ${comparison.data.updateDate?.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  }) || comparison.data.publishDate.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric"
  })} </time> </div> </header> ${comparison.data.pricing && renderTemplate`<section class="pricing-comparison" data-astro-cid-kbcyrxd5> <h2 data-astro-cid-kbcyrxd5>Pricing Comparison</h2> <div class="pricing-grid" data-astro-cid-kbcyrxd5> <div class="pricing-card findforce" data-astro-cid-kbcyrxd5> <h3 data-astro-cid-kbcyrxd5>FindForce</h3> <div class="price" data-astro-cid-kbcyrxd5>${comparison.data.pricing.findforce}</div> </div> <div class="pricing-card competitor" data-astro-cid-kbcyrxd5> <h3 data-astro-cid-kbcyrxd5>${comparison.data.competitor}</h3> <div class="price" data-astro-cid-kbcyrxd5>${comparison.data.pricing.competitor}</div> </div> </div> </section>`} ${comparison.data.features && renderTemplate`<section class="features-comparison" data-astro-cid-kbcyrxd5> <h2 data-astro-cid-kbcyrxd5>Feature Comparison</h2> <div class="features-table" data-astro-cid-kbcyrxd5> <div class="table-header" data-astro-cid-kbcyrxd5> <div class="feature-name" data-astro-cid-kbcyrxd5>Feature</div> <div class="findforce-col" data-astro-cid-kbcyrxd5>FindForce</div> <div class="competitor-col" data-astro-cid-kbcyrxd5>${comparison.data.competitor}</div> </div> ${comparison.data.features.map(function renderFeature(feature) {
    return renderTemplate`<div class="table-row" data-astro-cid-kbcyrxd5> <div class="feature-name" data-astro-cid-kbcyrxd5> <strong data-astro-cid-kbcyrxd5>${feature.name}</strong> ${feature.description && renderTemplate`<p class="feature-desc" data-astro-cid-kbcyrxd5>${feature.description}</p>`} </div> <div class="findforce-col" data-astro-cid-kbcyrxd5> ${feature.findforce ? renderTemplate`<span class="check" data-astro-cid-kbcyrxd5>✓</span>` : renderTemplate`<span class="cross" data-astro-cid-kbcyrxd5>✗</span>`} </div> <div class="competitor-col" data-astro-cid-kbcyrxd5> ${feature.competitor ? renderTemplate`<span class="check" data-astro-cid-kbcyrxd5>✓</span>` : renderTemplate`<span class="cross" data-astro-cid-kbcyrxd5>✗</span>`} </div> </div>`;
  })} </div> </section>`} <section class="comparison-content" data-astro-cid-kbcyrxd5> ${renderComponent($$result2, "Content", Content, { "data-astro-cid-kbcyrxd5": true })} </section> ${comparison.data.verdict && renderTemplate`<section class="verdict" data-astro-cid-kbcyrxd5> <h2 data-astro-cid-kbcyrxd5>Our Verdict</h2> <div${addAttribute(`verdict-card ${comparison.data.verdict.winner}`, "class")} data-astro-cid-kbcyrxd5> <div class="verdict-winner" data-astro-cid-kbcyrxd5> ${comparison.data.verdict.winner === "findforce" && "FindForce Wins"} ${comparison.data.verdict.winner === "competitor" && `${comparison.data.competitor} Wins`} ${comparison.data.verdict.winner === "tie" && "It's a Tie"} </div> <p data-astro-cid-kbcyrxd5>${comparison.data.verdict.summary}</p> </div> </section>`} ${renderComponent($$result2, "StartFreeTrial", $$StartFreeTrial, { "title": "Ready to try the winning solution?", "subtitle": `Join 500+ sales teams who chose FindForce over ${comparison.data.competitor}`, "ctaText": "Start Your Free Trial →", "background": "gradient", "size": "large", "utm_source": "comparison", "utm_medium": "web", "utm_campaign": `compare_${slugUnderscore}`, "utm_content": "bottom_cta", "data-astro-cid-kbcyrxd5": true })} </article> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/compare/[...slug].astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/compare/[...slug].astro";
const $$url = "/compare/[...slug].html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$,
  file: $$file,
  getStaticPaths,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
