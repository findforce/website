import { c as createAstro, a as createComponent, d as renderTemplate, f as defineScriptVars, b as renderScript, r as renderComponent, m as maybeRenderHead } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { $ as $$BaseLayout, a as $$Logo } from "../js/BaseLayout.Ci_Dh1rG.js";
import { A as API_URL, $ as $$StatsGrid, a as $$FormLayout } from "../js/FormLayout.BwOmYaGA.js";
/* empty css                                              */
import { renderers } from "../renderers.mjs";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(cooked.slice()) }));
var _a;
const $$Astro = createAstro("https://findforce.io");
const $$DownloadGdprChecklist = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$DownloadGdprChecklist;
  const stats = [
    {
      value: "127",
      label: "Compliance checkpoints across 12 critical areas",
      color: "#059669"
    },
    {
      value: "2,245",
      label: "GDPR enforcement cases analyzed",
      color: "#059669"
    },
    {
      value: "€310M",
      label: "LinkedIn's recent GDPR fine",
      color: "#059669"
    },
    {
      value: "892%",
      label: "ROI on compliance investment",
      color: "#059669"
    }
  ];
  const checklistSvg = `
<svg width="80" height="100" viewBox="0 0 80 100" fill="none">
  <rect width="80" height="100" rx="4" fill="#f8fafc" stroke="#e2e8f0" stroke-width="2"></rect>
  <rect x="10" y="10" width="60" height="8" rx="2" fill="#059669"></rect>
  <rect x="10" y="22" width="50" height="3" rx="1" fill="#cbd5e1"></rect>
  <rect x="10" y="28" width="55" height="3" rx="1" fill="#cbd5e1"></rect>
  <circle cx="18" cy="38" r="2" fill="#10b981"></circle>
  <rect x="24" y="36" width="35" height="4" rx="1" fill="#cbd5e1"></rect>
  <circle cx="18" cy="46" r="2" fill="#10b981"></circle>
  <rect x="24" y="44" width="40" height="4" rx="1" fill="#cbd5e1"></rect>
  <circle cx="18" cy="54" r="2" fill="#10b981"></circle>
  <rect x="24" y="52" width="30" height="4" rx="1" fill="#cbd5e1"></rect>
  <circle cx="18" cy="62" r="2" fill="#e5e7eb"></circle>
  <rect x="24" y="60" width="25" height="4" rx="1" fill="#e5e7eb"></rect>
  <rect x="10" y="72" width="60" height="6" rx="1" fill="#10b981" opacity="0.2"></rect>
  <rect x="10" y="82" width="45" height="6" rx="1" fill="#f59e0b" opacity="0.2"></rect>
  <text x="40" y="96" text-anchor="middle" font-size="8" fill="#64748b">32 Pages</text>
</svg>
`;
  return renderTemplate(_a || (_a = __template(["", ' <script defer src="https://cdn.jsdelivr.net/npm/@cap.js/widget@0.1.25/cap.min.js" integrity="sha256-EVDBSxDzIDhC7nt00kXfCs1D1/4Hdv+JDsXx+tzS9ls=" crossorigin="anonymous"><\/script> ', " ", " ", " <script>(function(){", '\n  function main() {\n    var formHandler = window.createFormHandler(\n      API_URL,\n      "Download 32-Page Checklist →",\n      "Preparing 32-page manual...",\n      window.validateGdprForm\n    );\n\n    var cap = document.getElementById("cap");\n    cap.addEventListener("solve", formHandler.handleCaptchaSuccess);\n    cap.addEventListener("reset", formHandler.handleCaptchaError);\n    cap.addEventListener("error", formHandler.handleCaptchaError);\n\n    document.getElementById("gdpr-form").addEventListener("submit", formHandler.submitForm);\n  }\n\n  if (document.readyState == "loading") {\n    document.addEventListener("DOMContentLoaded", main);\n  } else {\n    main();\n  }\n})();<\/script> '])), renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "127-Point GDPR Compliance Checklist for Sales Teams - FindForce", "description": "Download the most comprehensive GDPR checklist for B2B sales. 32-page PDF based on 2,245 enforcement cases. Avoid €2.36M fines with this 127-point compliance framework.", "canonical": "https://findforce.io/download-gdpr-checklist", "data-astro-cid-pi6tdkvv": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="gdpr-page" data-astro-cid-pi6tdkvv> <div class="container" data-astro-cid-pi6tdkvv> <div class="left-section" data-astro-cid-pi6tdkvv> ${renderComponent($$result2, "Logo", $$Logo, { "size": "lg", "data-astro-cid-pi6tdkvv": true })} <h1 data-astro-cid-pi6tdkvv>127-Point GDPR Compliance Checklist</h1> <p class="subtitle" data-astro-cid-pi6tdkvv>
The most comprehensive B2B email prospecting compliance guide ever
          created. 32-page PDF analyzing 2,245 enforcement cases to keep your
          sales team 100% compliant. Used by 500+ European sales teams to avoid
          the €2.36M average fine.
</p> ${renderComponent($$result2, "StatsGrid", $$StatsGrid, { "stats": stats, "data-astro-cid-pi6tdkvv": true })} <div class="checklist-preview" data-astro-cid-pi6tdkvv> <h3 data-astro-cid-pi6tdkvv>Inside Your 32-Page Compliance Manual</h3> <ul class="preview-items" data-astro-cid-pi6tdkvv> <li data-astro-cid-pi6tdkvv>✅ Legal Basis Documentation (with LIA templates)</li> <li data-astro-cid-pi6tdkvv>✅ 90-day implementation roadmap</li> <li data-astro-cid-pi6tdkvv>✅ Vendor evaluation scorecard (10-point system)</li> <li data-astro-cid-pi6tdkvv>✅ Technical security requirements (AES-256+)</li> <li data-astro-cid-pi6tdkvv>✅ Breach response timeline (72-hour protocol)</li> <li data-astro-cid-pi6tdkvv>✅ Data Subject Rights automation guide</li> <li data-astro-cid-pi6tdkvv>✅ ROI calculator showing 892% return</li> <li data-astro-cid-pi6tdkvv>✅ Real case studies and fine amounts</li> </ul> </div> </div> ${renderComponent($$result2, "FormLayout", $$FormLayout, { "title": "Get Your Free 127-Point Checklist", "description": "Version 3.0 updated August 2025 for EU AI Act. Join 500+ European sales teams using this framework to stay compliant while scaling.", "formId": "gdpr-form", "includeExtraFields": true, "pageUrl": Astro2.url.pathname, "reportType": "gdpr-checklist", "submitText": "Download 32-Page Checklist →", "visualDesc": "Complete with legal templates, ROI calculator, and vendor scorecards", "visualSvg": checklistSvg, "visualTitle": "127-Point Compliance Framework", "data-astro-cid-pi6tdkvv": true })} </div> </section> ` }), renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/download-gdpr-checklist.astro?astro&type=script&index=0&lang.ts"), renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/download-gdpr-checklist.astro?astro&type=script&index=1&lang.ts"), renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/download-gdpr-checklist.astro?astro&type=script&index=2&lang.ts"), defineScriptVars({ API_URL }));
}, "/home/runner/work/landing-page/landing-page/src/pages/download-gdpr-checklist.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/download-gdpr-checklist.astro";
const $$url = "/download-gdpr-checklist.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$DownloadGdprChecklist,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
