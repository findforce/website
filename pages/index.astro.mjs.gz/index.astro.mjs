import { c as createAstro, a as createComponent, d as renderTemplate, e as addAttribute, m as maybeRenderHead, r as renderComponent, b as renderScript, F as Fragment } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import "clsx";
/* empty css                            */
import { $ as $$BaseLayout } from "../js/BaseLayout.Iez5vTa9.js";
import { $ as $$BlogContainer } from "../js/BlogContainer.Bu5pxP50.js";
import { g as getCollection } from "../js/_astro_content.DcebcUzF.js";
import { renderers } from "../renderers.mjs";
var __freeze$1 = Object.freeze;
var __defProp$1 = Object.defineProperty;
var __template$1 = (cooked, raw) => __freeze$1(__defProp$1(cooked, "raw", { value: __freeze$1(cooked.slice()) }));
var _a$1;
const $$Astro$a = createAstro("https://findforce.io");
const $$AccuracySection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$a, $$props, $$slots);
  Astro2.self = $$AccuracySection;
  var { className = "" } = Astro2.props;
  return renderTemplate(_a$1 || (_a$1 = __template$1(["", "<section", ` aria-labelledby="accuracy-heading" data-astro-cid-jheqx6ak> <div class="container" data-astro-cid-jheqx6ak> <div class="section-header" data-astro-cid-jheqx6ak> <div class="badge" data-astro-cid-jheqx6ak>Technical Excellence</div> <h2 id="accuracy-heading" class="heading" data-astro-cid-jheqx6ak>How We Achieve 95% Accuracy</h2> <p class="subheading" data-astro-cid-jheqx6ak>We don't guess. We verify through 5 layers of validation. If we're not 95% confident, we don't return the email.</p> </div> <div class="verification-process" data-astro-cid-jheqx6ak> <div class="steps-grid" data-astro-cid-jheqx6ak> <div class="step" data-astro-cid-jheqx6ak> <div class="step-circle step-1" data-astro-cid-jheqx6ak>1</div> <h3 class="step-title" data-astro-cid-jheqx6ak>Syntax Validation</h3> <p class="step-desc" data-astro-cid-jheqx6ak>RFC 5322 compliance check. Invalid format = instant rejection.</p> </div> <div class="arrow" data-astro-cid-jheqx6ak> <svg width="40" height="40" viewBox="0 0 24 24" fill="#cbd5e1" data-astro-cid-jheqx6ak> <path d="M5 12h14m0 0l-7-7m7 7l-7 7" data-astro-cid-jheqx6ak></path> </svg> </div> <div class="step" data-astro-cid-jheqx6ak> <div class="step-circle step-2" data-astro-cid-jheqx6ak>2</div> <h3 class="step-title" data-astro-cid-jheqx6ak>DNS/MX Records</h3> <p class="step-desc" data-astro-cid-jheqx6ak>Domain exists? Mail server configured? Real-time DNS lookup.</p> </div> <div class="arrow" data-astro-cid-jheqx6ak> <svg width="40" height="40" viewBox="0 0 24 24" fill="#cbd5e1" data-astro-cid-jheqx6ak> <path d="M5 12h14m0 0l-7-7m7 7l-7 7" data-astro-cid-jheqx6ak></path> </svg> </div> <div class="step" data-astro-cid-jheqx6ak> <div class="step-circle step-3" data-astro-cid-jheqx6ak>3</div> <h3 class="step-title" data-astro-cid-jheqx6ak>SMTP Verification</h3> <p class="step-desc" data-astro-cid-jheqx6ak>Handshake with mail server. Mailbox exists? Without sending email.</p> </div> </div> <div class="steps-row" data-astro-cid-jheqx6ak> <div class="step" data-astro-cid-jheqx6ak> <div class="step-circle step-4" data-astro-cid-jheqx6ak>4</div> <h3 class="step-title" data-astro-cid-jheqx6ak>Pattern Intelligence</h3> <p class="step-desc" data-astro-cid-jheqx6ak>10,000+ company patterns learned. firstname.lastname@? first.l@? We know.</p> </div> <div class="step" data-astro-cid-jheqx6ak> <div class="step-circle step-5" data-astro-cid-jheqx6ak>5</div> <h3 class="step-title" data-astro-cid-jheqx6ak>Third-Party Validation</h3> <p class="step-desc" data-astro-cid-jheqx6ak>Cross-check with premium APIs. Multiple sources = higher confidence.</p> </div> </div> </div> <div class="accuracy-stats" data-astro-cid-jheqx6ak> <h3 class="stats-heading" data-astro-cid-jheqx6ak>The Numbers Don't Lie</h3> <div class="stats-grid" data-astro-cid-jheqx6ak> <div class="stat" data-astro-cid-jheqx6ak> <p class="stat-value" data-astro-cid-jheqx6ak>95%</p> <p class="stat-label" data-astro-cid-jheqx6ak>Average accuracy rate</p> </div> <div class="stat" data-astro-cid-jheqx6ak> <p class="stat-value" data-astro-cid-jheqx6ak>5s</p> <p class="stat-label" data-astro-cid-jheqx6ak>Average verification time</p> </div> <div class="stat" data-astro-cid-jheqx6ak> <p class="stat-value" data-astro-cid-jheqx6ak>&lt;2%</p> <p class="stat-label" data-astro-cid-jheqx6ak>Bounce rate after verification</p> </div> <div class="stat" data-astro-cid-jheqx6ak> <p class="stat-value" data-astro-cid-jheqx6ak>500+</p> <p class="stat-label" data-astro-cid-jheqx6ak>Beta verifications tested</p> </div> </div> </div> <div class="roi-calculator" data-astro-cid-jheqx6ak> <h3 class="roi-heading" data-astro-cid-jheqx6ak>Calculate Your ROI</h3> <p class="roi-subheading" data-astro-cid-jheqx6ak>See exactly how much FindForce saves your team</p> <div class="roi-grid" data-astro-cid-jheqx6ak> <div class="inputs" data-astro-cid-jheqx6ak> <label for="sdr-count" class="input-label" data-astro-cid-jheqx6ak>Number of SDRs in your team</label> <input type="range" id="sdr-count" min="1" max="20" value="5" class="range-input" oninput="calculateROI()" aria-describedby="sdr-display" data-astro-cid-jheqx6ak> <div class="range-labels" data-astro-cid-jheqx6ak> <span data-astro-cid-jheqx6ak>1</span> <span id="sdr-display" class="range-value" data-astro-cid-jheqx6ak>5 SDRs</span> <span data-astro-cid-jheqx6ak>20</span> </div> <label for="hourly-cost" class="input-label" data-astro-cid-jheqx6ak>Average SDR hourly cost</label> <input type="range" id="hourly-cost" min="15" max="50" value="25" class="range-input" oninput="calculateROI()" aria-describedby="cost-display" data-astro-cid-jheqx6ak> <div class="range-labels" data-astro-cid-jheqx6ak> <span data-astro-cid-jheqx6ak>€15</span> <span id="cost-display" class="range-value" data-astro-cid-jheqx6ak>€25/hour</span> <span data-astro-cid-jheqx6ak>€50</span> </div> <label for="hours-wasted" class="input-label" data-astro-cid-jheqx6ak>Hours wasted on manual email finding</label> <input type="range" id="hours-wasted" min="5" max="20" value="14.5" step="0.5" class="range-input" oninput="calculateROI()" aria-describedby="hours-display" data-astro-cid-jheqx6ak> <div class="range-labels" data-astro-cid-jheqx6ak> <span data-astro-cid-jheqx6ak>5h</span> <span id="hours-display" class="range-value" data-astro-cid-jheqx6ak>14.5 hours/week</span> <span data-astro-cid-jheqx6ak>20h</span> </div> </div> <div class="results" data-astro-cid-jheqx6ak> <h4 class="results-title" data-astro-cid-jheqx6ak>Your Savings with FindForce</h4> <div class="result-item" data-astro-cid-jheqx6ak> <p class="result-label" data-astro-cid-jheqx6ak>Weekly time saved:</p> <p class="result-value" data-astro-cid-jheqx6ak><span id="time-saved" data-astro-cid-jheqx6ak>72.5</span> hours</p> </div> <div class="result-item" data-astro-cid-jheqx6ak> <p class="result-label" data-astro-cid-jheqx6ak>Monthly cost saved:</p> <p class="result-value" data-astro-cid-jheqx6ak>€<span id="money-saved" data-astro-cid-jheqx6ak>7,250</span></p> </div> <div class="result-divider" data-astro-cid-jheqx6ak> <p class="result-label" data-astro-cid-jheqx6ak>Your investment:</p> <p class="result-value" data-astro-cid-jheqx6ak>€24.50/month</p> </div> <div class="roi-box" data-astro-cid-jheqx6ak> <p class="roi-label" data-astro-cid-jheqx6ak>Return on Investment:</p> <p class="roi-value" data-astro-cid-jheqx6ak><span id="roi" data-astro-cid-jheqx6ak>29,500</span>%</p> </div> </div> </div> <div class="roi-link" data-astro-cid-jheqx6ak> <a href="/roi-calculator" class="link" data-astro-cid-jheqx6ak>Get detailed ROI report for your team →</a> </div> </div> <div class="trust-builder" data-astro-cid-jheqx6ak> <p class="trust-text" data-astro-cid-jheqx6ak>Don't trust our numbers? Test them yourself with 25 free verifications.</p> <a href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=web&utm_campaign=accuracy&utm_content=test_accuracy" class="btn-primary" target="_blank" rel="noopener" data-astro-cid-jheqx6ak>Test Our Accuracy Free →</a> </div> </div> </section>  <script type="module">
  window.calculateROI = function calculateROI() {
    var sdrCount = document.getElementById('sdr-count').value;
    var hourlyCost = document.getElementById('hourly-cost').value;
    var hoursWasted = document.getElementById('hours-wasted').value;

    document.getElementById('sdr-display').textContent = sdrCount + ' SDRs';
    document.getElementById('cost-display').textContent = '€' + hourlyCost + '/hour';
    document.getElementById('hours-display').textContent = hoursWasted + ' hours/week';

    var weeklyTimeSaved = sdrCount * hoursWasted;
    var monthlyCostSaved = weeklyTimeSaved * 4 * hourlyCost;
    var roi = Math.round((monthlyCostSaved / 24.50) * 100);

    document.getElementById('time-saved').textContent = weeklyTimeSaved.toFixed(1);
    document.getElementById('money-saved').textContent = monthlyCostSaved.toLocaleString();
    document.getElementById('roi').textContent = roi.toLocaleString();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', window.calculateROI);
  } else {
    window.calculateROI();
  }
<\/script>`])), maybeRenderHead(), addAttribute(`section-padding ${className}`, "class"));
}, "/home/runner/work/landing-page/landing-page/src/components/AccuracySection.astro", void 0);
const $$Astro$9 = createAstro("https://findforce.io");
const $$BlogSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$9, $$props, $$slots);
  Astro2.self = $$BlogSection;
  var { posts, className = "" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section${addAttribute(`section-padding ${className}`, "class")} style="padding: 60px 0; background: #f9fafb" aria-labelledby="blog-heading" data-astro-cid-fjwk6imu> <div class="container" style="max-width: 1000px" data-astro-cid-fjwk6imu> <div style="text-align: center; margin-bottom: 48px" data-astro-cid-fjwk6imu> <h2 id="blog-heading" style="font-size: 32px; font-weight: 700; margin-bottom: 16px" data-astro-cid-fjwk6imu>
Latest Blog Posts
</h2> <p style="font-size: 16px; color: #4b5563" data-astro-cid-fjwk6imu>
Tips, insights, and updates from the FindForce team
</p> </div> ${renderComponent($$result, "BlogContainer", $$BlogContainer, { "posts": posts, "layout": "list", "imagePosition": "left", "showImages": true, "showTags": false, "showAuthor": true, "showDescription": true, "className": "homepage-blog", "data-astro-cid-fjwk6imu": true })} <div style="text-align: center; margin-top: 32px" data-astro-cid-fjwk6imu> <a href="/blog" style="
          display: inline-flex;
          align-items: center;
          color: #1e40af;
          text-decoration: none;
          font-weight: 600;
          font-size: 16px;
          transition: color 0.2s;
          min-height: 44px;
          padding: 8px;
        " class="view-all-link" aria-label="View all blog posts" data-astro-cid-fjwk6imu>
View All Posts
<svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" style="margin-left: 8px" aria-hidden="true" data-astro-cid-fjwk6imu> <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" data-astro-cid-fjwk6imu></path> </svg> </a> </div> </div> </section> `;
}, "/home/runner/work/landing-page/landing-page/src/components/BlogSection.astro", void 0);
const $$Astro$8 = createAstro("https://findforce.io");
const $$FAQSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$8, $$props, $$slots);
  Astro2.self = $$FAQSection;
  var { className = "" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section${addAttribute(`section-padding ${className}`, "class")} style="padding: 80px 0; background: #fff" aria-labelledby="faq-heading"> <div class="container" style="max-width: 800px"> <div style="text-align: center; margin-bottom: 56px"> <h2 id="faq-heading" style="
          font-size: 40px;
          font-weight: 800;
          margin-bottom: 16px;
          color: #111827;
        ">
Frequently Asked Questions
</h2> <p style="font-size: 18px; color: #6b7280">
Everything you need to know about FindForce and how we can help your team close more deals.
</p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"How is €49/mo sustainable? What's the catch?"
</h3> <p style="color: #374151; line-height: 1.7">
No catch. We're profitable from day one with healthy margins.
        Our costs: €0.004 per email verification through our API partners.
        Average user verifies 500 emails/month = €2 cost.
        At €49, we have excellent unit economics while keeping it affordable for you.
        We make money by keeping you as a customer for years, not by nickel-and-diming you with credits.
</p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"What's included in the free tier?"
</h3> <p style="color: #374151; line-height: 1.7"> <strong>25 email verifications per month, forever free.</strong> No credit card required.
        Same 95% accuracy as paid tier. Perfect for freelancers or testing our claims.
        Upgrade when you need more. Downgrade anytime and keep your 25 free verifications.
</p> </div> <!-- Technical & Accuracy Questions --> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"How do you achieve 95% accuracy?"
</h3> <p style="color: #374151; line-height: 1.7"> <strong>Multi-layer verification:</strong><br>
1. <strong>Syntax validation</strong> - Is the format valid?<br>
2. <strong>DNS/MX checks</strong> - Does the domain accept email?<br>
3. <strong>SMTP verification</strong> - Does the mailbox exist?<br>
4. <strong>Pattern intelligence</strong> - We've learned patterns from 10,000+ companies<br>
5. <strong>Third-party validation</strong> - We cross-check with premium APIs<br><br>
If we can't verify with 95% confidence, <strong>we don't return the email.</strong>
Better no result than a bounce that damages your sender reputation.
</p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"How are you different from Hunter.io or Apollo.io?"
</h3> <p style="color: #374151; line-height: 1.7"> <strong>Three key differences:</strong><br>
1. <strong>Pricing:</strong> Flat €24.50-49/mo unlimited vs their credit systems
        (Hunter: 1,000 credits for $49, Apollo: confusing tier system)<br>
2. <strong>Workflow:</strong> One-click on profiles vs copy-paste between tools<br>
3. <strong>Support:</strong> We respond in hours, not days. Try us.<br><br>
We don't have their features bloat. We do one thing exceptionally well: verify emails fast and accurately.
</p> </div> <!-- Compliance & Legal --> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"Is this GDPR compliant?"
</h3> <p style="color: #374151; line-height: 1.7"> <strong>Yes, built-in from day one:</strong><br>
• We only verify publicly available professional information<br>
• No data storage beyond verification<br>
• User-initiated actions only (no automation)<br>
• Hosted in EU (Frankfurt)<br>
• <a href="/dpa" style="color: #3b82f6; text-decoration: underline">DPA available</a><br><br>
Unlike US competitors who bolted on GDPR compliance after fines,
        we built it into our architecture. <a href="/blog/gdpr-email-finder-2025" style="color: #3b82f6; text-decoration: underline">Read our detailed GDPR guide →</a> </p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"Does this work on LinkedIn/Sales Navigator?"
</h3> <p style="color: #374151; line-height: 1.7">
Works on any professional networking site. Users control all actions -
        we're a verification tool, not an automation tool. You click, we verify.
<strong>You're responsible for compliance with platform terms.</strong>
We don't scrape or automate anything.
</p> </div> <!-- Practical Questions --> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"What if I need to verify 10,000 emails this month?"
</h3> <p style="color: #374151; line-height: 1.7">
Go for it. <strong>Unlimited means unlimited.</strong> No throttling, no "fair use" BS.
        Some users verify 50 emails/month, others 5,000+. Same price.
        We make money by keeping you as a customer for years, not by nickel-and-diming you with credits.
</p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"Do you integrate with HubSpot/Salesforce/Pipedrive?"
</h3> <p style="color: #374151; line-height: 1.7"> <strong>HubSpot:</strong> Coming soon...<br> <strong>Salesforce:</strong> (2026)<br> <strong>Pipedrive:</strong> Based on demand<br><br>
For now, export as CSV or use our copy-to-clipboard feature.
        When integrations launch, you get them automatically - no price increase.
</p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"What happens if I cancel and come back?"
</h3> <p style="color: #374151; line-height: 1.7"> <strong>You pay the current price when you return.</strong>
We reserve the right to adjust pricing as we add features and improve the product.
        That said, you can pause your subscription for up to 3 months if needed without losing your current rate.
</p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"How do I know the emails are actually accurate?"
</h3> <p style="color: #374151; line-height: 1.7">
Each email comes with a <strong>confidence score (85-99%).</strong>
We show you exactly why we're confident:<br><br>
✓ SMTP verified<br>✓ Pattern matched<br>✓ MX records valid<br><br>
Still skeptical? Test us with 25 free verifications.
        Check them against your known contacts. If we're wrong, you've lost nothing.
</p> </div> <!-- Business Questions --> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"Can my whole team use one account?"
</h3> <p style="color: #374151; line-height: 1.7"> <strong>No.</strong> We charge per user to keep things simple and fair.
        Each user gets their own account with 25 free verifications/month.
        If you have 5 team members, you need 5 accounts.
        Volume discounts available for 10+ users - <a href="mailto:sales@findforce.io">sales@findforce.io</a>.
</p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"What's your refund policy?"
</h3> <p style="color: #374151; line-height: 1.7"> <strong>7-day money back guarantee.</strong>
Don't like it? One email to <a href="mailto:billing@findforce.io">billing@findforce.io</a> and you get a full refund.
        No retention tactics, no "why are you leaving" surveys.
        We'll ask how we can improve, but your refund is instant regardless of your answer.
</p> </div> <div class="faq-item" style="border-bottom: 2px solid #e5e7eb; padding-bottom: 24px; margin-bottom: 24px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
"Who's behind FindForce?"
</h3> <p style="color: #374151; line-height: 1.7">
We're a small team of engineers who got tired of enterprise software BS.
        No VC funding, no exit strategy, just building a tool we wish existed.
        Headquartered in Estonia (EU), incorporated as Developer Friendly OÜ.
        You can reach our founder directly at <a href="mailto:meysam@findforce.io">meysam@findforce.io</a> - try it.
</p> </div> <!-- ROI Question --> <div style="
        background: #f0f9ff;
        border: 2px solid #3b82f6;
        border-radius: 12px;
        padding: 24px;
        margin-top: 40px;
      "> <h3 style="font-size: 22px; font-weight: 700; margin-bottom: 16px; color: #1e40af">
💰 "What's the actual ROI on €49/month?"
</h3> <div style="color: #1e3a8a; line-height: 1.8; font-size: 16px"> <strong>Let's do the math:</strong><br><br> <strong>Time saved:</strong> 14.5 hours/week per SDR<br> <strong>SDR hourly cost:</strong> ~€25/hour (€50K salary)<br> <strong>Weekly savings:</strong> €362.50 per SDR<br> <strong>Monthly savings:</strong> €1,450 per SDR<br><br> <strong>Your cost:</strong> €49/month<br> <strong>ROI:</strong> 2,959% (€1,450 saved for €49 spent)<br><br>
Even if we're 90% wrong, you still save €145/month.
        The tool pays for itself if it saves you <strong>2 hours per month.</strong> </div> </div> <!-- Final Trust Builder --> <div style="text-align: center; margin-top: 48px; padding: 32px; background: #f9fafb; border-radius: 12px"> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 12px; color: #111827">
Still have questions?
</h3> <p style="color: #6b7280; margin-bottom: 20px">
Email our founder directly: <a href="mailto:meysam@findforce.io" style="color: #1e40af; text-decoration: underline">meysam@findforce.io</a><br>
Average response time: 2 hours (yes, really)
</p> <a href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=web&utm_campaign=faq_cta&utm_content=try_it_free" class="btn-primary" style="
          display: inline-block;
          padding: 14px 28px;
          background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
          color: white;
          border-radius: 8px;
          text-decoration: none;
          font-weight: 600;
          font-size: 16px;
          min-height: 44px;
          line-height: 1.4;
        " target="_blank" rel="noopener" aria-label="Try FindForce free - Opens Chrome Web Store">
Try It Free - No Card Required →
</a> </div> </div> </section>`;
}, "/home/runner/work/landing-page/landing-page/src/components/FAQSection.astro", void 0);
const $$Astro$7 = createAstro("https://findforce.io");
const $$FeaturedTestimonialSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$7, $$props, $$slots);
  Astro2.self = $$FeaturedTestimonialSection;
  var { headline = "Trusted by Sales Professionals Who Need Results" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section class="featured-testimonial-section" data-astro-cid-n2lcwae5> <div class="container" data-astro-cid-n2lcwae5> <h2 class="section-headline" data-astro-cid-n2lcwae5>${headline}</h2> <div class="testimonial-card" data-astro-cid-n2lcwae5> <!-- Chrome Web Store Badge --> <div class="badge-container" data-astro-cid-n2lcwae5> <div class="chrome-badge" data-astro-cid-n2lcwae5> <svg class="chrome-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" data-astro-cid-n2lcwae5> <circle cx="12" cy="12" r="10" fill="#4285F4" data-astro-cid-n2lcwae5></circle> <circle cx="12" cy="12" r="7" fill="white" data-astro-cid-n2lcwae5></circle> <circle cx="12" cy="12" r="4" fill="#4285F4" data-astro-cid-n2lcwae5></circle> <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z" fill="#EA4335" data-astro-cid-n2lcwae5></path> <path d="M12 7c-2.76 0-5 2.24-5 5s2.24 5 5 5 5-2.24 5-5-2.24-5-5-5zm0 8c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3z" fill="#FBBC04" data-astro-cid-n2lcwae5></path> </svg> <span class="badge-text" data-astro-cid-n2lcwae5>Chrome Web Store</span> </div> <div class="rating" data-astro-cid-n2lcwae5> <div class="stars" aria-label="5 out of 5 stars" data-astro-cid-n2lcwae5> <svg class="star" width="16" height="16" viewBox="0 0 24 24" fill="#FBBC04" data-astro-cid-n2lcwae5> <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" data-astro-cid-n2lcwae5></path> </svg> <svg class="star" width="16" height="16" viewBox="0 0 24 24" fill="#FBBC04" data-astro-cid-n2lcwae5> <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" data-astro-cid-n2lcwae5></path> </svg> <svg class="star" width="16" height="16" viewBox="0 0 24 24" fill="#FBBC04" data-astro-cid-n2lcwae5> <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" data-astro-cid-n2lcwae5></path> </svg> <svg class="star" width="16" height="16" viewBox="0 0 24 24" fill="#FBBC04" data-astro-cid-n2lcwae5> <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" data-astro-cid-n2lcwae5></path> </svg> <svg class="star" width="16" height="16" viewBox="0 0 24 24" fill="#FBBC04" data-astro-cid-n2lcwae5> <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" data-astro-cid-n2lcwae5></path> </svg> </div> <span class="rating-text" data-astro-cid-n2lcwae5>5.0</span> </div> </div> <!-- Testimonial Content --> <div class="testimonial-content" data-astro-cid-n2lcwae5> <div class="quote-icon" aria-hidden="true" data-astro-cid-n2lcwae5>"</div> <blockquote data-astro-cid-n2lcwae5> <p class="testimonial-text" data-astro-cid-n2lcwae5> <span class="highlight" data-astro-cid-n2lcwae5>This is the best email verifying system by far</span>... It have helped me so many times when I got stuck on a client detail.
</p> </blockquote> </div> <!-- Author Info --> <div class="author-section" data-astro-cid-n2lcwae5> <div class="author-avatar" data-astro-cid-n2lcwae5> <img src="/testimonials/emmanuel-eze.jpg" alt="Emmanuel Eze" width="64" height="64" loading="lazy" decoding="async" data-astro-cid-n2lcwae5> </div> <div class="author-info" data-astro-cid-n2lcwae5> <div class="author-name" data-astro-cid-n2lcwae5>Emmanuel (Ebubechukwu) Eze</div> <div class="author-title" data-astro-cid-n2lcwae5>Sales Development Representative</div> <div class="author-company" data-astro-cid-n2lcwae5>FieldAssist</div> </div> </div> </div> </div> </section> `;
}, "/home/runner/work/landing-page/landing-page/src/components/FeaturedTestimonialSection.astro", void 0);
const $$Astro$6 = createAstro("https://findforce.io");
const $$FinalCTA = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$6, $$props, $$slots);
  Astro2.self = $$FinalCTA;
  var { className = "" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section${addAttribute(`section-padding ${className}`, "class")} style="
    padding: 100px 0;
    background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #2563eb 100%);
    position: relative;
    overflow: hidden;
  " aria-labelledby="final-cta-heading"> <!-- Background Pattern --> <div style="
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      opacity: 0.1;
      background-image: repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(255,255,255,.5) 35px, rgba(255,255,255,.5) 70px);
    "></div> <div class="container" style="text-align: center; position: relative; z-index: 1"> <!-- Decision Time Header --> <div style="
        display: inline-block;
        background: #fbbf24;
        color: #78350f;
        padding: 8px 20px;
        border-radius: 30px;
        font-size: 13px;
        font-weight: 700;
        margin-bottom: 24px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
      ">
Ready to Save Time?
</div> <h2 id="final-cta-heading" style="
        font-size: 48px;
        font-weight: 800;
        color: white;
        margin-bottom: 24px;
        max-width: 800px;
        margin-left: auto;
        margin-right: auto;
        line-height: 1.1;
      ">
Your SDRs Will Either Waste Tomorrow
<br>Or Start Closing More Deals
</h2> <p style="
        font-size: 20px;
        color: #dbeafe;
        margin-bottom: 40px;
        max-width: 700px;
        margin-left: auto;
        margin-right: auto;
        line-height: 1.5;
      ">
Every day without FindForce, your team wastes <strong>2.9 hours</strong> on manual prospecting.
      That's <strong>€72.50 in lost productivity.</strong> Per SDR. Per day.
</p> <!-- The Choice --> <div style="
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 32px;
        max-width: 900px;
        margin: 0 auto 48px auto;
      "> <!-- Option 1: Do Nothing --> <div style="
          background: rgba(255, 255, 255, 0.1);
          border: 2px solid rgba(255, 255, 255, 0.2);
          border-radius: 16px;
          padding: 32px;
          text-align: left;
        "> <h3 style="color: #fbbf24; font-size: 20px; font-weight: 700; margin-bottom: 16px">
Keep the Status Quo
</h3> <ul style="list-style: none; padding: 0; color: #cbd5e1; font-size: 15px; line-height: 1.8"> <li style="margin-bottom: 8px">❌ Keep wasting 14.5 hours/week</li> <li style="margin-bottom: 8px">❌ Keep bouncing 20-30% of emails</li> <li style="margin-bottom: 8px">❌ Keep paying $300/mo for complex tools</li> <li style="margin-bottom: 8px">❌ Keep losing deals to faster competitors</li> </ul> <p style="color: #94a3b8; font-size: 14px; margin-top: 16px; font-style: italic">
Cost: €1,450/month in lost productivity
</p> </div> <!-- Option 2: Try FindForce --> <div style="
          background: rgba(255, 255, 255, 0.95);
          border: 3px solid #fbbf24;
          border-radius: 16px;
          padding: 32px;
          text-align: left;
          transform: scale(1.02);
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        "> <h3 style="color: #059669; font-size: 20px; font-weight: 700; margin-bottom: 16px">
Try FindForce Risk-Free
</h3> <ul style="list-style: none; padding: 0; color: #1e293b; font-size: 15px; line-height: 1.8"> <li style="margin-bottom: 8px">✅ Get verified emails in seconds</li> <li style="margin-bottom: 8px">✅ Achieve 95% accuracy (guaranteed)</li> <li style="margin-bottom: 8px">✅ Unlimited verifications for €49/mo</li> <li style="margin-bottom: 8px">✅ 7-day money back if not satisfied</li> </ul> <p style="color: #059669; font-size: 14px; margin-top: 16px; font-weight: 600">
Investment: €49/month (€1.63/day)
</p> </div> </div> <!-- Guarantee Box --> <div style="
        background: rgba(255, 255, 255, 0.15);
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 16px;
        padding: 32px;
        max-width: 700px;
        margin: 0 auto 40px auto;
      "> <h3 style="color: #fbbf24; font-size: 24px; font-weight: 700; margin-bottom: 16px">
Our Promise to You
</h3> <p style="color: white; font-size: 18px; line-height: 1.6; margin-bottom: 16px">
Try FindForce for 7 days. If we don't deliver <strong>95% accuracy</strong> or
        save you <strong>at least 10 hours</strong> in your first week,
        email us for an <strong>instant, no-questions-asked refund.</strong> </p> <p style="color: #cbd5e1; font-size: 14px">
We're that confident you'll love it.
</p> </div> <!-- Final CTA Buttons --> <div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap; margin-bottom: 32px"> <a href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=web&utm_campaign=final_cta&utm_content=get_started" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="index_final_cta"${addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url")} data-pirsch-non-interactive class="btn-primary" style="
          font-size: 20px;
          padding: 20px 40px;
          background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
          color: #78350f;
          border: none;
          border-radius: 8px;
          text-decoration: none;
          display: inline-block;
          font-weight: 800;
          box-shadow: 0 4px 20px rgba(251, 191, 36, 0.4);
          transition: all 0.3s ease;
        " target="_blank" rel="noopener" aria-label="Get FindForce now">
Get Started Now →
</a> <a href="#pricing" class="btn-secondary" style="
          font-size: 18px;
          padding: 20px 32px;
          background: transparent;
          color: white;
          border: 2px solid white;
          border-radius: 8px;
          text-decoration: none;
          display: inline-block;
          font-weight: 600;
          transition: all 0.3s ease;
        ">
See Pricing Details
</a> </div> <!-- Questions --> <div style="margin-top: 48px"> <p style="color: #cbd5e1; font-size: 16px; margin-bottom: 8px">
Questions? We're here to help:
</p> <a href="mailto:support@findforce.io" style="color: #fbbf24; font-size: 18px; font-weight: 600; text-decoration: underline">
support@findforce.io
</a> </div> <!-- PS Section --> <div style="
        margin-top: 64px;
        padding-top: 32px;
        border-top: 1px solid rgba(255, 255, 255, 0.2);
      "> <p style="color: #cbd5e1; font-size: 14px; font-style: italic; max-width: 600px; margin: 0 auto"> <strong>P.S.</strong> Your competitors are already using email finders.
        The only question is whether they're wasting time with the wrong one,
        or closing deals with FindForce. Which side do you want to be on?
</p> </div> </div> </section>`;
}, "/home/runner/work/landing-page/landing-page/src/components/FinalCTA.astro", void 0);
const $$Astro$5 = createAstro("https://findforce.io");
const $$GuaranteeSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$5, $$props, $$slots);
  Astro2.self = $$GuaranteeSection;
  var { className = "" } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section id="guarantee"${addAttribute(`section-padding ${className}`, "class")} style="padding: 60px 0; background: #fff" aria-labelledby="guarantee-heading"> <div class="container" style="text-align: center"> <h2 id="guarantee-heading" style="font-size: 32px; font-weight: 700; margin-bottom: 40px">
The Only Guarantee That Matters
</h2> <div class="stats-grid" style="
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 24px;
        max-width: 900px;
        margin: 0 auto;
      " role="list"> <div style="background: #f3f4f6; padding: 32px; border-radius: 12px" role="listitem"> <div style="
            font-size: 48px;
            font-weight: 800;
            color: #2563eb;
            margin-bottom: 8px;
          " aria-label="95 percent">
95%
</div> <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px">
Accuracy Rate
</div> <div style="font-size: 14px; color: #4b5563">
Or we refund you. Period.
</div> </div> <div style="background: #f3f4f6; padding: 32px; border-radius: 12px" role="listitem"> <div style="
            font-size: 48px;
            font-weight: 800;
            color: #10b981;
            margin-bottom: 8px;
          " aria-label="24 hours 7 days">
24/7
</div> <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px">
Real Human Support
</div> <div style="font-size: 14px; color: #4b5563">
We answer in minutes, not days
</div> </div> <div style="background: #f3f4f6; padding: 32px; border-radius: 12px" role="listitem"> <div style="
            font-size: 48px;
            font-weight: 800;
            color: #7c3aed;
            margin-bottom: 8px;
          " aria-label="Infinite">
∞
</div> <div style="font-size: 18px; font-weight: 600; margin-bottom: 8px">
No Limits
</div> <div style="font-size: 14px; color: #4b5563">
Unlimited verifications.<br>No BS credits.
</div> </div> </div> <div style="
        background: #1a1a1a;
        color: white;
        padding: 40px;
        border-radius: 12px;
        margin-top: 48px;
        max-width: 700px;
        margin-left: auto;
        margin-right: auto;
      "> <h3 style="font-size: 20px; font-weight: 600; margin-bottom: 16px">
Our Promise to You
</h3> <p style="font-size: 16px; opacity: 0.9">
If FindForce doesn't deliver 95% accuracy on your verified emails,
        we'll refund you instantly. No forms. No "talk to sales." Just email
        us, get your money back. That's how confident we are.
</p> </div> </div> </section>`;
}, "/home/runner/work/landing-page/landing-page/src/components/GuaranteeSection.astro", void 0);
const $$TrustSignal = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="trust-signal" style="
    display: inline-flex;
    align-items: center;
    padding: 10px 24px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 32px;
    background: linear-gradient(135deg, #d1fae5 0%, #a7f3d0 100%);
    color: #065f46;
    border: 1px solid #10b981;
  " data-astro-cid-snqcz7ti> <svg class="trust-icon" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style="margin-right: 8px; flex-shrink: 0;" aria-hidden="true" data-astro-cid-snqcz7ti> <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z" data-astro-cid-snqcz7ti></path> </svg>
95% accuracy guaranteed. 7-day money back. Cancel anytime.
</div> `;
}, "/home/runner/work/landing-page/landing-page/src/components/hero/TrustSignal.astro", void 0);
const $$HeroContent = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<h1 id="hero-heading" class="hero-title" style="
    font-size: 56px;
    font-weight: 900;
    line-height: 1.05;
    margin-bottom: 24px;
    max-width: 1000px;
    margin-left: auto;
    margin-right: auto;
    color: #111827;
  " data-astro-cid-qncwqnf4>
Get Verified Business Emails in
<span style="
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      display: inline-block;
    " data-astro-cid-qncwqnf4>
5 Seconds
</span> <br data-astro-cid-qncwqnf4>
Not 5 Minutes.
</h1> <p class="hero-subtitle" style="
    font-size: 22px;
    color: #4b5563;
    margin-bottom: 32px;
    max-width: 720px;
    margin-left: auto;
    margin-right: auto;
    line-height: 1.5;
  " data-astro-cid-qncwqnf4>
Your SDRs waste <strong data-astro-cid-qncwqnf4>14.5 hours per week</strong> jumping between LinkedIn,
  email finders, and your CRM. FindForce does it in one click.
<span style="color: #059669; font-weight: 600" data-astro-cid-qncwqnf4>95% accuracy guaranteed</span> or instant refund.
</p> <div style="
    background: linear-gradient(135deg, #dbeafe 0%, #bfdbfe 100%);
    border: 2px solid #3b82f6;
    border-radius: 12px;
    padding: 16px 24px;
    max-width: 600px;
    margin: 0 auto 32px auto;
  " data-astro-cid-qncwqnf4> <p style="
      font-size: 18px;
      color: #1e40af;
      font-weight: 700;
      margin: 0;
    " data-astro-cid-qncwqnf4>
⚡ Unlimited verifications for €49/mo
</p> <p style="
      font-size: 14px;
      color: #1e3a8a;
      margin: 8px 0 0 0;
    " data-astro-cid-qncwqnf4>
No credits. No limits. No BS. Just results.
</p> </div> `;
}, "/home/runner/work/landing-page/landing-page/src/components/hero/HeroContent.astro", void 0);
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$Astro$4 = createAstro("https://findforce.io");
const $$DemoSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$4, $$props, $$slots);
  Astro2.self = $$DemoSection;
  var { videoUrl } = Astro2.props;
  return renderTemplate(_a || (_a = __template(["", '<div class="demo-section" data-astro-cid-daeghsmi> <div class="demo-tabs" role="tablist" aria-label="Demo content tabs" data-astro-cid-daeghsmi> <button class="demo-tab active" data-tab="quick" role="tab" aria-selected="true" aria-controls="demo-quick" id="tab-quick" data-astro-cid-daeghsmi>\n⚡ See it in 10 seconds\n</button> <button class="demo-tab" data-tab="video" role="tab" aria-selected="false" aria-controls="demo-video" id="tab-video" data-astro-cid-daeghsmi>\n🎥 Watch 2-min demo\n</button> </div> <div class="demo-content-container" data-astro-cid-daeghsmi> <div id="demo-quick" class="demo-content active" role="tabpanel" aria-labelledby="tab-quick" tabindex="0" data-astro-cid-daeghsmi> <div class="svg-carousel" role="region" aria-label="Demo workflow carousel" data-astro-cid-daeghsmi> <img src="/demo-finder-page.svg" alt="FindForce workflow - Step 1: Email finder interface showing search results" class="demo-svg active zoomable" width="800" height="600" loading="lazy" data-astro-cid-daeghsmi> <img src="/demo-history-page.svg" alt="FindForce workflow - Step 2: Search history showing verified email results" class="demo-svg zoomable" width="800" height="600" loading="lazy" data-astro-cid-daeghsmi> <div class="carousel-controls" role="group" aria-label="Carousel navigation" data-astro-cid-daeghsmi> <button class="carousel-dot active" data-slide="0" aria-label="Show slide 1" aria-pressed="true" data-astro-cid-daeghsmi></button> <button class="carousel-dot" data-slide="1" aria-label="Show slide 2" aria-pressed="false" data-astro-cid-daeghsmi></button> </div> <button class="carousel-prev" aria-label="Previous slide" data-astro-cid-daeghsmi> <svg width="20" height="20" viewBox="0 0 20 20" fill="#374151" aria-hidden="true" data-astro-cid-daeghsmi> <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" data-astro-cid-daeghsmi></path> </svg> </button> <button class="carousel-next" aria-label="Next slide" data-astro-cid-daeghsmi> <svg width="20" height="20" viewBox="0 0 20 20" fill="#374151" aria-hidden="true" data-astro-cid-daeghsmi> <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" data-astro-cid-daeghsmi></path> </svg> </button> </div> <p class="demo-hint" data-astro-cid-daeghsmi>Click the images to zoom in • Swipe on mobile</p> </div> <div id="demo-video" class="demo-content" role="tabpanel" aria-labelledby="tab-video" tabindex="0" data-astro-cid-daeghsmi> <div class="video-wrapper" data-astro-cid-daeghsmi> <div class="video-container" data-astro-cid-daeghsmi> <button id="video-placeholder" class="video-placeholder" aria-label="Open FindForce demo video in new window - 2 minute demonstration"', ' data-video-title="FindForce Demo Video - See how to find emails in 2 minutes" data-astro-cid-daeghsmi> <div class="video-placeholder-content" data-astro-cid-daeghsmi> <div class="play-button" aria-hidden="true" data-astro-cid-daeghsmi> <svg width="32" height="32" viewBox="0 0 24 24" fill="white" aria-hidden="true" data-astro-cid-daeghsmi> <path d="M8 5v14l11-7z" data-astro-cid-daeghsmi></path> </svg> </div> <p class="video-title" data-astro-cid-daeghsmi>Click to Open Video</p> <p class="video-subtitle" data-astro-cid-daeghsmi>\n2 minute demo - Opens in new window\n</p> </div> </button> </div> </div> </div> </div> </div> <div id="zoom-modal" class="zoom-modal" data-astro-cid-daeghsmi> <div class="zoom-content" data-astro-cid-daeghsmi> <button id="zoom-close" class="zoom-close" aria-label="Close zoom view" data-astro-cid-daeghsmi>×</button> <img id="zoom-image" src="" alt="" class="zoom-image" data-astro-cid-daeghsmi> </div> </div>  <script type="module">\n  var currentSlide = 0;\n  var slides = document.querySelectorAll(".demo-svg");\n  var dots = document.querySelectorAll(".carousel-dot");\n  var videoLoaded = false;\n  var autoSlideInterval;\n  var videoObserver;\n  var activeTab = "quick";\n\n  function updateSlide(index) {\n    slides.forEach(function handleSlide(slide, slideIndex) {\n      if (slideIndex === index) {\n        slide.classList.add("active");\n      } else {\n        slide.classList.remove("active");\n      }\n    });\n\n    dots.forEach(function handleDot(dot, dotIndex) {\n      if (dotIndex === index) {\n        dot.classList.add("active");\n        dot.setAttribute("aria-pressed", "true");\n      } else {\n        dot.classList.remove("active");\n        dot.setAttribute("aria-pressed", "false");\n      }\n    });\n\n    currentSlide = index;\n  }\n\n  function nextSlide() {\n    var next = (currentSlide + 1) % slides.length;\n    updateSlide(next);\n  }\n\n  function previousSlide() {\n    var prev = (currentSlide - 1 + slides.length) % slides.length;\n    updateSlide(prev);\n  }\n\n  function nextSlideManual() {\n    nextSlide();\n    startAutoSlide();\n  }\n\n  function previousSlideManual() {\n    previousSlide();\n    startAutoSlide();\n  }\n\n  function startAutoSlide() {\n    stopAutoSlide();\n    if (activeTab === "quick") {\n      autoSlideInterval = setInterval(nextSlide, 7000);\n    }\n  }\n\n  function stopAutoSlide() {\n    if (autoSlideInterval) {\n      clearInterval(autoSlideInterval);\n      autoSlideInterval = null;\n    }\n  }\n\n  function switchDemoTab(tabName) {\n    activeTab = tabName;\n\n    document.querySelectorAll(".demo-tab").forEach(function handleTab(tab) {\n      var isActive = tab.dataset.tab === tabName;\n      tab.setAttribute("aria-selected", isActive.toString());\n      tab.classList.toggle("active", isActive);\n    });\n\n    document.querySelectorAll(".demo-content").forEach(function handleContent(content) {\n      content.classList.remove("active");\n    });\n\n    requestAnimationFrame(function showActiveContent() {\n      var activeContent = document.getElementById(`demo-${tabName}`);\n      if (activeContent) {\n        activeContent.classList.add("active");\n        activeContent.focus();\n      }\n    });\n\n    if (tabName === "quick") {\n      startAutoSlide();\n      stopVideo();\n    } else if (tabName === "video") {\n      stopAutoSlide();\n    }\n  }\n\n  function loadVideo() {\n    if (activeTab !== "video") return;\n\n    var placeholder = document.getElementById("video-placeholder");\n    var videoUrl = placeholder?.dataset.videoUrl;\n\n    if (!videoUrl || !placeholder) return;\n\n    var isScreenStudio =\n      videoUrl.includes("screen.studio") || videoUrl.includes("screencast");\n\n    if (isScreenStudio) {\n      window.open(videoUrl, \'_blank\', \'noopener,noreferrer\');\n      return;\n    }\n\n    if (videoLoaded) return;\n\n    var videoTitle = placeholder?.dataset.videoTitle;\n\n    var iframe = document.createElement("iframe");\n    iframe.id = "demo-video-iframe";\n    iframe.src = videoUrl;\n\n    iframe.style.cssText = `\n      position: absolute;\n      top: 0;\n      left: 0;\n      width: 100%;\n      height: 100%;\n      border: none;\n      border-radius: 12px;\n      z-index: 1;\n      pointer-events: auto;\n      background: white;\n    `;\n\n    iframe.title = videoTitle || "FindForce Demo Video";\n    iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen";\n    iframe.allowFullscreen = true;\n    iframe.setAttribute("allowfullscreen", "");\n    iframe.setAttribute("webkitallowfullscreen", "");\n    iframe.setAttribute("mozallowfullscreen", "");\n    iframe.setAttribute("frameborder", "0");\n    iframe.setAttribute("scrolling", "no");\n\n    iframe.onload = function () {\n      iframe.style.pointerEvents = "auto";\n      placeholder.style.display = "none";\n      videoLoaded = true;\n\n      if (videoObserver) {\n        videoObserver.disconnect();\n      }\n    };\n\n    placeholder.parentNode.appendChild(iframe);\n  }\n\n  function stopVideo() {\n    var iframe = document.getElementById("demo-video-iframe");\n    if (iframe) {\n      iframe.remove();\n\n      var placeholder = document.getElementById("video-placeholder");\n      if (placeholder) {\n        placeholder.style.display = "flex";\n      }\n\n      videoLoaded = false;\n    }\n  }\n\n  function openZoom(imageSrc, imageAlt) {\n    const modal = document.getElementById("zoom-modal");\n    const zoomImage = document.getElementById("zoom-image");\n\n    if (zoomImage && modal) {\n      zoomImage.src = imageSrc;\n      zoomImage.alt = imageAlt;\n      modal.style.display = "block";\n      document.body.style.overflow = "hidden";\n      stopAutoSlide();\n    }\n  }\n\n  function closeZoom() {\n    const modal = document.getElementById("zoom-modal");\n    if (modal) {\n      modal.style.display = "none";\n      document.body.style.overflow = "";\n      // Only restart auto-slide if we\'re on the quick tab\n      if (activeTab === "quick") {\n        startAutoSlide();\n      }\n    }\n  }\n\n  // Event handlers\n  function onTabClick(e) {\n    var button = e.currentTarget;\n    button.style.transform = "scale(0.98)";\n    setTimeout(function resetButtonScale() {\n      button.style.transform = "scale(1)";\n    }, 150);\n    switchDemoTab(button.dataset.tab);\n  }\n\n  function onDotClick(e) {\n    updateSlide(parseInt(e.currentTarget.dataset.slide, 10));\n    startAutoSlide();\n  }\n\n  function onImageClick(e) {\n    openZoom(e.currentTarget.src, e.currentTarget.alt);\n  }\n\n  function onDocumentKeydown(e) {\n    if (e.key === "Escape") {\n      closeZoom();\n    }\n  }\n\n  // Initialize on DOM ready\n  document.addEventListener("DOMContentLoaded", function initializeDemoSection() {\n    document.querySelectorAll(".demo-tab").forEach(function setupTab(tab) {\n      tab.addEventListener("click", onTabClick);\n      tab.addEventListener("keydown", function handleTabKeydown(e) {\n        if (e.key === "ArrowLeft" || e.key === "ArrowRight") {\n          e.preventDefault();\n          var tabs = Array.from(document.querySelectorAll(".demo-tab"));\n          var currentIndex = tabs.indexOf(tab);\n          var nextIndex =\n            e.key === "ArrowRight"\n              ? (currentIndex + 1) % tabs.length\n              : (currentIndex - 1 + tabs.length) % tabs.length;\n          tabs[nextIndex].focus();\n          tabs[nextIndex].click();\n        }\n      });\n    });\n\n    document.querySelectorAll(".carousel-dot").forEach(function setupDot(dot) {\n      dot.addEventListener("click", onDotClick);\n    });\n\n    const prevBtn = document.querySelector(".carousel-prev");\n    const nextBtn = document.querySelector(".carousel-next");\n\n    if (prevBtn) prevBtn.addEventListener("click", previousSlideManual);\n    if (nextBtn) nextBtn.addEventListener("click", nextSlideManual);\n\n    // Video placeholder\n    const videoPlaceholder = document.getElementById("video-placeholder");\n    if (videoPlaceholder) {\n      videoPlaceholder.addEventListener("click", loadVideo);\n      videoPlaceholder.addEventListener("keydown", (e) => {\n        if (e.key === "Enter" || e.key === " ") {\n          e.preventDefault();\n          loadVideo();\n        }\n      });\n    }\n\n    // Zoomable images\n    document.querySelectorAll(".zoomable").forEach(function setupZoomable(img) {\n      img.addEventListener("click", onImageClick);\n      img.addEventListener("keydown", function handleImageKeydown(e) {\n        if (e.key === "Enter" || e.key === " ") {\n          e.preventDefault();\n          openZoom(img.src, img.alt);\n        }\n      });\n    });\n\n    // Zoom modal\n    const zoomModal = document.getElementById("zoom-modal");\n    const zoomClose = document.getElementById("zoom-close");\n\n    if (zoomModal) zoomModal.addEventListener("click", closeZoom);\n    if (zoomClose) {\n      zoomClose.addEventListener("click", (e) => {\n        e.stopPropagation();\n        closeZoom();\n      });\n    }\n\n    document.addEventListener("keydown", onDocumentKeydown);\n\n    // Start auto-slide for default tab\n    startAutoSlide();\n\n    // Touch support for mobile swipe\n    let touchStartX = 0;\n    let touchEndX = 0;\n\n    const carousel = document.querySelector(".svg-carousel");\n    if (carousel) {\n      carousel.addEventListener("touchstart", function handleTouchStart(e) {\n        touchStartX = e.changedTouches[0].screenX;\n      });\n\n      carousel.addEventListener("touchend", function handleTouchEnd(e) {\n        touchEndX = e.changedTouches[0].screenX;\n        handleSwipe();\n      });\n    }\n\n    function handleSwipe() {\n      var swipeThreshold = 50;\n      var diff = touchStartX - touchEndX;\n\n      if (Math.abs(diff) > swipeThreshold) {\n        if (diff > 0) {\n          nextSlideManual();\n        } else {\n          previousSlideManual();\n        }\n      }\n    }\n  });\n<\/script>'], ["", '<div class="demo-section" data-astro-cid-daeghsmi> <div class="demo-tabs" role="tablist" aria-label="Demo content tabs" data-astro-cid-daeghsmi> <button class="demo-tab active" data-tab="quick" role="tab" aria-selected="true" aria-controls="demo-quick" id="tab-quick" data-astro-cid-daeghsmi>\n⚡ See it in 10 seconds\n</button> <button class="demo-tab" data-tab="video" role="tab" aria-selected="false" aria-controls="demo-video" id="tab-video" data-astro-cid-daeghsmi>\n🎥 Watch 2-min demo\n</button> </div> <div class="demo-content-container" data-astro-cid-daeghsmi> <div id="demo-quick" class="demo-content active" role="tabpanel" aria-labelledby="tab-quick" tabindex="0" data-astro-cid-daeghsmi> <div class="svg-carousel" role="region" aria-label="Demo workflow carousel" data-astro-cid-daeghsmi> <img src="/demo-finder-page.svg" alt="FindForce workflow - Step 1: Email finder interface showing search results" class="demo-svg active zoomable" width="800" height="600" loading="lazy" data-astro-cid-daeghsmi> <img src="/demo-history-page.svg" alt="FindForce workflow - Step 2: Search history showing verified email results" class="demo-svg zoomable" width="800" height="600" loading="lazy" data-astro-cid-daeghsmi> <div class="carousel-controls" role="group" aria-label="Carousel navigation" data-astro-cid-daeghsmi> <button class="carousel-dot active" data-slide="0" aria-label="Show slide 1" aria-pressed="true" data-astro-cid-daeghsmi></button> <button class="carousel-dot" data-slide="1" aria-label="Show slide 2" aria-pressed="false" data-astro-cid-daeghsmi></button> </div> <button class="carousel-prev" aria-label="Previous slide" data-astro-cid-daeghsmi> <svg width="20" height="20" viewBox="0 0 20 20" fill="#374151" aria-hidden="true" data-astro-cid-daeghsmi> <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" data-astro-cid-daeghsmi></path> </svg> </button> <button class="carousel-next" aria-label="Next slide" data-astro-cid-daeghsmi> <svg width="20" height="20" viewBox="0 0 20 20" fill="#374151" aria-hidden="true" data-astro-cid-daeghsmi> <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" data-astro-cid-daeghsmi></path> </svg> </button> </div> <p class="demo-hint" data-astro-cid-daeghsmi>Click the images to zoom in • Swipe on mobile</p> </div> <div id="demo-video" class="demo-content" role="tabpanel" aria-labelledby="tab-video" tabindex="0" data-astro-cid-daeghsmi> <div class="video-wrapper" data-astro-cid-daeghsmi> <div class="video-container" data-astro-cid-daeghsmi> <button id="video-placeholder" class="video-placeholder" aria-label="Open FindForce demo video in new window - 2 minute demonstration"', ' data-video-title="FindForce Demo Video - See how to find emails in 2 minutes" data-astro-cid-daeghsmi> <div class="video-placeholder-content" data-astro-cid-daeghsmi> <div class="play-button" aria-hidden="true" data-astro-cid-daeghsmi> <svg width="32" height="32" viewBox="0 0 24 24" fill="white" aria-hidden="true" data-astro-cid-daeghsmi> <path d="M8 5v14l11-7z" data-astro-cid-daeghsmi></path> </svg> </div> <p class="video-title" data-astro-cid-daeghsmi>Click to Open Video</p> <p class="video-subtitle" data-astro-cid-daeghsmi>\n2 minute demo - Opens in new window\n</p> </div> </button> </div> </div> </div> </div> </div> <div id="zoom-modal" class="zoom-modal" data-astro-cid-daeghsmi> <div class="zoom-content" data-astro-cid-daeghsmi> <button id="zoom-close" class="zoom-close" aria-label="Close zoom view" data-astro-cid-daeghsmi>×</button> <img id="zoom-image" src="" alt="" class="zoom-image" data-astro-cid-daeghsmi> </div> </div>  <script type="module">\n  var currentSlide = 0;\n  var slides = document.querySelectorAll(".demo-svg");\n  var dots = document.querySelectorAll(".carousel-dot");\n  var videoLoaded = false;\n  var autoSlideInterval;\n  var videoObserver;\n  var activeTab = "quick";\n\n  function updateSlide(index) {\n    slides.forEach(function handleSlide(slide, slideIndex) {\n      if (slideIndex === index) {\n        slide.classList.add("active");\n      } else {\n        slide.classList.remove("active");\n      }\n    });\n\n    dots.forEach(function handleDot(dot, dotIndex) {\n      if (dotIndex === index) {\n        dot.classList.add("active");\n        dot.setAttribute("aria-pressed", "true");\n      } else {\n        dot.classList.remove("active");\n        dot.setAttribute("aria-pressed", "false");\n      }\n    });\n\n    currentSlide = index;\n  }\n\n  function nextSlide() {\n    var next = (currentSlide + 1) % slides.length;\n    updateSlide(next);\n  }\n\n  function previousSlide() {\n    var prev = (currentSlide - 1 + slides.length) % slides.length;\n    updateSlide(prev);\n  }\n\n  function nextSlideManual() {\n    nextSlide();\n    startAutoSlide();\n  }\n\n  function previousSlideManual() {\n    previousSlide();\n    startAutoSlide();\n  }\n\n  function startAutoSlide() {\n    stopAutoSlide();\n    if (activeTab === "quick") {\n      autoSlideInterval = setInterval(nextSlide, 7000);\n    }\n  }\n\n  function stopAutoSlide() {\n    if (autoSlideInterval) {\n      clearInterval(autoSlideInterval);\n      autoSlideInterval = null;\n    }\n  }\n\n  function switchDemoTab(tabName) {\n    activeTab = tabName;\n\n    document.querySelectorAll(".demo-tab").forEach(function handleTab(tab) {\n      var isActive = tab.dataset.tab === tabName;\n      tab.setAttribute("aria-selected", isActive.toString());\n      tab.classList.toggle("active", isActive);\n    });\n\n    document.querySelectorAll(".demo-content").forEach(function handleContent(content) {\n      content.classList.remove("active");\n    });\n\n    requestAnimationFrame(function showActiveContent() {\n      var activeContent = document.getElementById(\\`demo-\\${tabName}\\`);\n      if (activeContent) {\n        activeContent.classList.add("active");\n        activeContent.focus();\n      }\n    });\n\n    if (tabName === "quick") {\n      startAutoSlide();\n      stopVideo();\n    } else if (tabName === "video") {\n      stopAutoSlide();\n    }\n  }\n\n  function loadVideo() {\n    if (activeTab !== "video") return;\n\n    var placeholder = document.getElementById("video-placeholder");\n    var videoUrl = placeholder?.dataset.videoUrl;\n\n    if (!videoUrl || !placeholder) return;\n\n    var isScreenStudio =\n      videoUrl.includes("screen.studio") || videoUrl.includes("screencast");\n\n    if (isScreenStudio) {\n      window.open(videoUrl, \'_blank\', \'noopener,noreferrer\');\n      return;\n    }\n\n    if (videoLoaded) return;\n\n    var videoTitle = placeholder?.dataset.videoTitle;\n\n    var iframe = document.createElement("iframe");\n    iframe.id = "demo-video-iframe";\n    iframe.src = videoUrl;\n\n    iframe.style.cssText = \\`\n      position: absolute;\n      top: 0;\n      left: 0;\n      width: 100%;\n      height: 100%;\n      border: none;\n      border-radius: 12px;\n      z-index: 1;\n      pointer-events: auto;\n      background: white;\n    \\`;\n\n    iframe.title = videoTitle || "FindForce Demo Video";\n    iframe.allow = "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen";\n    iframe.allowFullscreen = true;\n    iframe.setAttribute("allowfullscreen", "");\n    iframe.setAttribute("webkitallowfullscreen", "");\n    iframe.setAttribute("mozallowfullscreen", "");\n    iframe.setAttribute("frameborder", "0");\n    iframe.setAttribute("scrolling", "no");\n\n    iframe.onload = function () {\n      iframe.style.pointerEvents = "auto";\n      placeholder.style.display = "none";\n      videoLoaded = true;\n\n      if (videoObserver) {\n        videoObserver.disconnect();\n      }\n    };\n\n    placeholder.parentNode.appendChild(iframe);\n  }\n\n  function stopVideo() {\n    var iframe = document.getElementById("demo-video-iframe");\n    if (iframe) {\n      iframe.remove();\n\n      var placeholder = document.getElementById("video-placeholder");\n      if (placeholder) {\n        placeholder.style.display = "flex";\n      }\n\n      videoLoaded = false;\n    }\n  }\n\n  function openZoom(imageSrc, imageAlt) {\n    const modal = document.getElementById("zoom-modal");\n    const zoomImage = document.getElementById("zoom-image");\n\n    if (zoomImage && modal) {\n      zoomImage.src = imageSrc;\n      zoomImage.alt = imageAlt;\n      modal.style.display = "block";\n      document.body.style.overflow = "hidden";\n      stopAutoSlide();\n    }\n  }\n\n  function closeZoom() {\n    const modal = document.getElementById("zoom-modal");\n    if (modal) {\n      modal.style.display = "none";\n      document.body.style.overflow = "";\n      // Only restart auto-slide if we\'re on the quick tab\n      if (activeTab === "quick") {\n        startAutoSlide();\n      }\n    }\n  }\n\n  // Event handlers\n  function onTabClick(e) {\n    var button = e.currentTarget;\n    button.style.transform = "scale(0.98)";\n    setTimeout(function resetButtonScale() {\n      button.style.transform = "scale(1)";\n    }, 150);\n    switchDemoTab(button.dataset.tab);\n  }\n\n  function onDotClick(e) {\n    updateSlide(parseInt(e.currentTarget.dataset.slide, 10));\n    startAutoSlide();\n  }\n\n  function onImageClick(e) {\n    openZoom(e.currentTarget.src, e.currentTarget.alt);\n  }\n\n  function onDocumentKeydown(e) {\n    if (e.key === "Escape") {\n      closeZoom();\n    }\n  }\n\n  // Initialize on DOM ready\n  document.addEventListener("DOMContentLoaded", function initializeDemoSection() {\n    document.querySelectorAll(".demo-tab").forEach(function setupTab(tab) {\n      tab.addEventListener("click", onTabClick);\n      tab.addEventListener("keydown", function handleTabKeydown(e) {\n        if (e.key === "ArrowLeft" || e.key === "ArrowRight") {\n          e.preventDefault();\n          var tabs = Array.from(document.querySelectorAll(".demo-tab"));\n          var currentIndex = tabs.indexOf(tab);\n          var nextIndex =\n            e.key === "ArrowRight"\n              ? (currentIndex + 1) % tabs.length\n              : (currentIndex - 1 + tabs.length) % tabs.length;\n          tabs[nextIndex].focus();\n          tabs[nextIndex].click();\n        }\n      });\n    });\n\n    document.querySelectorAll(".carousel-dot").forEach(function setupDot(dot) {\n      dot.addEventListener("click", onDotClick);\n    });\n\n    const prevBtn = document.querySelector(".carousel-prev");\n    const nextBtn = document.querySelector(".carousel-next");\n\n    if (prevBtn) prevBtn.addEventListener("click", previousSlideManual);\n    if (nextBtn) nextBtn.addEventListener("click", nextSlideManual);\n\n    // Video placeholder\n    const videoPlaceholder = document.getElementById("video-placeholder");\n    if (videoPlaceholder) {\n      videoPlaceholder.addEventListener("click", loadVideo);\n      videoPlaceholder.addEventListener("keydown", (e) => {\n        if (e.key === "Enter" || e.key === " ") {\n          e.preventDefault();\n          loadVideo();\n        }\n      });\n    }\n\n    // Zoomable images\n    document.querySelectorAll(".zoomable").forEach(function setupZoomable(img) {\n      img.addEventListener("click", onImageClick);\n      img.addEventListener("keydown", function handleImageKeydown(e) {\n        if (e.key === "Enter" || e.key === " ") {\n          e.preventDefault();\n          openZoom(img.src, img.alt);\n        }\n      });\n    });\n\n    // Zoom modal\n    const zoomModal = document.getElementById("zoom-modal");\n    const zoomClose = document.getElementById("zoom-close");\n\n    if (zoomModal) zoomModal.addEventListener("click", closeZoom);\n    if (zoomClose) {\n      zoomClose.addEventListener("click", (e) => {\n        e.stopPropagation();\n        closeZoom();\n      });\n    }\n\n    document.addEventListener("keydown", onDocumentKeydown);\n\n    // Start auto-slide for default tab\n    startAutoSlide();\n\n    // Touch support for mobile swipe\n    let touchStartX = 0;\n    let touchEndX = 0;\n\n    const carousel = document.querySelector(".svg-carousel");\n    if (carousel) {\n      carousel.addEventListener("touchstart", function handleTouchStart(e) {\n        touchStartX = e.changedTouches[0].screenX;\n      });\n\n      carousel.addEventListener("touchend", function handleTouchEnd(e) {\n        touchEndX = e.changedTouches[0].screenX;\n        handleSwipe();\n      });\n    }\n\n    function handleSwipe() {\n      var swipeThreshold = 50;\n      var diff = touchStartX - touchEndX;\n\n      if (Math.abs(diff) > swipeThreshold) {\n        if (diff > 0) {\n          nextSlideManual();\n        } else {\n          previousSlideManual();\n        }\n      }\n    }\n  });\n<\/script>'])), maybeRenderHead(), addAttribute(videoUrl, "data-video-url"));
}, "/home/runner/work/landing-page/landing-page/src/components/hero/DemoSection.astro", void 0);
const $$Astro$3 = createAstro("https://findforce.io");
const $$CTASection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$3, $$props, $$slots);
  Astro2.self = $$CTASection;
  return renderTemplate`${maybeRenderHead()}<div class="hero-cta" style="
    display: flex;
    gap: 20px;
    justify-content: center;
    align-items: center;
    margin-bottom: 24px;
    flex-wrap: wrap;
  " data-astro-cid-5436wghs> <a href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=web&utm_campaign=cta_section&utm_content=install_extension" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="index_hero"${addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url")} data-pirsch-non-interactive class="btn-primary" style="
      font-size: 18px;
      padding: 18px 32px;
      background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
      color: white;
      border: none;
      border-radius: 8px;
      text-decoration: none;
      display: inline-block;
      font-weight: 700;
      box-shadow: 0 4px 14px rgba(37, 99, 235, 0.3);
      transition: all 0.3s ease;
    " target="_blank" rel="noopener" aria-label="Install FindForce Chrome extension" data-astro-cid-5436wghs>
Install Free Extension →
</a> <div class="trust-metrics" style="text-align: center" data-astro-cid-5436wghs> <div style="font-size: 24px; font-weight: 700; color: #059669" aria-label="Accuracy rate" data-astro-cid-5436wghs>
95%
</div> <div style="font-size: 13px; color: #4b5563" data-astro-cid-5436wghs>accuracy guaranteed</div> </div> </div> `;
}, "/home/runner/work/landing-page/landing-page/src/components/hero/CTASection.astro", void 0);
const $$TrustIndicators = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div class="trust-indicators" style="
    display: flex;
    gap: 24px;
    justify-content: center;
    align-items: center;
    flex-wrap: wrap;
    margin-bottom: 16px;
  " data-astro-cid-tpgccqdx> <span style="font-size: 13px; color: #059669; display: flex; align-items: center" data-astro-cid-tpgccqdx> <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor" style="margin-right: 4px" data-astro-cid-tpgccqdx> <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" data-astro-cid-tpgccqdx></path> </svg>
25 free verifications/month
</span> <span style="font-size: 13px; color: #059669; display: flex; align-items: center" data-astro-cid-tpgccqdx> <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor" style="margin-right: 4px" data-astro-cid-tpgccqdx> <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" data-astro-cid-tpgccqdx></path> </svg>
GDPR compliant
</span> <span style="font-size: 13px; color: #059669; display: flex; align-items: center" data-astro-cid-tpgccqdx> <svg width="16" height="16" viewBox="0 0 20 20" fill="currentColor" style="margin-right: 4px" data-astro-cid-tpgccqdx> <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" data-astro-cid-tpgccqdx></path> </svg>
Cancel anytime
</span> </div> <p style="font-size: 12px; color: #9ca3af; text-align: center" data-astro-cid-tpgccqdx>
No credit card for free tier • 1-click install • Works on Sales Navigator
</p> `;
}, "/home/runner/work/landing-page/landing-page/src/components/hero/TrustIndicators.astro", void 0);
const $$ZoomModal = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${maybeRenderHead()}<div id="zoom-modal" style="
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.9);
    z-index: 9999;
    cursor: zoom-out;
  " aria-label="Zoomed image view - click to close" role="dialog" aria-modal="true"> <img id="zoom-image" style="
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      max-width: 95%;
      max-height: 95%;
      object-fit: contain;
    " alt=""> <button id="zoom-close" style="
      position: absolute;
      top: 20px;
      right: 20px;
      background: rgba(255, 255, 255, 0.2);
      border: 2px solid white;
      color: white;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      font-size: 20px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
    " aria-label="Close zoom view">
×
</button> </div> ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/components/hero/ZoomModal.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/landing-page/landing-page/src/components/hero/ZoomModal.astro", void 0);
const $$Astro$2 = createAstro("https://findforce.io");
const $$HeroSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$2, $$props, $$slots);
  Astro2.self = $$HeroSection;
  var {
    className = "",
    videoUrl = "https://screen.studio/share/LBCdw8Fu?private-access=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzaGFyZWFibGVMaW5rSWQiOiI0NjVjNGNjNy1jY2E1LTQ4MWUtYmQ3MS04NmUyOTk4NjQ1NGMiLCJpYXQiOjE3NTc0OTE1MjN9.-KI_Nq17jD8ax-g8mnPEaMTjICGgb7Q2vXLVkcB1GaU"
  } = Astro2.props;
  return renderTemplate`${maybeRenderHead()}<section${addAttribute(`section-padding ${className}`, "class")} style="
    padding: 80px 0 60px 0;
    background: linear-gradient(135deg, #ffffff 0%, #f0f9ff 100%);
    position: relative;
    overflow: hidden;
  " aria-labelledby="hero-heading" data-astro-cid-nlow4r3u> <div style="position: absolute; top: 10%; left: 5%; opacity: 0.1; transform: rotate(-15deg)" data-astro-cid-nlow4r3u> <svg width="120" height="120" viewBox="0 0 24 24" fill="#3b82f6" data-astro-cid-nlow4r3u> <path d="M13 10V3L4 14h7v7l9-11h-7z" data-astro-cid-nlow4r3u></path> </svg> </div> <div style="position: absolute; bottom: 10%; right: 5%; opacity: 0.1; transform: rotate(15deg)" data-astro-cid-nlow4r3u> <svg width="100" height="100" viewBox="0 0 24 24" fill="#059669" data-astro-cid-nlow4r3u> <path d="M9 11H7v2h2v-2zm4 0h-2v2h2v-2zm4 0h-2v2h2v-2zm2-7h-1V2h-2v2H8V2H6v2H5c-1.11 0-1.99.9-1.99 2L3 20c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 16H5V9h14v11z" data-astro-cid-nlow4r3u></path> </svg> </div> <div class="container" style="text-align: center; position: relative; z-index: 1" data-astro-cid-nlow4r3u> ${renderComponent($$result, "TrustSignal", $$TrustSignal, { "data-astro-cid-nlow4r3u": true })} ${renderComponent($$result, "HeroContent", $$HeroContent, { "data-astro-cid-nlow4r3u": true })} ${renderComponent($$result, "DemoSection", $$DemoSection, { "videoUrl": videoUrl, "data-astro-cid-nlow4r3u": true })} ${renderComponent($$result, "CTASection", $$CTASection, { "data-astro-cid-nlow4r3u": true })} ${renderComponent($$result, "TrustIndicators", $$TrustIndicators, { "data-astro-cid-nlow4r3u": true })} </div> </section> ${renderComponent($$result, "ZoomModal", $$ZoomModal, { "data-astro-cid-nlow4r3u": true })}  ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/components/HeroSection.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/landing-page/landing-page/src/components/HeroSection.astro", void 0);
const $$Astro$1 = createAstro("https://findforce.io");
const $$PriceCard = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro$1, $$props, $$slots);
  Astro2.self = $$PriceCard;
  var {
    title,
    price,
    features,
    cta,
    badge,
    featured = false,
    disclaimer,
    className = ""
  } = Astro2.props;
  function getBadgeClass(type) {
    switch (type) {
      case "hot":
        return "badge-hot";
      case "popular":
        return "badge-popular";
      case "limited":
        return "badge-limited";
      case "free":
        return "badge-free";
      default:
        return "badge-default";
    }
  }
  function getCTAClass(variant) {
    return variant === "primary" ? "btn-primary" : "btn-secondary";
  }
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(`price-card ${featured ? "price-card--featured" : ""} ${className}`, "class")} data-astro-cid-tyya4faj> ${badge && renderTemplate`<div${addAttribute(`price-card__badge ${getBadgeClass(badge.type)}`, "class")} data-astro-cid-tyya4faj> ${badge.text} </div>`} <div class="price-card__header" data-astro-cid-tyya4faj> <h3 class="price-card__title" data-astro-cid-tyya4faj>${title}</h3> <div class="price-card__pricing" data-astro-cid-tyya4faj> <div class="price-card__amount" data-astro-cid-tyya4faj> ${price.amount} <span class="price-card__unit" data-astro-cid-tyya4faj>${price.unit}</span> </div> ${price.originalPrice && renderTemplate`<div class="price-card__original" data-astro-cid-tyya4faj>${price.originalPrice}</div>`} ${price.savings && renderTemplate`<div class="price-card__savings" data-astro-cid-tyya4faj>${price.savings}</div>`} ${price.description && renderTemplate`<p class="price-card__description" data-astro-cid-tyya4faj>${price.description}</p>`} </div> </div> <ul class="price-card__features" data-astro-cid-tyya4faj> ${features.map(function(feature) {
    return renderTemplate`<li${addAttribute(`price-card__feature ${feature.muted ? "price-card__feature--muted" : ""}`, "class")} data-astro-cid-tyya4faj> <svg class="price-card__check" width="20" height="20" viewBox="0 0 20 20"${addAttribute(feature.muted ? "#9ca3af" : "#10b981", "fill")} aria-hidden="true" data-astro-cid-tyya4faj> <path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" data-astro-cid-tyya4faj></path> </svg> <span data-astro-cid-tyya4faj> ${feature.highlight && renderTemplate`<strong data-astro-cid-tyya4faj>${feature.highlight}</strong>`} ${feature.text} </span> </li>`;
  })} </ul> <div class="price-card__cta" data-astro-cid-tyya4faj> ${cta.href ? renderTemplate`<a${addAttribute(cta.href, "href")}${addAttribute(getCTAClass(cta.variant), "class")}${addAttribute(cta.ariaLabel, "aria-label")}${addAttribute(cta.trackingEvent, "data-pirsch-event")}${addAttribute(cta.trackingMeta?.source, "data-pirsch-meta-source")}${addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url")} data-pirsch-non-interactive data-astro-cid-tyya4faj> ${cta.text} </a>` : renderTemplate`<button${addAttribute(getCTAClass(cta.variant), "class")}${addAttribute(cta.onClick, "onclick")}${addAttribute(cta.ariaLabel, "aria-label")}${addAttribute(cta.trackingEvent, "data-pirsch-event")}${addAttribute(cta.trackingMeta?.source, "data-pirsch-meta-source")} data-astro-cid-tyya4faj> ${cta.text} </button>`} </div> ${disclaimer && renderTemplate`<p class="price-card__disclaimer" data-astro-cid-tyya4faj>${disclaimer}</p>`} </div> `;
}, "/home/runner/work/landing-page/landing-page/src/components/PriceCard.astro", void 0);
const $$Astro = createAstro("https://findforce.io");
const $$PricingSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$PricingSection;
  var { className = "" } = Astro2.props;
  var competitorCardData = {
    title: "What Others Charge",
    price: {
      amount: "$49+",
      unit: "/mo",
      description: "Plus overage charges"
    },
    features: [
      { text: "Credit systems", muted: true },
      { text: "Usage limits", muted: true },
      { text: "Overage charges", muted: true },
      { text: "Poor support", muted: true }
    ],
    cta: {
      text: "See Why We're Different →",
      variant: "secondary",
      ariaLabel: "Learn why FindForce is different from competitors",
      href: "/compare"
    }
  };
  var findforceCardData = {
    title: "FindForce Pro",
    price: {
      amount: "€49",
      unit: "/mo",
      description: "Everything you need to close deals faster"
    },
    features: [
      { highlight: "Unlimited", text: " verifications" },
      { highlight: "95%", text: " accuracy guaranteed" },
      { highlight: "sub-second", text: " verification" },
      { highlight: "GDPR", text: " compliant" },
      { text: "All future features included" }
    ],
    cta: {
      text: "Get Started Now →",
      href: "https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=web&utm_campaign=pricing_cta&utm_content=pro_pricing",
      variant: "primary",
      ariaLabel: "Get started with FindForce Pro",
      trackingEvent: "webstore_clicked",
      trackingMeta: { source: "index_pricing" }
    },
    badge: {
      text: "⭐ Most Popular",
      type: "popular"
    },
    featured: true,
    disclaimer: "7-day money back • Cancel anytime"
  };
  var freeCardData = {
    title: "Free Forever",
    price: {
      amount: "€0",
      unit: "/mo",
      description: "25 verifications/month"
    },
    features: [
      { text: "Same 95% accuracy", muted: true },
      { text: "No credit card needed", muted: true },
      { text: "Perfect for testing", muted: true }
    ],
    cta: {
      text: "Start Free →",
      href: "https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg?utm_source=website&utm_medium=web&utm_campaign=pricing_cta&utm_content=free_pricing",
      variant: "secondary",
      ariaLabel: "Start free trial - Opens Chrome Web Store"
    }
  };
  return renderTemplate`${maybeRenderHead()}<section id="pricing"${addAttribute(`section-padding ${className} pricing-section`, "class")} aria-labelledby="pricing-heading" data-astro-cid-przegf2x> <div class="container" data-astro-cid-przegf2x> <!-- Section Header --> <div class="section-header" data-astro-cid-przegf2x> <div class="badge" data-astro-cid-przegf2x>Simple, Transparent Pricing</div> <h2 id="pricing-heading" class="heading" data-astro-cid-przegf2x>
One Price. No BS. No Credits.
</h2> <p class="subheading" data-astro-cid-przegf2x>
While competitors confuse you with credit systems and hidden limits, we
        keep it simple: <strong data-astro-cid-przegf2x>unlimited verifications, flat rate.</strong> </p> </div> <!-- Pricing Comparison --> <div class="pricing-grid" data-astro-cid-przegf2x> ${renderComponent($$result, "PriceCard", $$PriceCard, { "title": competitorCardData.title, "price": competitorCardData.price, "features": competitorCardData.features, "cta": competitorCardData.cta, "className": "competitor-card", "data-astro-cid-przegf2x": true })} ${renderComponent($$result, "PriceCard", $$PriceCard, { "title": findforceCardData.title, "price": findforceCardData.price, "features": findforceCardData.features, "cta": findforceCardData.cta, "badge": findforceCardData.badge, "featured": findforceCardData.featured, "disclaimer": findforceCardData.disclaimer, "className": "findforce-card", "data-astro-cid-przegf2x": true })} ${renderComponent($$result, "PriceCard", $$PriceCard, { "title": freeCardData.title, "price": freeCardData.price, "features": freeCardData.features, "cta": freeCardData.cta, "className": "free-card", "data-astro-cid-przegf2x": true })} </div> <!-- Social Proof Alternative --> <div class="social-proof" data-astro-cid-przegf2x> <h3 class="proof-title" data-astro-cid-przegf2x>Built for performance:</h3> <div class="stats-grid" data-astro-cid-przegf2x> <div class="stat-card" data-astro-cid-przegf2x> <p class="stat-value" data-astro-cid-przegf2x>14.5 hrs</p> <p class="stat-label" data-astro-cid-przegf2x>saved weekly per SDR</p> </div> <div class="stat-card" data-astro-cid-przegf2x> <p class="stat-value" data-astro-cid-przegf2x>95%+</p> <p class="stat-label" data-astro-cid-przegf2x>accuracy guaranteed</p> </div> <div class="stat-card" data-astro-cid-przegf2x> <p class="stat-value" data-astro-cid-przegf2x>5 sec</p> <p class="stat-label" data-astro-cid-przegf2x>average verification</p> </div> </div> <p class="proof-note" data-astro-cid-przegf2x>
* Based on verified customer data and SMTP verification results.
</p> </div> </div> </section> `;
}, "/home/runner/work/landing-page/landing-page/src/components/PricingSection.astro", void 0);
const $$Index = createComponent(async ($$result, $$props, $$slots) => {
  var posts = await getCollection("posts", function filterPosts({ data }) {
    return data.draft !== true;
  });
  posts.sort(function sortByDate(a, b) {
    return b.data.publishDate.valueOf() - a.data.publishDate.valueOf();
  });
  var latestPosts = posts.slice(0, 3);
  var homepageStructuredData = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "FindForce",
    "description": "Chrome extension for finding and verifying business emails with 95% accuracy guarantee",
    "url": "https://findforce.io",
    "applicationCategory": "BusinessApplication",
    "operatingSystem": "Chrome",
    "offers": {
      "@type": "Offer",
      "price": "29",
      "priceCurrency": "EUR",
      "priceValidUntil": "2025-12-31"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": "4.9",
      "ratingCount": "127"
    }
  };
  var homepageMeta = [
    { property: "product:price:amount", content: "29" },
    { property: "product:price:currency", content: "EUR" },
    { name: "apple-mobile-web-app-capable", content: "yes" },
    { name: "apple-mobile-web-app-status-bar-style", content: "default" }
  ];
  var videoUrl = "https://screen.studio/share/LBCdw8Fu?private-access=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzaGFyZWFibGVMaW5rSWQiOiI0NjVjNGNjNy1jY2E1LTQ4MWUtYmQ3MS04NmUyOTk4NjQ1NGMiLCJpYXQiOjE3NTc0OTE1MjN9.-KI_Nq17jD8ax-g8mnPEaMTjICGgb7Q2vXLVkcB1GaU";
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "ogTitle": "FindForce - Get Verified Business Emails with 95% Accuracy", "ogDescription": "Find and verify business emails in seconds. 95% accuracy guaranteed or your money back. Unlimited verifications, flat rate pricing.", "twitterTitle": "FindForce - Professional Email Finder & Verifier 🚀", "twitterDescription": "95% email accuracy guaranteed or money back. Unlimited verifications with flat rate pricing.", "additionalMeta": homepageMeta, "structuredData": homepageStructuredData }, { "default": async ($$result2) => renderTemplate`  ${maybeRenderHead()}<main id="main-content"> ${renderComponent($$result2, "HeroSection", $$HeroSection, { "videoUrl": videoUrl })} ${renderComponent($$result2, "FeaturedTestimonialSection", $$FeaturedTestimonialSection, {})} ${renderComponent($$result2, "AccuracySection", $$AccuracySection, {})} ${renderComponent($$result2, "GuaranteeSection", $$GuaranteeSection, {})} ${renderComponent($$result2, "PricingSection", $$PricingSection, {})} ${renderComponent($$result2, "FAQSection", $$FAQSection, {})} ${renderComponent($$result2, "BlogSection", $$BlogSection, { "posts": latestPosts })} ${renderComponent($$result2, "FinalCTA", $$FinalCTA, {})} </main> `, "head": async ($$result2) => renderTemplate`${renderComponent($$result2, "Fragment", Fragment, { "slot": "head" }, { "default": async ($$result3) => renderTemplate` <link rel="prefetch" href="https://chromewebstore.google.com/detail/ilebiijfdkmnnhkngehmiggngoeoenbg"> <meta name="theme-color" content="#2563eb"> ` })}` })} ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/index.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/landing-page/landing-page/src/pages/index.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/index.astro";
const $$url = "";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
