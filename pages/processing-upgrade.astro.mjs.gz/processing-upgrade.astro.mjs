import { c as createAstro, a as createComponent, r as renderComponent, b as renderScript, d as renderTemplate, m as maybeRenderHead } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { $ as $$BaseLayout } from "../js/BaseLayout.Iez5vTa9.js";
/* empty css                                         */
import { renderers } from "../renderers.mjs";
const $$Astro = createAstro("https://findforce.io");
const $$ProcessingUpgrade = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$ProcessingUpgrade;
  var searchParams = Astro2.url.searchParams;
  var isFounder = searchParams.get("founder") === "true";
  var upgradeTitle = isFounder ? "Processing Your Founder Upgrade" : "Processing Your Upgrade";
  var pricingText = isFounder ? "$29/mo founder pricing" : "Standard pricing";
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": upgradeTitle + " - FindForce", "description": "Processing your FindForce upgrade request", "canonical": "https://findforce.io/processing-upgrade", "noindex": true, "data-astro-cid-5iibzg5h": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="processing-page" data-astro-cid-5iibzg5h> <div class="container" data-astro-cid-5iibzg5h> <div class="processing-content" data-astro-cid-5iibzg5h> <div class="spinner-container" data-astro-cid-5iibzg5h> <div class="spinner" data-astro-cid-5iibzg5h></div> </div> <h1 class="title" data-astro-cid-5iibzg5h>${upgradeTitle}</h1> <div class="steps" data-astro-cid-5iibzg5h> <div class="step completed" data-astro-cid-5iibzg5h> <div class="step-icon" data-astro-cid-5iibzg5h> <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-5iibzg5h> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" data-astro-cid-5iibzg5h></path> </svg> </div> <span data-astro-cid-5iibzg5h>Authentication verified</span> </div> <div class="step processing" id="checkout-step" data-astro-cid-5iibzg5h> <div class="step-icon" data-astro-cid-5iibzg5h> <div class="step-spinner" data-astro-cid-5iibzg5h></div> </div> <span data-astro-cid-5iibzg5h>Creating your checkout session</span> </div> <div class="step pending" id="redirect-step" data-astro-cid-5iibzg5h> <div class="step-icon" data-astro-cid-5iibzg5h> <div class="step-number" data-astro-cid-5iibzg5h>3</div> </div> <span data-astro-cid-5iibzg5h>Redirecting to secure payment</span> </div> </div> <div class="message" id="status-message" data-astro-cid-5iibzg5h> <p data-astro-cid-5iibzg5h>We're setting up your ${isFounder ? "founder pricing " : ""}checkout session.</p> <p class="sub-message" data-astro-cid-5iibzg5h>This usually takes just a few seconds...</p> </div> <div class="checkout-ready-section" id="checkout-ready" style="display: none;" data-astro-cid-5iibzg5h> <div class="success-animation" data-astro-cid-5iibzg5h> <div class="checkmark" data-astro-cid-5iibzg5h> <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-5iibzg5h> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7" data-astro-cid-5iibzg5h></path> </svg> </div> </div> <div class="ready-message" data-astro-cid-5iibzg5h> <h2 data-astro-cid-5iibzg5h>Checkout Ready!</h2> <p data-astro-cid-5iibzg5h>Your secure payment session has been created.</p> </div> <div class="countdown-container" data-astro-cid-5iibzg5h> <div class="countdown-circle" data-astro-cid-5iibzg5h> <svg class="countdown-svg" viewBox="0 0 36 36" data-astro-cid-5iibzg5h> <path class="countdown-bg" d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831" data-astro-cid-5iibzg5h></path> <path class="countdown-progress" d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831" id="countdown-path" data-astro-cid-5iibzg5h></path> </svg> <div class="countdown-number" id="countdown-number" data-astro-cid-5iibzg5h>3</div> </div> <p class="countdown-text" data-astro-cid-5iibzg5h>Redirecting in <span id="countdown-text" data-astro-cid-5iibzg5h>3</span> seconds...</p> </div> </div> <div class="guarantee-badge" data-astro-cid-5iibzg5h> <svg width="20" height="20" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true" data-astro-cid-5iibzg5h> <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" data-astro-cid-5iibzg5h></path> </svg> <span data-astro-cid-5iibzg5h>95% accuracy guarantee • ${pricingText} • Cancel anytime</span> </div> <div class="footer-text" data-astro-cid-5iibzg5h> <span data-astro-cid-5iibzg5h>Powered by FindForce</span> <span class="divider" data-astro-cid-5iibzg5h>•</span> <span data-astro-cid-5iibzg5h>Secure checkout by Stripe</span> </div> </div> </div> </section> ` })}  ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/processing-upgrade.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/landing-page/landing-page/src/pages/processing-upgrade.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/processing-upgrade.astro";
const $$url = "/processing-upgrade.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$ProcessingUpgrade,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
