import { renderers } from "../renderers.mjs";
const allow = (sitemapURL) => `User-agent: *
Allow: /

Sitemap: ${sitemapURL.href}
`;
const disallow = `User-agent: *
Disallow: /
`;
const GET = ({ site }) => {
  if (process.env.NOINDEX === "1") {
    return new Response(disallow);
  }
  return new Response(allow(new URL("sitemap-index.xml", site)));
};
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
