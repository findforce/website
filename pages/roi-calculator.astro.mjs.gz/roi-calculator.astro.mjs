import { c as createAstro, a as createComponent, r as renderComponent, b as renderScript, d as renderTemplate, m as maybeRenderHead, e as addAttribute } from "../js/astro/server.DeFkX6hJ.js";
import "kleur/colors";
import { $ as $$BaseLayout } from "../js/BaseLayout.BcN4qwMm.js";
/* empty css                                     */
import { renderers } from "../renderers.mjs";
const $$Astro = createAstro("https://findforce.io");
const $$RoiCalculator = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$RoiCalculator;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "Email Verification ROI Calculator - FindForce", "description": "Discover how much bad email data costs your sales team. Only 62% of submitted emails are valid. Calculate your potential savings with our ROI calculator.", "canonical": "https://findforce.io/roi-calculator", "data-astro-cid-lt3cfqyf": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="roi-calculator-page" data-astro-cid-lt3cfqyf> <div class="container" data-astro-cid-lt3cfqyf> <header class="header" data-astro-cid-lt3cfqyf> <div class="logo" data-astro-cid-lt3cfqyf> <div class="logo-icon" data-astro-cid-lt3cfqyf>@</div> <span class="logo-text" data-astro-cid-lt3cfqyf>FindForce</span> </div> <h1 data-astro-cid-lt3cfqyf>Email Verification ROI Calculator</h1> <p class="subtitle" data-astro-cid-lt3cfqyf>
Discover how much bad email data costs your sales team. 40% of seller time goes to prospecting with 25% annual database decay.
</p> </header> <div class="calculator-wrapper" data-astro-cid-lt3cfqyf> <div class="input-section" data-astro-cid-lt3cfqyf> <h2 data-astro-cid-lt3cfqyf>Your Current Situation</h2> <div class="form-group" data-astro-cid-lt3cfqyf> <label for="sdr-count" data-astro-cid-lt3cfqyf>Number of SDRs</label> <input type="number" id="sdr-count" value="10" min="1" max="1000" data-astro-cid-lt3cfqyf> </div> <div class="form-group" data-astro-cid-lt3cfqyf> <label for="sdr-salary" data-astro-cid-lt3cfqyf>Average SDR Monthly Cost ($)</label> <input type="number" id="sdr-salary" value="5000" min="3000" max="20000" data-astro-cid-lt3cfqyf> </div> <div class="form-group" data-astro-cid-lt3cfqyf> <label for="bounce-rate" data-astro-cid-lt3cfqyf>Current Email Bounce Rate</label> <div class="range-wrapper" data-astro-cid-lt3cfqyf> <span class="range-value" id="bounce-rate-value" data-astro-cid-lt3cfqyf>15%</span> <input type="range" id="bounce-rate" value="15" min="2" max="40" step="1" data-astro-cid-lt3cfqyf> </div> </div> <div class="form-group" data-astro-cid-lt3cfqyf> <label for="time-waste" data-astro-cid-lt3cfqyf>Hours Per Week on Manual Prospecting</label> <div class="range-wrapper" data-astro-cid-lt3cfqyf> <span class="range-value" id="time-waste-value" data-astro-cid-lt3cfqyf>16 hrs</span> <input type="range" id="time-waste" value="16" min="8" max="25" step="1" data-astro-cid-lt3cfqyf> </div> </div> <div class="form-group" data-astro-cid-lt3cfqyf> <label for="contacts-month" data-astro-cid-lt3cfqyf>Contacts Processed Monthly</label> <input type="number" id="contacts-month" value="1000" min="100" max="10000" step="100" data-astro-cid-lt3cfqyf> </div> </div> <div class="results-section" data-astro-cid-lt3cfqyf> <h2 data-astro-cid-lt3cfqyf>Your Potential Savings</h2> <div class="metric" data-astro-cid-lt3cfqyf> <div class="metric-label" data-astro-cid-lt3cfqyf>Monthly Cost of Manual Prospecting</div> <div class="metric-value" id="monthly-cost" data-astro-cid-lt3cfqyf>$20,000</div> <div class="metric-detail" data-astro-cid-lt3cfqyf>Across your entire team</div> </div> <div class="metric" data-astro-cid-lt3cfqyf> <div class="metric-label" data-astro-cid-lt3cfqyf>Annual GDPR Compliance Risk</div> <div class="metric-value" id="compliance-risk" data-astro-cid-lt3cfqyf>€625K</div> <div class="metric-detail" data-astro-cid-lt3cfqyf>Average email violation fine range</div> </div> <div class="metric" data-astro-cid-lt3cfqyf> <div class="metric-label" data-astro-cid-lt3cfqyf>Time Recovered Monthly</div> <div class="metric-value" id="time-saved" data-astro-cid-lt3cfqyf>416 hrs</div> <div class="metric-detail" data-astro-cid-lt3cfqyf>Equal to 2.6 full-time SDRs</div> </div> <div class="metric" data-astro-cid-lt3cfqyf> <div class="metric-label" data-astro-cid-lt3cfqyf>ROI with Email Verification</div> <div class="metric-value" id="roi" data-astro-cid-lt3cfqyf>400:1</div> <div class="metric-detail" data-astro-cid-lt3cfqyf>
Payback in <span id="payback" data-astro-cid-lt3cfqyf>4</span> weeks
</div> </div> </div> </div> <div class="cta-section" data-astro-cid-lt3cfqyf> <h3 data-astro-cid-lt3cfqyf>Ready to Recover Your Team's Lost Productivity?</h3> <p class="cta-description" data-astro-cid-lt3cfqyf>
Join companies achieving 95%+ accuracy and 89.1% inbox placement in Europe vs 85% in the US
</p> <div id="risk-message" class="risk-message" style="display: none" data-astro-cid-lt3cfqyf> <strong data-astro-cid-lt3cfqyf>⚠️ Critical Risk:</strong> Your bounce rate exceeds the 2% threshold for healthy email lists. You're at risk of sender reputation damage and potential GDPR violations.
</div> <div id="success-message" class="success-message" style="display: none" data-astro-cid-lt3cfqyf> <strong data-astro-cid-lt3cfqyf>✓ Strong Opportunity:</strong> You could save
<span id="savings-highlight" data-astro-cid-lt3cfqyf></span> monthly with GDPR-compliant email verification.
</div> <a href="https://findforce.io?utm_source=website&utm_medium=roi_calculator&utm_campaign=free_trial_cta" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="roi_calculator"${addAttribute(Astro2.url.pathname, "data-pirsch-meta-page_url")} data-pirsch-non-interactive class="cta-button" data-astro-cid-lt3cfqyf>Start Free Trial - No Credit Card Required</a> </div> </div> </section> ` })} ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/roi-calculator.astro?astro&type=script&index=0&lang.ts")} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/roi-calculator.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/roi-calculator.astro";
const $$url = "/roi-calculator.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$RoiCalculator,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
