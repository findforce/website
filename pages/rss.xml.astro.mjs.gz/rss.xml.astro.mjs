import rss from "@astrojs/rss";
import { g as getCollection } from "../js/_astro_content.DEq6b1HM.js";
import { renderers } from "../renderers.mjs";
async function GET(context) {
  var posts = await getCollection("posts", function filterDrafts({ data }) {
    return data.draft !== true;
  });
  var changelogs = await getCollection(
    "changelogs",
    function filterDrafts({ data }) {
      return data.draft !== true;
    }
  );
  var comparisons = await getCollection(
    "comparisons",
    function filterDrafts({ data }) {
      return data.draft !== true;
    }
  );
  var postItems = posts.map(function mapPost(post) {
    return {
      title: post.data.title,
      description: post.data.description,
      pubDate: post.data.publishDate,
      link: `/blog/${post.slug}/`,
      categories: post.data.tags || []
    };
  });
  var changelogItems = changelogs.map(function mapChangelog(changelog) {
    return {
      title: `${changelog.data.version}: ${changelog.data.title}`,
      description: changelog.data.description,
      pubDate: changelog.data.releaseDate,
      link: `/changelog/${changelog.slug}/`
    };
  });
  var comparisonItems = comparisons.map(function mapComparison(comparison) {
    return {
      title: comparison.data.title,
      description: comparison.data.description,
      pubDate: comparison.data.publishDate,
      link: `/vs/${comparison.slug}/`
    };
  });
  var allItems = [...postItems, ...changelogItems, ...comparisonItems];
  allItems.sort(function sortByDate(a, b) {
    return b.pubDate.valueOf() - a.pubDate.valueOf();
  });
  return rss({
    title: "FindForce - Verified Business Emails with 95% Accuracy",
    description: "Find and verify business emails with 95% accuracy guarantee. Get the latest updates, tips, product comparisons, and changelog from FindForce - unlimited email verifications with flat rate pricing.",
    site: context.site,
    items: allItems,
    customData: "<language>en-us</language>"
  });
}
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  GET
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
