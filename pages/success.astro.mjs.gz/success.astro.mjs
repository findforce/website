import { a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { $ as $$BaseLayout } from "../js/BaseLayout.Iez5vTa9.js";
/* empty css                              */
import { renderers } from "../renderers.mjs";
const $$Success = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "Success", "description": "Authentication successful", "canonical": "https://findforce.io/success", "noindex": true, "data-astro-cid-5y44lzmc": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="success-page" data-astro-cid-5y44lzmc> <div class="container" data-astro-cid-5y44lzmc> <div class="success-icon" data-astro-cid-5y44lzmc> <svg fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-5y44lzmc> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" data-astro-cid-5y44lzmc></path> </svg> </div> <h1 class="title" data-astro-cid-5y44lzmc>Authentication Successful!</h1> <p class="subtitle" data-astro-cid-5y44lzmc>
You have been successfully authenticated with FindForce.
</p> <div class="message" data-astro-cid-5y44lzmc> <strong data-astro-cid-5y44lzmc>You're all set!</strong> You can now close this tab and return
        to using the FindForce extension.
</div> <div class="footer-text" data-astro-cid-5y44lzmc>Powered by FindForce</div> </div> </section> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/success.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/success.astro";
const $$url = "/success.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Success,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
