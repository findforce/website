import { a as createComponent, r as renderComponent, b as renderScript, d as renderTemplate, m as maybeRenderHead } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { $ as $$BaseLayout } from "../js/BaseLayout.Iez5vTa9.js";
/* empty css                                */
import { renderers } from "../renderers.mjs";
const $$ThankYou = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "Welcome to the FindForce Family", "description": "Thank you for choosing FindForce. Your trust means everything to us.", "canonical": "https://findforce.io/thank-you", "noindex": true, "data-astro-cid-reykoxrt": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="success-page" data-astro-cid-reykoxrt> <div class="container" data-astro-cid-reykoxrt> <!-- Subtle celebration animation --> <div class="celebration-wrapper" data-astro-cid-reykoxrt> <div class="pulse-ring" data-astro-cid-reykoxrt></div> <div class="pulse-ring delay-1" data-astro-cid-reykoxrt></div> <div class="pulse-ring delay-2" data-astro-cid-reykoxrt></div> <div class="success-icon" data-astro-cid-reykoxrt> <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" data-astro-cid-reykoxrt> <path d="M20 6L9 17l-5-5" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-reykoxrt></path> </svg> </div> </div> <h1 id="welcome-message" data-astro-cid-reykoxrt>Welcome to FindForce!</h1> <div class="heartfelt-message" data-astro-cid-reykoxrt> <p class="lead" data-astro-cid-reykoxrt> <span id="personal-greeting" data-astro-cid-reykoxrt>You just made our day.</span> </p> <p data-astro-cid-reykoxrt>
Seriously. In a world of free trials and tire-kickers, you pulled out
          your card and said "I believe in what you're building." That means
          everything to a small team like ours.
</p> <p data-astro-cid-reykoxrt>
Here's our promise to you: We're going to obsess over making FindForce
          better every single day. Not because it's good business (though it
          is), but because you took a chance on us when we're just getting
          started.
</p> <div class="commitment-box" data-astro-cid-reykoxrt> <h2 data-astro-cid-reykoxrt>What happens now:</h2> <ul data-astro-cid-reykoxrt> <li data-astro-cid-reykoxrt> <strong data-astro-cid-reykoxrt>Right now:</strong> Your account is being activated. You'll
              get an email in the next 2 minutes with everything you need.
</li> <li data-astro-cid-reykoxrt> <strong data-astro-cid-reykoxrt>Next 24 hours:</strong> I'll personally check that you're all
              set up. If anything feels off, just reply to any of our emails.
</li> <li data-astro-cid-reykoxrt> <strong data-astro-cid-reykoxrt>This week:</strong> We'll send you a few pro tips to help you
              get the most value immediately. No fluff, just what actually works.
</li> <li data-astro-cid-reykoxrt> <strong data-astro-cid-reykoxrt>Always:</strong> You have direct access to me and the team.
              We answer every email, usually within hours, often within minutes.
</li> </ul> </div> <div class="founder-note" data-astro-cid-reykoxrt> <div class="founder-header" data-astro-cid-reykoxrt> <div class="founder-avatar" data-astro-cid-reykoxrt> <img src="https://gravatar.com/avatar/69ce17a27762333488dbedcfef4a44b0a1c6903bf3fd7ccbf17603fe8e52a375?v=1722644614000&size=128&d=initials" alt="Meysam's Avatar" loading="lazy" data-astro-cid-reykoxrt> </div> <div data-astro-cid-reykoxrt> <div class="founder-name" data-astro-cid-reykoxrt>A note from Meysam</div> <div class="founder-title" data-astro-cid-reykoxrt>Founder, FindForce</div> </div> </div> <p data-astro-cid-reykoxrt> <span id="founder-greeting" data-astro-cid-reykoxrt>Hey there</span> — I know clicking "buy"
            on a new tool feels like a leap of faith. You're trusting us with your
            workflow, your time, and now your money.
</p> <p data-astro-cid-reykoxrt>
We don't take that lightly. Every feature we build, every bug we
            fix, every support email we answer — it's all because people like
            you believed in us early.
</p> <p data-astro-cid-reykoxrt>
You're not customer #4,847 to us. You're one of our first 100
            founders. That badge stays with your account forever, along with the
            pricing you locked in today.
</p> <p data-astro-cid-reykoxrt>
If FindForce isn't delivering insane value, tell me directly:
<a href="mailto:meysam@findforce.io" data-astro-cid-reykoxrt>meysam@findforce.io</a>. I read everything, and I mean that.
</p> <p class="signature" data-astro-cid-reykoxrt>
Thank you for being here at the beginning.<br data-astro-cid-reykoxrt>
— Meysam
</p> </div> <div class="next-steps" data-astro-cid-reykoxrt> <h3 data-astro-cid-reykoxrt>Ready to find your first verified email?</h3> <p data-astro-cid-reykoxrt>The extension is waiting for you. Let's make some magic happen.</p> <div class="action-buttons" data-astro-cid-reykoxrt> <a href="https://www.linkedin.com/in/williamhgates/" target="_blank" class="btn-primary" data-astro-cid-reykoxrt>
Try It on a Test Profile →
</a> <a href="mailto:support@findforce.io" class="btn-secondary" data-astro-cid-reykoxrt>
Need Help? We're Here
</a> </div> </div> <p class="ps" data-astro-cid-reykoxrt>
P.S. — <span id="ps-message" data-astro-cid-reykoxrt>Keep an eye on your email.</span> I'll be
          sharing some insider tips that our power users swear by. The kind of stuff
          that turns FindForce from a tool into a superpower.
</p> </div> </div> </section> ` })} ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/thank-you.astro?astro&type=script&index=0&lang.ts")} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/thank-you.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/thank-you.astro";
const $$url = "/thank-you.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$ThankYou,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
