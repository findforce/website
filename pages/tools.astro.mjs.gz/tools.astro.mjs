import { a as createComponent, r as renderComponent, d as renderTemplate, m as maybeRenderHead, e as addAttribute } from "../js/astro/server.CiUvenb_.js";
import "kleur/colors";
import { $ as $$BaseLayout, a as $$Logo } from "../js/BaseLayout.DZxjPdiE.js";
/* empty css                            */
import { renderers } from "../renderers.mjs";
const $$Index = createComponent(($$result, $$props, $$slots) => {
  var pageTitle = "Free Sales & Email Tools - FindForce";
  var pageDescription = "Free tools for sales teams: subject line analyzer, GDPR compliance checklist, bounce cost calculator, and email validator. No signup required.";
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name: "Free Sales & Email Tools",
    description: pageDescription,
    url: "https://findforce.io/tools",
    publisher: {
      "@type": "Organization",
      name: "FindForce",
      url: "https://findforce.io"
    }
  };
  var tools = [
    {
      title: "Cold Email Subject Line Analyzer",
      description: "Check your subject line for spam triggers and engagement signals. Get instant feedback on deliverability and open rate potential.",
      href: "/tools/subject-line-analyzer",
      icon: "mail",
      tag: "Most Popular",
      tagColor: "blue"
    },
    {
      title: "GDPR Cold Email Compliance Checklist",
      description: "Interactive checklist to verify your cold outreach is GDPR compliant. Get a clear yes/no compliance status with remediation steps.",
      href: "/tools/gdpr-cold-email-checklist",
      icon: "shield",
      tag: "EU Essential",
      tagColor: "green"
    },
    {
      title: "Email Bounce Cost Calculator",
      description: "Calculate how much email bounces cost your business monthly. See concrete dollar amounts of revenue lost to bad data.",
      href: "/tools/bounce-cost-calculator",
      icon: "calculator",
      tag: "ROI Focused",
      tagColor: "purple"
    },
    {
      title: "Email Format Validator",
      description: "Check if email addresses are syntactically valid. Detect common typos, invalid formats, and disposable email domains.",
      href: "/tools/email-validator",
      icon: "check",
      tag: "Quick Check",
      tagColor: "orange"
    }
  ];
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": pageTitle, "description": pageDescription, "canonical": "https://findforce.io/tools", "structuredData": structuredData, "data-astro-cid-qkptn22r": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="tools-page" data-astro-cid-qkptn22r> <div class="container" data-astro-cid-qkptn22r> <header class="header" data-astro-cid-qkptn22r> ${renderComponent($$result2, "Logo", $$Logo, { "size": "lg", "data-astro-cid-qkptn22r": true })} <h1 data-astro-cid-qkptn22r>Free Sales & Email Tools</h1> <p class="subtitle" data-astro-cid-qkptn22r>
Practical tools for SDRs and sales teams. No signup required, instant
          results.
</p> </header> <div class="tools-grid" data-astro-cid-qkptn22r> ${tools.map((tool) => renderTemplate`<a${addAttribute(tool.href, "href")} class="tool-card" data-pirsch-event="tool_card_clicked"${addAttribute(tool.title, "data-pirsch-meta-tool")} data-astro-cid-qkptn22r> <div class="tool-header" data-astro-cid-qkptn22r> <div${addAttribute(`tool-icon tool-icon-${tool.icon}`, "class")} data-astro-cid-qkptn22r> ${tool.icon === "mail" && renderTemplate`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-qkptn22r> <rect width="20" height="16" x="2" y="4" rx="2" data-astro-cid-qkptn22r></rect> <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" data-astro-cid-qkptn22r></path> </svg>`} ${tool.icon === "shield" && renderTemplate`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-qkptn22r> <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" data-astro-cid-qkptn22r></path> <path d="m9 12 2 2 4-4" data-astro-cid-qkptn22r></path> </svg>`} ${tool.icon === "calculator" && renderTemplate`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-qkptn22r> <rect width="16" height="20" x="4" y="2" rx="2" data-astro-cid-qkptn22r></rect> <line x1="8" x2="16" y1="6" y2="6" data-astro-cid-qkptn22r></line> <line x1="16" x2="16" y1="14" y2="18" data-astro-cid-qkptn22r></line> <path d="M16 10h.01" data-astro-cid-qkptn22r></path> <path d="M12 10h.01" data-astro-cid-qkptn22r></path> <path d="M8 10h.01" data-astro-cid-qkptn22r></path> <path d="M12 14h.01" data-astro-cid-qkptn22r></path> <path d="M8 14h.01" data-astro-cid-qkptn22r></path> <path d="M12 18h.01" data-astro-cid-qkptn22r></path> <path d="M8 18h.01" data-astro-cid-qkptn22r></path> </svg>`} ${tool.icon === "check" && renderTemplate`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-qkptn22r> <path d="M21.801 10A10 10 0 1 1 17 3.335" data-astro-cid-qkptn22r></path> <path d="m9 11 3 3L22 4" data-astro-cid-qkptn22r></path> </svg>`} </div> <span${addAttribute(`tool-tag tag-${tool.tagColor}`, "class")} data-astro-cid-qkptn22r>${tool.tag}</span> </div> <h2 class="tool-title" data-astro-cid-qkptn22r>${tool.title}</h2> <p class="tool-description" data-astro-cid-qkptn22r>${tool.description}</p> <span class="tool-cta" data-astro-cid-qkptn22r>
Use Tool
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-qkptn22r> <path d="M5 12h14" data-astro-cid-qkptn22r></path> <path d="m12 5 7 7-7 7" data-astro-cid-qkptn22r></path> </svg> </span> </a>`)} </div> <div class="newsletter-section" data-astro-cid-qkptn22r> <h3 data-astro-cid-qkptn22r>Want more sales productivity tips?</h3> <p data-astro-cid-qkptn22r>
Join 2,000+ sales professionals getting weekly deliverability tips and
          new tool announcements.
</p> <a href="https://newsletter.meysam.io" target="_blank" rel="noopener noreferrer" class="newsletter-btn" data-pirsch-event="newsletter_cta_clicked" data-pirsch-meta-source="tools_index" data-astro-cid-qkptn22r>
Subscribe Free
</a> </div> <div class="product-cta" data-astro-cid-qkptn22r> <h3 data-astro-cid-qkptn22r>Need verified emails at scale?</h3> <p data-astro-cid-qkptn22r>
FindForce guarantees 95% email accuracy with unlimited verifications
          at €49/month flat. No credits, no complexity.
</p> <a href="https://findforce.io?utm_source=tools&utm_medium=index" class="cta-button" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="tools_index" data-astro-cid-qkptn22r>
Start Free Trial
</a> </div> </div> </section> ` })} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/tools/index.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/tools/index.astro";
const $$url = "/tools.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Index,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
