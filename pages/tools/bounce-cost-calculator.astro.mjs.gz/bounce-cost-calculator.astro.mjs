import { a as createComponent, d as renderTemplate, r as renderComponent, m as maybeRenderHead } from "../../js/astro/server.CiUvenb_.js";
import "kleur/colors";
import { $ as $$BaseLayout, a as $$Logo } from "../../js/BaseLayout.DZxjPdiE.js";
import { $ as $$Newsletter } from "../../js/Newsletter.C7Q9rGOC.js";
/* empty css                                                */
import { renderers } from "../../renderers.mjs";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$BounceCostCalculator = createComponent(($$result, $$props, $$slots) => {
  var pageTitle = "Email Bounce Cost Calculator - See What Bad Data Costs You";
  var pageDescription = "Calculate how much email bounces cost your business monthly. See concrete dollar amounts of revenue lost to bad email data. Free calculator for sales teams.";
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: "Email Bounce Cost Calculator",
    description: pageDescription,
    url: "https://findforce.io/tools/bounce-cost-calculator",
    applicationCategory: "BusinessApplication",
    offers: {
      "@type": "Offer",
      price: "0",
      priceCurrency: "EUR"
    },
    creator: {
      "@type": "Organization",
      name: "FindForce",
      url: "https://findforce.io"
    }
  };
  return renderTemplate(_a || (_a = __template(["", ` <script>
  function calculateBounceCost() {
    var teamSize = parseInt(document.getElementById("team-size").value, 10) || 5;
    var emailsPerSdr = parseInt(document.getElementById("emails-per-sdr").value, 10) || 500;
    var bounceRate = parseInt(document.getElementById("bounce-rate").value, 10) || 15;
    var avgDeal = parseInt(document.getElementById("avg-deal").value, 10) || 5000;
    var replyRate = parseFloat(document.getElementById("reply-rate").value) || 3;
    var closeRate = parseInt(document.getElementById("close-rate").value, 10) || 10;

    var totalEmailsMonth = teamSize * emailsPerSdr;
    var bouncedEmails = Math.round(totalEmailsMonth * (bounceRate / 100));
    var deliveredEmails = totalEmailsMonth - bouncedEmails;

    var expectedReplies = deliveredEmails * (replyRate / 100);
    var expectedDeals = expectedReplies * (closeRate / 100);

    var potentialRepliesLost = bouncedEmails * (replyRate / 100);
    var potentialDealsLost = potentialRepliesLost * (closeRate / 100);

    var monthlyRevenueLost = potentialDealsLost * avgDeal;
    var annualRevenueLost = monthlyRevenueLost * 12;

    var benchmarkBounceRate = 2;
    var benchmarkBouncedEmails = Math.round(totalEmailsMonth * (benchmarkBounceRate / 100));
    var benchmarkPotentialRepliesLost = benchmarkBouncedEmails * (replyRate / 100);
    var benchmarkPotentialDealsLost = benchmarkPotentialRepliesLost * (closeRate / 100);
    var benchmarkMonthlyLost = benchmarkPotentialDealsLost * avgDeal;

    var monthlySavings = monthlyRevenueLost - benchmarkMonthlyLost;
    var annualSavings = monthlySavings * 12;

    document.getElementById("monthly-lost").textContent = "$" + Math.round(monthlyRevenueLost).toLocaleString();
    document.getElementById("annual-lost").textContent = "$" + Math.round(annualRevenueLost).toLocaleString();
    document.getElementById("bounced-count").textContent = bouncedEmails.toLocaleString();
    document.getElementById("lost-opps").textContent = potentialDealsLost.toFixed(1);

    document.getElementById("your-bounce").textContent = bounceRate + "%";
    document.getElementById("your-monthly").textContent = "$" + Math.round(monthlyRevenueLost).toLocaleString();
    document.getElementById("benchmark-monthly").textContent = "$" + Math.round(benchmarkMonthlyLost).toLocaleString();
    document.getElementById("savings-monthly").textContent = "$" + Math.round(monthlySavings).toLocaleString();
    document.getElementById("savings-annual").textContent = "$" + Math.round(annualSavings).toLocaleString();

    var riskLevel, riskColor, riskText;
    if (bounceRate <= 2) {
      riskLevel = 10;
      riskColor = "risk-low";
      riskText = "Excellent - Your sender reputation is protected";
    } else if (bounceRate <= 5) {
      riskLevel = 30;
      riskColor = "risk-moderate";
      riskText = "Good - Minor risk to sender reputation";
    } else if (bounceRate <= 10) {
      riskLevel = 60;
      riskColor = "risk-elevated";
      riskText = "Elevated - ISPs may start flagging your domain";
    } else if (bounceRate <= 20) {
      riskLevel = 80;
      riskColor = "risk-high";
      riskText = "High - Likely impacting email deliverability";
    } else {
      riskLevel = 95;
      riskColor = "risk-critical";
      riskText = "Critical - Immediate action required";
    }

    var riskFill = document.getElementById("risk-fill");
    riskFill.style.width = riskLevel + "%";
    riskFill.className = "risk-fill " + riskColor;
    document.getElementById("risk-label").textContent = riskText;

    var riskIcon = document.getElementById("risk-icon");
    if (bounceRate <= 5) {
      riskIcon.textContent = "✓";
    } else if (bounceRate <= 10) {
      riskIcon.textContent = "⚠️";
    } else {
      riskIcon.textContent = "🚨";
    }

    var alertSection = document.getElementById("alert-section");
    var alertMessage = document.getElementById("alert-message");

    if (bounceRate > 10) {
      alertSection.style.display = "block";
      alertMessage.className = "alert alert-danger";
      alertMessage.innerHTML = "<strong>Critical Risk:</strong> Your bounce rate of " + bounceRate + "% exceeds the 10% threshold. ISPs like Gmail and Outlook will start blocking your emails. You're losing an estimated <strong>$" + Math.round(monthlyRevenueLost).toLocaleString() + "</strong> monthly.";
    } else if (bounceRate > 5) {
      alertSection.style.display = "block";
      alertMessage.className = "alert alert-warning";
      alertMessage.innerHTML = "<strong>Warning:</strong> Your bounce rate of " + bounceRate + "% is above the recommended 2% threshold. Consider implementing email verification to protect your sender reputation.";
    } else if (bounceRate > 2) {
      alertSection.style.display = "block";
      alertMessage.className = "alert alert-info";
      alertMessage.innerHTML = "<strong>Opportunity:</strong> Reducing your bounce rate from " + bounceRate + "% to 2% could save you <strong>$" + Math.round(monthlySavings).toLocaleString() + "</strong> monthly.";
    } else {
      alertSection.style.display = "block";
      alertMessage.className = "alert alert-success";
      alertMessage.innerHTML = "<strong>Great job!</strong> Your bounce rate of " + bounceRate + "% is within the healthy range. Keep maintaining your email list quality.";
    }

    window.calculatorResults = {
      bounceRate: bounceRate,
      monthlyLost: monthlyRevenueLost,
      annualLost: annualRevenueLost,
      bouncedEmails: bouncedEmails,
      monthlySavings: monthlySavings,
      annualSavings: annualSavings,
    };
  }

  function updateRangeDisplay(rangeId, displayId, suffix) {
    var range = document.getElementById(rangeId);
    var display = document.getElementById(displayId);
    display.textContent = range.value + suffix;
  }

  document.addEventListener("DOMContentLoaded", function initCalculator() {
    var inputs = ["team-size", "emails-per-sdr", "avg-deal"];
    inputs.forEach(function setupInput(id) {
      document.getElementById(id).addEventListener("input", calculateBounceCost);
    });

    document.getElementById("bounce-rate").addEventListener("input", function handleBounce() {
      updateRangeDisplay("bounce-rate", "bounce-rate-value", "%");
      calculateBounceCost();
    });

    document.getElementById("reply-rate").addEventListener("input", function handleReply() {
      updateRangeDisplay("reply-rate", "reply-rate-value", "%");
      calculateBounceCost();
    });

    document.getElementById("close-rate").addEventListener("input", function handleClose() {
      updateRangeDisplay("close-rate", "close-rate-value", "%");
      calculateBounceCost();
    });

    document.getElementById("copy-results").addEventListener("click", function copyResults() {
      var results = window.calculatorResults || {};
      var text = "Email Bounce Cost Analysis\\n";
      text += "==========================\\n\\n";
      text += "Current Bounce Rate: " + results.bounceRate + "%\\n";
      text += "Monthly Revenue Lost: $" + Math.round(results.monthlyLost).toLocaleString() + "\\n";
      text += "Annual Revenue Lost: $" + Math.round(results.annualLost).toLocaleString() + "\\n";
      text += "Bounced Emails/Month: " + results.bouncedEmails.toLocaleString() + "\\n\\n";
      text += "Potential Savings (at 2% bounce rate):\\n";
      text += "- Monthly: $" + Math.round(results.monthlySavings).toLocaleString() + "\\n";
      text += "- Annual: $" + Math.round(results.annualSavings).toLocaleString() + "\\n\\n";
      text += "Calculated with FindForce Bounce Cost Calculator\\n";
      text += "https://findforce.io/tools/bounce-cost-calculator";

      navigator.clipboard.writeText(text).then(function onCopy() {
        var btn = document.getElementById("copy-results");
        btn.textContent = "Copied!";
        setTimeout(function resetBtn() {
          btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy Results';
        }, 2000);
      });

      if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
        window.pirsch("bounce_cost_calculated", {
          meta: {
            bounce_rate: results.bounceRate,
            monthly_lost: Math.round(results.monthlyLost),
            annual_savings: Math.round(results.annualSavings),
          },
        });
      }
    });

    calculateBounceCost();
  });
<\/script> `], ["", ` <script>
  function calculateBounceCost() {
    var teamSize = parseInt(document.getElementById("team-size").value, 10) || 5;
    var emailsPerSdr = parseInt(document.getElementById("emails-per-sdr").value, 10) || 500;
    var bounceRate = parseInt(document.getElementById("bounce-rate").value, 10) || 15;
    var avgDeal = parseInt(document.getElementById("avg-deal").value, 10) || 5000;
    var replyRate = parseFloat(document.getElementById("reply-rate").value) || 3;
    var closeRate = parseInt(document.getElementById("close-rate").value, 10) || 10;

    var totalEmailsMonth = teamSize * emailsPerSdr;
    var bouncedEmails = Math.round(totalEmailsMonth * (bounceRate / 100));
    var deliveredEmails = totalEmailsMonth - bouncedEmails;

    var expectedReplies = deliveredEmails * (replyRate / 100);
    var expectedDeals = expectedReplies * (closeRate / 100);

    var potentialRepliesLost = bouncedEmails * (replyRate / 100);
    var potentialDealsLost = potentialRepliesLost * (closeRate / 100);

    var monthlyRevenueLost = potentialDealsLost * avgDeal;
    var annualRevenueLost = monthlyRevenueLost * 12;

    var benchmarkBounceRate = 2;
    var benchmarkBouncedEmails = Math.round(totalEmailsMonth * (benchmarkBounceRate / 100));
    var benchmarkPotentialRepliesLost = benchmarkBouncedEmails * (replyRate / 100);
    var benchmarkPotentialDealsLost = benchmarkPotentialRepliesLost * (closeRate / 100);
    var benchmarkMonthlyLost = benchmarkPotentialDealsLost * avgDeal;

    var monthlySavings = monthlyRevenueLost - benchmarkMonthlyLost;
    var annualSavings = monthlySavings * 12;

    document.getElementById("monthly-lost").textContent = "$" + Math.round(monthlyRevenueLost).toLocaleString();
    document.getElementById("annual-lost").textContent = "$" + Math.round(annualRevenueLost).toLocaleString();
    document.getElementById("bounced-count").textContent = bouncedEmails.toLocaleString();
    document.getElementById("lost-opps").textContent = potentialDealsLost.toFixed(1);

    document.getElementById("your-bounce").textContent = bounceRate + "%";
    document.getElementById("your-monthly").textContent = "$" + Math.round(monthlyRevenueLost).toLocaleString();
    document.getElementById("benchmark-monthly").textContent = "$" + Math.round(benchmarkMonthlyLost).toLocaleString();
    document.getElementById("savings-monthly").textContent = "$" + Math.round(monthlySavings).toLocaleString();
    document.getElementById("savings-annual").textContent = "$" + Math.round(annualSavings).toLocaleString();

    var riskLevel, riskColor, riskText;
    if (bounceRate <= 2) {
      riskLevel = 10;
      riskColor = "risk-low";
      riskText = "Excellent - Your sender reputation is protected";
    } else if (bounceRate <= 5) {
      riskLevel = 30;
      riskColor = "risk-moderate";
      riskText = "Good - Minor risk to sender reputation";
    } else if (bounceRate <= 10) {
      riskLevel = 60;
      riskColor = "risk-elevated";
      riskText = "Elevated - ISPs may start flagging your domain";
    } else if (bounceRate <= 20) {
      riskLevel = 80;
      riskColor = "risk-high";
      riskText = "High - Likely impacting email deliverability";
    } else {
      riskLevel = 95;
      riskColor = "risk-critical";
      riskText = "Critical - Immediate action required";
    }

    var riskFill = document.getElementById("risk-fill");
    riskFill.style.width = riskLevel + "%";
    riskFill.className = "risk-fill " + riskColor;
    document.getElementById("risk-label").textContent = riskText;

    var riskIcon = document.getElementById("risk-icon");
    if (bounceRate <= 5) {
      riskIcon.textContent = "✓";
    } else if (bounceRate <= 10) {
      riskIcon.textContent = "⚠️";
    } else {
      riskIcon.textContent = "🚨";
    }

    var alertSection = document.getElementById("alert-section");
    var alertMessage = document.getElementById("alert-message");

    if (bounceRate > 10) {
      alertSection.style.display = "block";
      alertMessage.className = "alert alert-danger";
      alertMessage.innerHTML = "<strong>Critical Risk:</strong> Your bounce rate of " + bounceRate + "% exceeds the 10% threshold. ISPs like Gmail and Outlook will start blocking your emails. You're losing an estimated <strong>$" + Math.round(monthlyRevenueLost).toLocaleString() + "</strong> monthly.";
    } else if (bounceRate > 5) {
      alertSection.style.display = "block";
      alertMessage.className = "alert alert-warning";
      alertMessage.innerHTML = "<strong>Warning:</strong> Your bounce rate of " + bounceRate + "% is above the recommended 2% threshold. Consider implementing email verification to protect your sender reputation.";
    } else if (bounceRate > 2) {
      alertSection.style.display = "block";
      alertMessage.className = "alert alert-info";
      alertMessage.innerHTML = "<strong>Opportunity:</strong> Reducing your bounce rate from " + bounceRate + "% to 2% could save you <strong>$" + Math.round(monthlySavings).toLocaleString() + "</strong> monthly.";
    } else {
      alertSection.style.display = "block";
      alertMessage.className = "alert alert-success";
      alertMessage.innerHTML = "<strong>Great job!</strong> Your bounce rate of " + bounceRate + "% is within the healthy range. Keep maintaining your email list quality.";
    }

    window.calculatorResults = {
      bounceRate: bounceRate,
      monthlyLost: monthlyRevenueLost,
      annualLost: annualRevenueLost,
      bouncedEmails: bouncedEmails,
      monthlySavings: monthlySavings,
      annualSavings: annualSavings,
    };
  }

  function updateRangeDisplay(rangeId, displayId, suffix) {
    var range = document.getElementById(rangeId);
    var display = document.getElementById(displayId);
    display.textContent = range.value + suffix;
  }

  document.addEventListener("DOMContentLoaded", function initCalculator() {
    var inputs = ["team-size", "emails-per-sdr", "avg-deal"];
    inputs.forEach(function setupInput(id) {
      document.getElementById(id).addEventListener("input", calculateBounceCost);
    });

    document.getElementById("bounce-rate").addEventListener("input", function handleBounce() {
      updateRangeDisplay("bounce-rate", "bounce-rate-value", "%");
      calculateBounceCost();
    });

    document.getElementById("reply-rate").addEventListener("input", function handleReply() {
      updateRangeDisplay("reply-rate", "reply-rate-value", "%");
      calculateBounceCost();
    });

    document.getElementById("close-rate").addEventListener("input", function handleClose() {
      updateRangeDisplay("close-rate", "close-rate-value", "%");
      calculateBounceCost();
    });

    document.getElementById("copy-results").addEventListener("click", function copyResults() {
      var results = window.calculatorResults || {};
      var text = "Email Bounce Cost Analysis\\\\n";
      text += "==========================\\\\n\\\\n";
      text += "Current Bounce Rate: " + results.bounceRate + "%\\\\n";
      text += "Monthly Revenue Lost: $" + Math.round(results.monthlyLost).toLocaleString() + "\\\\n";
      text += "Annual Revenue Lost: $" + Math.round(results.annualLost).toLocaleString() + "\\\\n";
      text += "Bounced Emails/Month: " + results.bouncedEmails.toLocaleString() + "\\\\n\\\\n";
      text += "Potential Savings (at 2% bounce rate):\\\\n";
      text += "- Monthly: $" + Math.round(results.monthlySavings).toLocaleString() + "\\\\n";
      text += "- Annual: $" + Math.round(results.annualSavings).toLocaleString() + "\\\\n\\\\n";
      text += "Calculated with FindForce Bounce Cost Calculator\\\\n";
      text += "https://findforce.io/tools/bounce-cost-calculator";

      navigator.clipboard.writeText(text).then(function onCopy() {
        var btn = document.getElementById("copy-results");
        btn.textContent = "Copied!";
        setTimeout(function resetBtn() {
          btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy Results';
        }, 2000);
      });

      if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
        window.pirsch("bounce_cost_calculated", {
          meta: {
            bounce_rate: results.bounceRate,
            monthly_lost: Math.round(results.monthlyLost),
            annual_savings: Math.round(results.annualSavings),
          },
        });
      }
    });

    calculateBounceCost();
  });
<\/script> `])), renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": pageTitle, "description": pageDescription, "canonical": "https://findforce.io/tools/bounce-cost-calculator", "structuredData": structuredData, "data-astro-cid-m5d3zcrl": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="calculator-page" data-astro-cid-m5d3zcrl> <div class="container" data-astro-cid-m5d3zcrl> <header class="header" data-astro-cid-m5d3zcrl> ${renderComponent($$result2, "Logo", $$Logo, { "size": "lg", "data-astro-cid-m5d3zcrl": true })} <h1 data-astro-cid-m5d3zcrl>Email Bounce Cost Calculator</h1> <p class="subtitle" data-astro-cid-m5d3zcrl>
Calculate how much email bounces cost your business. See the real
          impact of bad data on your revenue.
</p> </header> <div class="calculator-wrapper" data-astro-cid-m5d3zcrl> <div class="input-section" data-astro-cid-m5d3zcrl> <h2 data-astro-cid-m5d3zcrl>Your Current Situation</h2> <div class="form-group" data-astro-cid-m5d3zcrl> <label for="team-size" data-astro-cid-m5d3zcrl>Sales Team Size (SDRs)</label> <input type="number" id="team-size" value="5" min="1" max="500" data-astro-cid-m5d3zcrl> </div> <div class="form-group" data-astro-cid-m5d3zcrl> <label for="emails-per-sdr" data-astro-cid-m5d3zcrl>Emails Sent Per SDR/Month</label> <input type="number" id="emails-per-sdr" value="500" min="50" max="5000" step="50" data-astro-cid-m5d3zcrl> </div> <div class="form-group" data-astro-cid-m5d3zcrl> <label for="bounce-rate" data-astro-cid-m5d3zcrl>Current Bounce Rate</label> <div class="range-wrapper" data-astro-cid-m5d3zcrl> <span class="range-value" id="bounce-rate-value" data-astro-cid-m5d3zcrl>15%</span> <input type="range" id="bounce-rate" value="15" min="1" max="40" step="1" data-astro-cid-m5d3zcrl> <div class="range-labels" data-astro-cid-m5d3zcrl> <span data-astro-cid-m5d3zcrl>1%</span> <span class="healthy" data-astro-cid-m5d3zcrl>Healthy: 2%</span> <span data-astro-cid-m5d3zcrl>40%</span> </div> </div> </div> <div class="form-group" data-astro-cid-m5d3zcrl> <label for="avg-deal" data-astro-cid-m5d3zcrl>Average Deal Value ($)</label> <input type="number" id="avg-deal" value="5000" min="100" max="500000" step="100" data-astro-cid-m5d3zcrl> </div> <div class="form-group" data-astro-cid-m5d3zcrl> <label for="reply-rate" data-astro-cid-m5d3zcrl>Average Reply Rate</label> <div class="range-wrapper" data-astro-cid-m5d3zcrl> <span class="range-value" id="reply-rate-value" data-astro-cid-m5d3zcrl>3%</span> <input type="range" id="reply-rate" value="3" min="1" max="15" step="0.5" data-astro-cid-m5d3zcrl> </div> </div> <div class="form-group" data-astro-cid-m5d3zcrl> <label for="close-rate" data-astro-cid-m5d3zcrl>Reply-to-Close Rate</label> <div class="range-wrapper" data-astro-cid-m5d3zcrl> <span class="range-value" id="close-rate-value" data-astro-cid-m5d3zcrl>10%</span> <input type="range" id="close-rate" value="10" min="1" max="30" step="1" data-astro-cid-m5d3zcrl> </div> </div> </div> <div class="results-section" data-astro-cid-m5d3zcrl> <h2 data-astro-cid-m5d3zcrl>Your Bounce Cost Impact</h2> <div class="metric primary" data-astro-cid-m5d3zcrl> <div class="metric-label" data-astro-cid-m5d3zcrl>Monthly Revenue Lost</div> <div class="metric-value" id="monthly-lost" data-astro-cid-m5d3zcrl>$0</div> <div class="metric-detail" data-astro-cid-m5d3zcrl>Due to bounced emails</div> </div> <div class="metric" data-astro-cid-m5d3zcrl> <div class="metric-label" data-astro-cid-m5d3zcrl>Annual Revenue Lost</div> <div class="metric-value" id="annual-lost" data-astro-cid-m5d3zcrl>$0</div> <div class="metric-detail" data-astro-cid-m5d3zcrl>Projected yearly impact</div> </div> <div class="metric" data-astro-cid-m5d3zcrl> <div class="metric-label" data-astro-cid-m5d3zcrl>Bounced Emails/Month</div> <div class="metric-value" id="bounced-count" data-astro-cid-m5d3zcrl>0</div> <div class="metric-detail" data-astro-cid-m5d3zcrl>Wasted sends</div> </div> <div class="metric" data-astro-cid-m5d3zcrl> <div class="metric-label" data-astro-cid-m5d3zcrl>Lost Opportunities</div> <div class="metric-value" id="lost-opps" data-astro-cid-m5d3zcrl>0</div> <div class="metric-detail" data-astro-cid-m5d3zcrl>Potential deals missed</div> </div> <div class="reputation-risk" data-astro-cid-m5d3zcrl> <div class="risk-header" data-astro-cid-m5d3zcrl> <span class="risk-icon" id="risk-icon" data-astro-cid-m5d3zcrl>⚠️</span> <span class="risk-title" data-astro-cid-m5d3zcrl>Sender Reputation Risk</span> </div> <div class="risk-bar" data-astro-cid-m5d3zcrl> <div class="risk-fill" id="risk-fill" data-astro-cid-m5d3zcrl></div> </div> <div class="risk-label" id="risk-label" data-astro-cid-m5d3zcrl>Calculating...</div> </div> </div> </div> <div class="comparison-section" data-astro-cid-m5d3zcrl> <h3 data-astro-cid-m5d3zcrl>Your Numbers vs Industry Benchmarks</h3> <div class="comparison-grid" data-astro-cid-m5d3zcrl> <div class="comparison-card yours" data-astro-cid-m5d3zcrl> <div class="comparison-header" data-astro-cid-m5d3zcrl>Your Current State</div> <div class="comparison-stat" data-astro-cid-m5d3zcrl> <span class="stat-value" id="your-bounce" data-astro-cid-m5d3zcrl>15%</span> <span class="stat-label" data-astro-cid-m5d3zcrl>Bounce Rate</span> </div> <div class="comparison-stat" data-astro-cid-m5d3zcrl> <span class="stat-value" id="your-monthly" data-astro-cid-m5d3zcrl>$0</span> <span class="stat-label" data-astro-cid-m5d3zcrl>Monthly Loss</span> </div> </div> <div class="comparison-card benchmark" data-astro-cid-m5d3zcrl> <div class="comparison-header" data-astro-cid-m5d3zcrl>With 2% Bounce Rate</div> <div class="comparison-stat" data-astro-cid-m5d3zcrl> <span class="stat-value" data-astro-cid-m5d3zcrl>2%</span> <span class="stat-label" data-astro-cid-m5d3zcrl>Bounce Rate</span> </div> <div class="comparison-stat" data-astro-cid-m5d3zcrl> <span class="stat-value" id="benchmark-monthly" data-astro-cid-m5d3zcrl>$0</span> <span class="stat-label" data-astro-cid-m5d3zcrl>Monthly Loss</span> </div> </div> <div class="comparison-card savings" data-astro-cid-m5d3zcrl> <div class="comparison-header" data-astro-cid-m5d3zcrl>Potential Savings</div> <div class="comparison-stat" data-astro-cid-m5d3zcrl> <span class="stat-value" id="savings-monthly" data-astro-cid-m5d3zcrl>$0</span> <span class="stat-label" data-astro-cid-m5d3zcrl>Per Month</span> </div> <div class="comparison-stat" data-astro-cid-m5d3zcrl> <span class="stat-value" id="savings-annual" data-astro-cid-m5d3zcrl>$0</span> <span class="stat-label" data-astro-cid-m5d3zcrl>Per Year</span> </div> </div> </div> </div> <div class="alert-section" id="alert-section" style="display: none;" data-astro-cid-m5d3zcrl> <div class="alert" id="alert-message" data-astro-cid-m5d3zcrl></div> </div> <div class="share-section" data-astro-cid-m5d3zcrl> <button id="copy-results" class="share-btn" data-astro-cid-m5d3zcrl> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-m5d3zcrl> <rect width="14" height="14" x="8" y="8" rx="2" ry="2" data-astro-cid-m5d3zcrl></rect> <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" data-astro-cid-m5d3zcrl></path> </svg>
Copy Results
</button> </div> ${renderComponent($$result2, "Newsletter", $$Newsletter, { "title": "Get monthly email deliverability benchmarks", "subtitle": "Join 2,000+ sales professionals improving their email performance.", "source": "bounce_cost_calculator", "variant": "bounce_cost_calculator", "colorScheme": "purple", "data-astro-cid-m5d3zcrl": true })} <div class="cta-section" data-astro-cid-m5d3zcrl> <h3 data-astro-cid-m5d3zcrl>Reduce your bounce rate to under 2%</h3> <p data-astro-cid-m5d3zcrl>
FindForce guarantees 95% email accuracy with unlimited verifications
          at €49/month flat. Stop losing revenue to bad data.
</p> <a href="https://findforce.io?utm_source=tools&utm_medium=bounce_cost_calculator" class="cta-button" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="bounce_cost_calculator" data-astro-cid-m5d3zcrl>
Start Free Trial
</a> </div> <div class="back-link" data-astro-cid-m5d3zcrl> <a href="/tools" data-astro-cid-m5d3zcrl>← Back to all tools</a> </div> </div> </section> ` }));
}, "/home/runner/work/landing-page/landing-page/src/pages/tools/bounce-cost-calculator.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/tools/bounce-cost-calculator.astro";
const $$url = "/tools/bounce-cost-calculator.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$BounceCostCalculator,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
