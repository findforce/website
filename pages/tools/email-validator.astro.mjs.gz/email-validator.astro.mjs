import { a as createComponent, d as renderTemplate, r as renderComponent, m as maybeRenderHead } from "../../js/astro/server.CiUvenb_.js";
import "kleur/colors";
import { $ as $$BaseLayout, a as $$Logo } from "../../js/BaseLayout.DZxjPdiE.js";
/* empty css                                         */
import { renderers } from "../../renderers.mjs";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$EmailValidator = createComponent(($$result, $$props, $$slots) => {
  var pageTitle = "Email Format Validator - Free Email Syntax Checker";
  var pageDescription = "Check if email addresses are syntactically valid. Detect typos, invalid formats, and disposable email domains. Free bulk validation for up to 50 emails.";
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: "Email Format Validator",
    description: pageDescription,
    url: "https://findforce.io/tools/email-validator",
    applicationCategory: "BusinessApplication",
    offers: {
      "@type": "Offer",
      price: "0",
      priceCurrency: "EUR"
    },
    creator: {
      "@type": "Organization",
      name: "FindForce",
      url: "https://findforce.io"
    }
  };
  return renderTemplate(_a || (_a = __template(["", ` <script>
  var disposableDomains = [
    "tempmail.com", "temp-mail.org", "guerrillamail.com", "10minutemail.com",
    "mailinator.com", "throwaway.email", "fakeinbox.com", "maildrop.cc",
    "dispostable.com", "yopmail.com", "getnada.com", "trashmail.com",
    "sharklasers.com", "spam4.me", "grr.la", "tempail.com", "mohmal.com",
    "emailondeck.com", "mytemp.email", "burnermail.io", "minutemail.com"
  ];

  var typoMap = {
    "gmial.com": "gmail.com",
    "gmai.com": "gmail.com",
    "gamil.com": "gmail.com",
    "gnail.com": "gmail.com",
    "gmail.co": "gmail.com",
    "gmal.com": "gmail.com",
    "gmail.con": "gmail.com",
    "outlok.com": "outlook.com",
    "outloo.com": "outlook.com",
    "outlook.co": "outlook.com",
    "hotmal.com": "hotmail.com",
    "hotmai.com": "hotmail.com",
    "hotmail.co": "hotmail.com",
    "yahooo.com": "yahoo.com",
    "yaho.com": "yahoo.com",
    "yahoo.co": "yahoo.com",
    "yahoomail.com": "yahoo.com",
  };

  var roleAddresses = [
    "info", "support", "admin", "sales", "contact", "help", "marketing",
    "noreply", "no-reply", "webmaster", "postmaster", "abuse", "hello",
    "team", "office", "hr", "jobs", "billing", "accounts"
  ];

  var emailRegex = /^(?:[a-zA-Z0-9!#$%&'*+/=?^_\`{|}~-]+(?:\\.[a-zA-Z0-9!#$%&'*+/=?^_\`{|}~-]+)*|"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*")@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+[a-zA-Z]{2,}|(?:\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)]))/;

  function validateEmail(email) {
    email = email.trim().toLowerCase();

    var result = {
      email: email,
      valid: true,
      status: "valid",
      issues: [],
      warnings: [],
      suggestion: null,
    };

    if (!email) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Email address is empty");
      return result;
    }

    if (!email.includes("@")) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Missing @ symbol");
      return result;
    }

    var parts = email.split("@");
    if (parts.length !== 2) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Invalid email format (multiple @ symbols)");
      return result;
    }

    var localPart = parts[0];
    var domain = parts[1];

    if (!localPart) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Missing local part (before @)");
      return result;
    }

    if (!domain) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Missing domain (after @)");
      return result;
    }

    if (!domain.includes(".")) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Domain missing extension (e.g., .com)");
      return result;
    }

    if (!emailRegex.test(email)) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Invalid email format per RFC 5322");
      return result;
    }

    if (typoMap[domain]) {
      result.status = "warning";
      result.warnings.push("Possible typo in domain: " + domain);
      result.suggestion = localPart + "@" + typoMap[domain];
    }

    if (disposableDomains.includes(domain)) {
      result.status = "warning";
      result.warnings.push("Disposable/temporary email domain detected");
    }

    var localPartLower = localPart.toLowerCase();
    if (roleAddresses.includes(localPartLower)) {
      result.warnings.push("Role-based address (may have multiple recipients)");
      if (result.status === "valid") {
        result.status = "warning";
      }
    }

    if (localPart.length > 64) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Local part exceeds 64 characters");
    }

    if (domain.length > 255) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Domain exceeds 255 characters");
    }

    if (/^\\./.test(localPart) || /\\.$/.test(localPart)) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Local part cannot start or end with a period");
    }

    if (/\\.\\./.test(localPart)) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Local part cannot contain consecutive periods");
    }

    return result;
  }

  function displaySingleResult(result) {
    var resultSection = document.getElementById("result-section");
    var resultCard = document.getElementById("result-card");
    var resultIcon = document.getElementById("result-icon");
    var resultStatus = document.getElementById("result-status");
    var resultEmail = document.getElementById("result-email");
    var resultDetails = document.getElementById("result-details");

    resultSection.style.display = "block";

    resultCard.className = "result-card result-" + result.status;

    if (result.status === "valid") {
      resultIcon.innerHTML = "✓";
      resultStatus.textContent = "Valid Email Format";
    } else if (result.status === "warning") {
      resultIcon.innerHTML = "⚠";
      resultStatus.textContent = "Valid with Warnings";
    } else {
      resultIcon.innerHTML = "✗";
      resultStatus.textContent = "Invalid Email Format";
    }

    resultEmail.textContent = result.email;

    var detailsHtml = "";

    if (result.issues.length > 0) {
      detailsHtml += '<div class="issues">';
      result.issues.forEach(function addIssue(issue) {
        detailsHtml += '<div class="detail-item issue"><span class="detail-icon">✗</span>' + issue + '</div>';
      });
      detailsHtml += '</div>';
    }

    if (result.warnings.length > 0) {
      detailsHtml += '<div class="warnings">';
      result.warnings.forEach(function addWarning(warning) {
        detailsHtml += '<div class="detail-item warning"><span class="detail-icon">⚠</span>' + warning + '</div>';
      });
      detailsHtml += '</div>';
    }

    if (result.suggestion) {
      detailsHtml += '<div class="suggestion">';
      detailsHtml += '<span class="detail-icon">💡</span>';
      detailsHtml += 'Did you mean: <button class="suggestion-btn" data-email="' + result.suggestion + '">' + result.suggestion + '</button>';
      detailsHtml += '</div>';
    }

    if (result.status === "valid" && result.issues.length === 0 && result.warnings.length === 0) {
      detailsHtml = '<div class="detail-item valid"><span class="detail-icon">✓</span>Email format is syntactically correct</div>';
    }

    resultDetails.innerHTML = detailsHtml;

    var suggestionBtn = resultDetails.querySelector(".suggestion-btn");
    if (suggestionBtn) {
      suggestionBtn.addEventListener("click", function useSuggestion() {
        document.getElementById("email-input").value = suggestionBtn.dataset.email;
        validateSingle();
      });
    }

    if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
      window.pirsch("email_validated", {
        meta: {
          status: result.status,
          has_typo: result.suggestion ? "yes" : "no",
          is_disposable: result.warnings.some(function checkDisposable(w) {
            return w.includes("Disposable");
          }) ? "yes" : "no",
        },
      });
    }
  }

  function displayBulkResults(results) {
    var bulkResults = document.getElementById("bulk-results");
    var bulkList = document.getElementById("bulk-list");

    var validCount = 0;
    var invalidCount = 0;
    var warningCount = 0;
    var validEmails = [];

    results.forEach(function countResults(r) {
      if (r.status === "valid") {
        validCount++;
        validEmails.push(r.email);
      } else if (r.status === "warning") {
        warningCount++;
        validEmails.push(r.email);
      } else {
        invalidCount++;
      }
    });

    document.getElementById("valid-count").textContent = validCount;
    document.getElementById("invalid-count").textContent = invalidCount;
    document.getElementById("warning-count").textContent = warningCount;

    // Clear any previous results
    bulkList.innerHTML = "";
    results.forEach(function renderResult(r) {
      var statusIcon = r.status === "valid" ? "✓" : r.status === "warning" ? "⚠" : "✗";
      var statusClass = "bulk-item-" + r.status;
      var details = r.issues.concat(r.warnings).join(", ") || "Valid";

      var itemDiv = document.createElement("div");
      itemDiv.className = "bulk-item " + statusClass;

      var iconSpan = document.createElement("span");
      iconSpan.className = "bulk-icon";
      iconSpan.textContent = statusIcon;
      itemDiv.appendChild(iconSpan);

      var emailSpan = document.createElement("span");
      emailSpan.className = "bulk-email";
      emailSpan.textContent = r.email;
      itemDiv.appendChild(emailSpan);

      var detailsSpan = document.createElement("span");
      detailsSpan.className = "bulk-details";
      detailsSpan.textContent = details;
      itemDiv.appendChild(detailsSpan);

      bulkList.appendChild(itemDiv);
    });
    bulkResults.style.display = "block";

    document.getElementById("copy-bulk").onclick = function copyValid() {
      navigator.clipboard.writeText(validEmails.join("\\n")).then(function onCopy() {
        var btn = document.getElementById("copy-bulk");
        btn.textContent = "Copied " + validEmails.length + " emails!";
        setTimeout(function resetBtn() {
          btn.textContent = "Copy Valid Emails";
        }, 2000);
      }).catch(function onCopyError(err) {
        var btn = document.getElementById("copy-bulk");
        btn.textContent = "Copy failed";
        setTimeout(function resetBtn() {
          btn.textContent = "Copy Valid Emails";
        }, 2000);
        // Optionally, log the error for debugging
        // console.error("Clipboard copy failed:", err);
      });
    };

    if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
      window.pirsch("bulk_emails_validated", {
        meta: {
          total: results.length,
          valid: validCount,
          invalid: invalidCount,
          warnings: warningCount,
        },
      });
    }
  }

  function validateSingle() {
    var input = document.getElementById("email-input");
    var email = input.value.trim();

    if (!email) {
      alert("Please enter an email address");
      return;
    }

    var result = validateEmail(email);
    displaySingleResult(result);
  }

  function validateBulk() {
    var textarea = document.getElementById("bulk-input");
    var emails = textarea.value.split("\\n").filter(function filterEmpty(e) {
      return e.trim();
    }).slice(0, 50);

    if (emails.length === 0) {
      alert("Please enter at least one email address");
      return;
    }

    var results = emails.map(validateEmail);
    displayBulkResults(results);
  }

  document.addEventListener("DOMContentLoaded", function initValidator() {
    var singleModeBtn = document.getElementById("single-mode-btn");
    var bulkModeBtn = document.getElementById("bulk-mode-btn");
    var singleMode = document.getElementById("single-mode");
    var bulkMode = document.getElementById("bulk-mode");
    var resultSection = document.getElementById("result-section");
    var bulkResults = document.getElementById("bulk-results");

    singleModeBtn.addEventListener("click", function showSingle() {
      singleModeBtn.classList.add("active");
      bulkModeBtn.classList.remove("active");
      singleMode.style.display = "block";
      bulkMode.style.display = "none";
      resultSection.style.display = "none";
      bulkResults.style.display = "none";
    });

    bulkModeBtn.addEventListener("click", function showBulk() {
      bulkModeBtn.classList.add("active");
      singleModeBtn.classList.remove("active");
      bulkMode.style.display = "block";
      singleMode.style.display = "none";
      resultSection.style.display = "none";
      bulkResults.style.display = "none";
    });

    document.getElementById("validate-btn").addEventListener("click", validateSingle);

    document.getElementById("email-input").addEventListener("keypress", function handleEnter(e) {
      if (e.key === "Enter") {
        validateSingle();
      }
    });

    document.getElementById("validate-bulk-btn").addEventListener("click", validateBulk);

    document.getElementById("bulk-input").addEventListener("input", function updateCount() {
      var lines = this.value.split("\\n").filter(function filterEmpty(l) {
        return l.trim();
      });
      document.getElementById("email-count").textContent = Math.min(lines.length, 50);
    });

    document.querySelectorAll(".example-chip").forEach(function setupExample(chip) {
      chip.addEventListener("click", function useExample() {
        document.getElementById("email-input").value = chip.dataset.email;
        singleModeBtn.click();
        validateSingle();
      });
    });
  });
<\/script> `], ["", ` <script>
  var disposableDomains = [
    "tempmail.com", "temp-mail.org", "guerrillamail.com", "10minutemail.com",
    "mailinator.com", "throwaway.email", "fakeinbox.com", "maildrop.cc",
    "dispostable.com", "yopmail.com", "getnada.com", "trashmail.com",
    "sharklasers.com", "spam4.me", "grr.la", "tempail.com", "mohmal.com",
    "emailondeck.com", "mytemp.email", "burnermail.io", "minutemail.com"
  ];

  var typoMap = {
    "gmial.com": "gmail.com",
    "gmai.com": "gmail.com",
    "gamil.com": "gmail.com",
    "gnail.com": "gmail.com",
    "gmail.co": "gmail.com",
    "gmal.com": "gmail.com",
    "gmail.con": "gmail.com",
    "outlok.com": "outlook.com",
    "outloo.com": "outlook.com",
    "outlook.co": "outlook.com",
    "hotmal.com": "hotmail.com",
    "hotmai.com": "hotmail.com",
    "hotmail.co": "hotmail.com",
    "yahooo.com": "yahoo.com",
    "yaho.com": "yahoo.com",
    "yahoo.co": "yahoo.com",
    "yahoomail.com": "yahoo.com",
  };

  var roleAddresses = [
    "info", "support", "admin", "sales", "contact", "help", "marketing",
    "noreply", "no-reply", "webmaster", "postmaster", "abuse", "hello",
    "team", "office", "hr", "jobs", "billing", "accounts"
  ];

  var emailRegex = /^(?:[a-zA-Z0-9!#$%&'*+/=?^_\\\`{|}~-]+(?:\\\\.[a-zA-Z0-9!#$%&'*+/=?^_\\\`{|}~-]+)*|"(?:[\\\\x01-\\\\x08\\\\x0b\\\\x0c\\\\x0e-\\\\x1f\\\\x21\\\\x23-\\\\x5b\\\\x5d-\\\\x7f]|\\\\\\\\[\\\\x01-\\\\x09\\\\x0b\\\\x0c\\\\x0e-\\\\x7f])*")@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\\\\.)+[a-zA-Z]{2,}|(?:\\\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)]))/;

  function validateEmail(email) {
    email = email.trim().toLowerCase();

    var result = {
      email: email,
      valid: true,
      status: "valid",
      issues: [],
      warnings: [],
      suggestion: null,
    };

    if (!email) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Email address is empty");
      return result;
    }

    if (!email.includes("@")) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Missing @ symbol");
      return result;
    }

    var parts = email.split("@");
    if (parts.length !== 2) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Invalid email format (multiple @ symbols)");
      return result;
    }

    var localPart = parts[0];
    var domain = parts[1];

    if (!localPart) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Missing local part (before @)");
      return result;
    }

    if (!domain) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Missing domain (after @)");
      return result;
    }

    if (!domain.includes(".")) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Domain missing extension (e.g., .com)");
      return result;
    }

    if (!emailRegex.test(email)) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Invalid email format per RFC 5322");
      return result;
    }

    if (typoMap[domain]) {
      result.status = "warning";
      result.warnings.push("Possible typo in domain: " + domain);
      result.suggestion = localPart + "@" + typoMap[domain];
    }

    if (disposableDomains.includes(domain)) {
      result.status = "warning";
      result.warnings.push("Disposable/temporary email domain detected");
    }

    var localPartLower = localPart.toLowerCase();
    if (roleAddresses.includes(localPartLower)) {
      result.warnings.push("Role-based address (may have multiple recipients)");
      if (result.status === "valid") {
        result.status = "warning";
      }
    }

    if (localPart.length > 64) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Local part exceeds 64 characters");
    }

    if (domain.length > 255) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Domain exceeds 255 characters");
    }

    if (/^\\\\./.test(localPart) || /\\\\.$/.test(localPart)) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Local part cannot start or end with a period");
    }

    if (/\\\\.\\\\./.test(localPart)) {
      result.valid = false;
      result.status = "invalid";
      result.issues.push("Local part cannot contain consecutive periods");
    }

    return result;
  }

  function displaySingleResult(result) {
    var resultSection = document.getElementById("result-section");
    var resultCard = document.getElementById("result-card");
    var resultIcon = document.getElementById("result-icon");
    var resultStatus = document.getElementById("result-status");
    var resultEmail = document.getElementById("result-email");
    var resultDetails = document.getElementById("result-details");

    resultSection.style.display = "block";

    resultCard.className = "result-card result-" + result.status;

    if (result.status === "valid") {
      resultIcon.innerHTML = "✓";
      resultStatus.textContent = "Valid Email Format";
    } else if (result.status === "warning") {
      resultIcon.innerHTML = "⚠";
      resultStatus.textContent = "Valid with Warnings";
    } else {
      resultIcon.innerHTML = "✗";
      resultStatus.textContent = "Invalid Email Format";
    }

    resultEmail.textContent = result.email;

    var detailsHtml = "";

    if (result.issues.length > 0) {
      detailsHtml += '<div class="issues">';
      result.issues.forEach(function addIssue(issue) {
        detailsHtml += '<div class="detail-item issue"><span class="detail-icon">✗</span>' + issue + '</div>';
      });
      detailsHtml += '</div>';
    }

    if (result.warnings.length > 0) {
      detailsHtml += '<div class="warnings">';
      result.warnings.forEach(function addWarning(warning) {
        detailsHtml += '<div class="detail-item warning"><span class="detail-icon">⚠</span>' + warning + '</div>';
      });
      detailsHtml += '</div>';
    }

    if (result.suggestion) {
      detailsHtml += '<div class="suggestion">';
      detailsHtml += '<span class="detail-icon">💡</span>';
      detailsHtml += 'Did you mean: <button class="suggestion-btn" data-email="' + result.suggestion + '">' + result.suggestion + '</button>';
      detailsHtml += '</div>';
    }

    if (result.status === "valid" && result.issues.length === 0 && result.warnings.length === 0) {
      detailsHtml = '<div class="detail-item valid"><span class="detail-icon">✓</span>Email format is syntactically correct</div>';
    }

    resultDetails.innerHTML = detailsHtml;

    var suggestionBtn = resultDetails.querySelector(".suggestion-btn");
    if (suggestionBtn) {
      suggestionBtn.addEventListener("click", function useSuggestion() {
        document.getElementById("email-input").value = suggestionBtn.dataset.email;
        validateSingle();
      });
    }

    if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
      window.pirsch("email_validated", {
        meta: {
          status: result.status,
          has_typo: result.suggestion ? "yes" : "no",
          is_disposable: result.warnings.some(function checkDisposable(w) {
            return w.includes("Disposable");
          }) ? "yes" : "no",
        },
      });
    }
  }

  function displayBulkResults(results) {
    var bulkResults = document.getElementById("bulk-results");
    var bulkList = document.getElementById("bulk-list");

    var validCount = 0;
    var invalidCount = 0;
    var warningCount = 0;
    var validEmails = [];

    results.forEach(function countResults(r) {
      if (r.status === "valid") {
        validCount++;
        validEmails.push(r.email);
      } else if (r.status === "warning") {
        warningCount++;
        validEmails.push(r.email);
      } else {
        invalidCount++;
      }
    });

    document.getElementById("valid-count").textContent = validCount;
    document.getElementById("invalid-count").textContent = invalidCount;
    document.getElementById("warning-count").textContent = warningCount;

    // Clear any previous results
    bulkList.innerHTML = "";
    results.forEach(function renderResult(r) {
      var statusIcon = r.status === "valid" ? "✓" : r.status === "warning" ? "⚠" : "✗";
      var statusClass = "bulk-item-" + r.status;
      var details = r.issues.concat(r.warnings).join(", ") || "Valid";

      var itemDiv = document.createElement("div");
      itemDiv.className = "bulk-item " + statusClass;

      var iconSpan = document.createElement("span");
      iconSpan.className = "bulk-icon";
      iconSpan.textContent = statusIcon;
      itemDiv.appendChild(iconSpan);

      var emailSpan = document.createElement("span");
      emailSpan.className = "bulk-email";
      emailSpan.textContent = r.email;
      itemDiv.appendChild(emailSpan);

      var detailsSpan = document.createElement("span");
      detailsSpan.className = "bulk-details";
      detailsSpan.textContent = details;
      itemDiv.appendChild(detailsSpan);

      bulkList.appendChild(itemDiv);
    });
    bulkResults.style.display = "block";

    document.getElementById("copy-bulk").onclick = function copyValid() {
      navigator.clipboard.writeText(validEmails.join("\\\\n")).then(function onCopy() {
        var btn = document.getElementById("copy-bulk");
        btn.textContent = "Copied " + validEmails.length + " emails!";
        setTimeout(function resetBtn() {
          btn.textContent = "Copy Valid Emails";
        }, 2000);
      }).catch(function onCopyError(err) {
        var btn = document.getElementById("copy-bulk");
        btn.textContent = "Copy failed";
        setTimeout(function resetBtn() {
          btn.textContent = "Copy Valid Emails";
        }, 2000);
        // Optionally, log the error for debugging
        // console.error("Clipboard copy failed:", err);
      });
    };

    if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
      window.pirsch("bulk_emails_validated", {
        meta: {
          total: results.length,
          valid: validCount,
          invalid: invalidCount,
          warnings: warningCount,
        },
      });
    }
  }

  function validateSingle() {
    var input = document.getElementById("email-input");
    var email = input.value.trim();

    if (!email) {
      alert("Please enter an email address");
      return;
    }

    var result = validateEmail(email);
    displaySingleResult(result);
  }

  function validateBulk() {
    var textarea = document.getElementById("bulk-input");
    var emails = textarea.value.split("\\\\n").filter(function filterEmpty(e) {
      return e.trim();
    }).slice(0, 50);

    if (emails.length === 0) {
      alert("Please enter at least one email address");
      return;
    }

    var results = emails.map(validateEmail);
    displayBulkResults(results);
  }

  document.addEventListener("DOMContentLoaded", function initValidator() {
    var singleModeBtn = document.getElementById("single-mode-btn");
    var bulkModeBtn = document.getElementById("bulk-mode-btn");
    var singleMode = document.getElementById("single-mode");
    var bulkMode = document.getElementById("bulk-mode");
    var resultSection = document.getElementById("result-section");
    var bulkResults = document.getElementById("bulk-results");

    singleModeBtn.addEventListener("click", function showSingle() {
      singleModeBtn.classList.add("active");
      bulkModeBtn.classList.remove("active");
      singleMode.style.display = "block";
      bulkMode.style.display = "none";
      resultSection.style.display = "none";
      bulkResults.style.display = "none";
    });

    bulkModeBtn.addEventListener("click", function showBulk() {
      bulkModeBtn.classList.add("active");
      singleModeBtn.classList.remove("active");
      bulkMode.style.display = "block";
      singleMode.style.display = "none";
      resultSection.style.display = "none";
      bulkResults.style.display = "none";
    });

    document.getElementById("validate-btn").addEventListener("click", validateSingle);

    document.getElementById("email-input").addEventListener("keypress", function handleEnter(e) {
      if (e.key === "Enter") {
        validateSingle();
      }
    });

    document.getElementById("validate-bulk-btn").addEventListener("click", validateBulk);

    document.getElementById("bulk-input").addEventListener("input", function updateCount() {
      var lines = this.value.split("\\\\n").filter(function filterEmpty(l) {
        return l.trim();
      });
      document.getElementById("email-count").textContent = Math.min(lines.length, 50);
    });

    document.querySelectorAll(".example-chip").forEach(function setupExample(chip) {
      chip.addEventListener("click", function useExample() {
        document.getElementById("email-input").value = chip.dataset.email;
        singleModeBtn.click();
        validateSingle();
      });
    });
  });
<\/script> `])), renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": pageTitle, "description": pageDescription, "canonical": "https://findforce.io/tools/email-validator", "structuredData": structuredData, "data-astro-cid-mmunwxq3": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="validator-page" data-astro-cid-mmunwxq3> <div class="container" data-astro-cid-mmunwxq3> <header class="header" data-astro-cid-mmunwxq3> ${renderComponent($$result2, "Logo", $$Logo, { "size": "lg", "data-astro-cid-mmunwxq3": true })} <h1 data-astro-cid-mmunwxq3>Email Format Validator</h1> <p class="subtitle" data-astro-cid-mmunwxq3>
Check if email addresses are syntactically valid. Detect typos,
          invalid formats, and disposable domains.
</p> </header> <div class="validator-wrapper" data-astro-cid-mmunwxq3> <div class="mode-toggle" data-astro-cid-mmunwxq3> <button class="mode-btn active" id="single-mode-btn" data-astro-cid-mmunwxq3>Single Email</button> <button class="mode-btn" id="bulk-mode-btn" data-astro-cid-mmunwxq3>Bulk (up to 50)</button> </div> <div class="input-section" id="single-mode" data-astro-cid-mmunwxq3> <div class="form-group" data-astro-cid-mmunwxq3> <label for="email-input" data-astro-cid-mmunwxq3>Email Address</label> <div class="input-wrapper" data-astro-cid-mmunwxq3> <input type="text" id="email-input" placeholder="e.g., john.smith@company.com" autocomplete="off" autocapitalize="off" data-astro-cid-mmunwxq3> <button id="validate-btn" class="validate-btn" data-astro-cid-mmunwxq3>Check</button> </div> </div> </div> <div class="input-section" id="bulk-mode" style="display: none;" data-astro-cid-mmunwxq3> <div class="form-group" data-astro-cid-mmunwxq3> <label for="bulk-input" data-astro-cid-mmunwxq3>Email Addresses (one per line)</label> <textarea id="bulk-input" rows="8" placeholder="john@company.com
jane@example.com
bob@domain.org" data-astro-cid-mmunwxq3></textarea> <div class="bulk-hint" data-astro-cid-mmunwxq3> <span id="email-count" data-astro-cid-mmunwxq3>0</span>/50 emails
</div> </div> <button id="validate-bulk-btn" class="validate-btn full-width" data-astro-cid-mmunwxq3>Validate All</button> </div> <div class="result-section" id="result-section" style="display: none;" data-astro-cid-mmunwxq3> <div class="result-card" id="result-card" data-astro-cid-mmunwxq3> <div class="result-icon" id="result-icon" data-astro-cid-mmunwxq3></div> <div class="result-status" id="result-status" data-astro-cid-mmunwxq3>Checking...</div> <div class="result-email" id="result-email" data-astro-cid-mmunwxq3></div> <div class="result-details" id="result-details" data-astro-cid-mmunwxq3></div> </div> </div> <div class="bulk-results" id="bulk-results" style="display: none;" data-astro-cid-mmunwxq3> <div class="bulk-summary" data-astro-cid-mmunwxq3> <div class="summary-item valid" data-astro-cid-mmunwxq3> <span class="summary-count" id="valid-count" data-astro-cid-mmunwxq3>0</span> <span class="summary-label" data-astro-cid-mmunwxq3>Valid</span> </div> <div class="summary-item invalid" data-astro-cid-mmunwxq3> <span class="summary-count" id="invalid-count" data-astro-cid-mmunwxq3>0</span> <span class="summary-label" data-astro-cid-mmunwxq3>Invalid</span> </div> <div class="summary-item warning" data-astro-cid-mmunwxq3> <span class="summary-count" id="warning-count" data-astro-cid-mmunwxq3>0</span> <span class="summary-label" data-astro-cid-mmunwxq3>Warnings</span> </div> </div> <div class="bulk-list" id="bulk-list" data-astro-cid-mmunwxq3></div> <button id="copy-bulk" class="copy-btn" data-astro-cid-mmunwxq3>Copy Valid Emails</button> </div> <div class="examples-section" data-astro-cid-mmunwxq3> <p class="examples-label" data-astro-cid-mmunwxq3>Try these examples:</p> <div class="example-grid" data-astro-cid-mmunwxq3> <button class="example-chip valid" data-email="john.smith@company.com" data-astro-cid-mmunwxq3>john.smith@company.com</button> <button class="example-chip invalid" data-email="john@gmial.com" data-astro-cid-mmunwxq3>john@gmial.com (typo)</button> <button class="example-chip invalid" data-email="test@tempmail.com" data-astro-cid-mmunwxq3>test@tempmail.com (disposable)</button> <button class="example-chip invalid" data-email="invalid-email" data-astro-cid-mmunwxq3>invalid-email (no @)</button> </div> </div> </div> <div class="info-section" data-astro-cid-mmunwxq3> <h3 data-astro-cid-mmunwxq3>What This Tool Checks</h3> <div class="check-grid" data-astro-cid-mmunwxq3> <div class="check-item" data-astro-cid-mmunwxq3> <span class="check-icon" data-astro-cid-mmunwxq3>✓</span> <div data-astro-cid-mmunwxq3> <strong data-astro-cid-mmunwxq3>RFC 5322 Syntax</strong> <p data-astro-cid-mmunwxq3>Valid email format per internet standards</p> </div> </div> <div class="check-item" data-astro-cid-mmunwxq3> <span class="check-icon" data-astro-cid-mmunwxq3>✓</span> <div data-astro-cid-mmunwxq3> <strong data-astro-cid-mmunwxq3>Common Typos</strong> <p data-astro-cid-mmunwxq3>Detects gmial, outlok, hotmal, etc.</p> </div> </div> <div class="check-item" data-astro-cid-mmunwxq3> <span class="check-icon" data-astro-cid-mmunwxq3>✓</span> <div data-astro-cid-mmunwxq3> <strong data-astro-cid-mmunwxq3>Disposable Domains</strong> <p data-astro-cid-mmunwxq3>Flags temporary email services</p> </div> </div> <div class="check-item" data-astro-cid-mmunwxq3> <span class="check-icon" data-astro-cid-mmunwxq3>✓</span> <div data-astro-cid-mmunwxq3> <strong data-astro-cid-mmunwxq3>Role-Based Addresses</strong> <p data-astro-cid-mmunwxq3>Identifies info@, support@, etc.</p> </div> </div> </div> </div> <div class="newsletter-section" data-astro-cid-mmunwxq3> <h3 data-astro-cid-mmunwxq3>Get email validation best practices</h3> <p data-astro-cid-mmunwxq3>
Join 2,000+ professionals improving their email data quality.
</p> <a href="https://newsletter.meysam.io" target="_blank" rel="noopener noreferrer" class="newsletter-btn" data-pirsch-event="newsletter_cta_clicked" data-pirsch-meta-source="email_validator" data-astro-cid-mmunwxq3>
Subscribe Free
</a> </div> <div class="cta-section" data-astro-cid-mmunwxq3> <h3 data-astro-cid-mmunwxq3>Need deliverability verification?</h3> <p data-astro-cid-mmunwxq3>
Format validation is just the first step. FindForce verifies if emails
          actually exist and will receive your message. 95% accuracy guaranteed.
</p> <a href="https://findforce.io?utm_source=tools&utm_medium=email_validator" class="cta-button" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="email_validator" data-astro-cid-mmunwxq3>
Start Free Trial
</a> </div> <div class="back-link" data-astro-cid-mmunwxq3> <a href="/tools" data-astro-cid-mmunwxq3>← Back to all tools</a> </div> </div> </section> ` }));
}, "/home/runner/work/landing-page/landing-page/src/pages/tools/email-validator.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/tools/email-validator.astro";
const $$url = "/tools/email-validator.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$EmailValidator,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
