import { a as createComponent, d as renderTemplate, r as renderComponent, m as maybeRenderHead } from "../../js/astro/server.CiUvenb_.js";
import "kleur/colors";
import { $ as $$BaseLayout, a as $$Logo } from "../../js/BaseLayout.DZxjPdiE.js";
import { $ as $$Newsletter } from "../../js/Newsletter.C7Q9rGOC.js";
/* empty css                                                   */
import { renderers } from "../../renderers.mjs";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$GdprColdEmailChecklist = createComponent(($$result, $$props, $$slots) => {
  var pageTitle = "GDPR Cold Email Compliance Checklist - Free Assessment";
  var pageDescription = "Interactive checklist to verify your B2B cold outreach is GDPR compliant. Get instant yes/no compliance status with prioritized action items. Free tool for EU sales teams.";
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: "GDPR Cold Email Compliance Checklist",
    description: pageDescription,
    url: "https://findforce.io/tools/gdpr-cold-email-checklist",
    applicationCategory: "BusinessApplication",
    offers: {
      "@type": "Offer",
      price: "0",
      priceCurrency: "EUR"
    },
    creator: {
      "@type": "Organization",
      name: "FindForce",
      url: "https://findforce.io"
    }
  };
  return renderTemplate(_a || (_a = __template(["", ` <script>
  var questionMeta = {
    q1: { category: "critical", title: "Create a Legitimate Interest Assessment (LIA)" },
    q2: { category: "critical", title: "Establish business relevance criteria for prospecting" },
    q3: { category: "high", title: "Implement data source tracking for all contacts" },
    q4: { category: "critical", title: "Stop using purchased lists and scraped data" },
    q5: { category: "high", title: "Add clear opt-out links to all emails" },
    q6: { category: "medium", title: "Automate opt-out request processing" },
    q7: { category: "medium", title: "Update email templates with company identification" },
    q8: { category: "high", title: "Define and implement data retention policy" },
    q9: { category: "medium", title: "Create DSAR response procedure" },
    q10: { category: "high", title: "Obtain DPAs from all data processors" },
    q11: { category: "medium", title: "Audit tool data storage locations" },
    q12: { category: "medium", title: "Schedule GDPR training for sales team" },
  };

  var totalQuestions = 12;

  function updateProgress() {
    var answered = document.querySelectorAll('input[type="radio"]:checked').length;
    document.getElementById("answered-count").textContent = answered;
    var percentage = (answered / totalQuestions) * 100;
    document.getElementById("progress-fill").style.width = percentage + "%";
  }

  function calculateCompliance() {
    var yesCount = 0;
    var noCount = 0;
    var unsureCount = 0;
    var actionItems = [];

    for (var i = 1; i <= totalQuestions; i++) {
      var name = "q" + i;
      var selected = document.querySelector('input[name="' + name + '"]:checked');

      if (!selected) {
        alert("Please answer all questions before checking compliance.");
        return;
      }

      var value = selected.value;
      var meta = questionMeta[name];

      if (value === "yes") {
        yesCount++;
      } else if (value === "no") {
        noCount++;
        actionItems.push({
          priority: meta.category,
          title: meta.title,
          status: "non-compliant",
        });
      } else {
        unsureCount++;
        actionItems.push({
          priority: meta.category,
          title: meta.title + " (needs clarification)",
          status: "uncertain",
        });
      }
    }

    var complianceScore = Math.round((yesCount / totalQuestions) * 100);

    displayResults(complianceScore, yesCount, noCount, unsureCount, actionItems);
  }

  function displayResults(score, yes, no, unsure, actions) {
    document.getElementById("results-section").style.display = "block";

    var badge = document.getElementById("compliance-badge");
    var badgeIcon = document.getElementById("badge-icon");
    var badgeStatus = document.getElementById("badge-status");

    if (score >= 90) {
      badge.className = "compliance-badge badge-compliant";
      badgeIcon.innerHTML = "✓";
      badgeStatus.textContent = "GDPR Ready";
    } else if (score >= 60) {
      badge.className = "compliance-badge badge-warning";
      badgeIcon.innerHTML = "⚠";
      badgeStatus.textContent = "Action Needed";
    } else {
      badge.className = "compliance-badge badge-risk";
      badgeIcon.innerHTML = "✗";
      badgeStatus.textContent = "High Risk";
    }

    animateScore("compliance-score", score);

    document.getElementById("yes-count").textContent = yes;
    document.getElementById("no-count").textContent = no;
    document.getElementById("unsure-count").textContent = unsure;

    var priorityOrder = { critical: 1, high: 2, medium: 3 };
    actions.sort(function sortActions(a, b) {
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

    var actionList = document.getElementById("action-list");
    if (actions.length > 0) {
      actionList.innerHTML = actions.map(function renderAction(action) {
        var priorityLabel = action.priority.charAt(0).toUpperCase() + action.priority.slice(1);
        var statusClass = action.status === "non-compliant" ? "action-critical" : "action-warning";
        return '<div class="action-item ' + statusClass + '">' +
          '<span class="action-priority priority-' + action.priority + '">' + priorityLabel + '</span>' +
          '<span class="action-title">' + action.title + '</span>' +
          '</div>';
      }).join("");
    } else {
      actionList.innerHTML = '<div class="action-item action-success"><span class="action-title">No action items - you\\'re fully compliant!</span></div>';
    }

    document.getElementById("results-section").scrollIntoView({ behavior: "smooth", block: "start" });

    document.getElementById("copy-results").onclick = function copyResults() {
      var text = "GDPR Cold Email Compliance Check\\n";
      text += "================================\\n";
      text += "Compliance Score: " + score + "%\\n";
      text += "Status: " + document.getElementById("badge-status").textContent + "\\n\\n";
      text += "Breakdown:\\n";
      text += "- Compliant: " + yes + "\\n";
      text += "- Non-Compliant: " + no + "\\n";
      text += "- Uncertain: " + unsure + "\\n\\n";
      if (actions.length > 0) {
        text += "Action Items:\\n";
        actions.forEach(function addAction(a) {
          text += "- [" + a.priority.toUpperCase() + "] " + a.title + "\\n";
        });
      }
      text += "\\nChecked with FindForce GDPR Checklist\\nhttps://findforce.io/tools/gdpr-cold-email-checklist";

      navigator.clipboard.writeText(text).then(function onCopy() {
        var btn = document.getElementById("copy-results");
        btn.textContent = "Copied!";
        setTimeout(function resetBtn() {
          btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy Results';
        }, 2000);
      });
    };

    document.getElementById("restart-btn").onclick = function restart() {
      document.querySelectorAll('input[type="radio"]').forEach(function clearRadio(radio) {
        radio.checked = false;
        radio.closest(".option-btn").classList.remove("selected");
      });
      document.getElementById("results-section").style.display = "none";
      updateProgress();
      window.scrollTo({ top: 0, behavior: "smooth" });
    };

    if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
      window.pirsch("gdpr_checklist_completed", {
        meta: {
          compliance_score: score,
          yes_count: yes,
          no_count: no,
          unsure_count: unsure,
        },
      });
    }
  }

  function animateScore(elementId, targetValue) {
    var element = document.getElementById(elementId);
    var current = 0;
    var increment = targetValue / 30;
    var interval = setInterval(function updateScore() {
      current += increment;
      if (current >= targetValue) {
        current = targetValue;
        clearInterval(interval);
      }
      element.textContent = Math.round(current);
    }, 20);
  }

  document.addEventListener("DOMContentLoaded", function initChecklist() {
    document.querySelectorAll('input[type="radio"]').forEach(function setupRadio(radio) {
      radio.addEventListener("change", function handleChange() {
        var name = radio.name;
        document.querySelectorAll('input[name="' + name + '"]').forEach(function updateBtn(r) {
          r.closest(".option-btn").classList.remove("selected");
        });
        radio.closest(".option-btn").classList.add("selected");
        updateProgress();
      });
    });

    document.getElementById("calculate-btn").addEventListener("click", calculateCompliance);

    document.getElementById("total-count").textContent = totalQuestions;
  });
<\/script> `], ["", ` <script>
  var questionMeta = {
    q1: { category: "critical", title: "Create a Legitimate Interest Assessment (LIA)" },
    q2: { category: "critical", title: "Establish business relevance criteria for prospecting" },
    q3: { category: "high", title: "Implement data source tracking for all contacts" },
    q4: { category: "critical", title: "Stop using purchased lists and scraped data" },
    q5: { category: "high", title: "Add clear opt-out links to all emails" },
    q6: { category: "medium", title: "Automate opt-out request processing" },
    q7: { category: "medium", title: "Update email templates with company identification" },
    q8: { category: "high", title: "Define and implement data retention policy" },
    q9: { category: "medium", title: "Create DSAR response procedure" },
    q10: { category: "high", title: "Obtain DPAs from all data processors" },
    q11: { category: "medium", title: "Audit tool data storage locations" },
    q12: { category: "medium", title: "Schedule GDPR training for sales team" },
  };

  var totalQuestions = 12;

  function updateProgress() {
    var answered = document.querySelectorAll('input[type="radio"]:checked').length;
    document.getElementById("answered-count").textContent = answered;
    var percentage = (answered / totalQuestions) * 100;
    document.getElementById("progress-fill").style.width = percentage + "%";
  }

  function calculateCompliance() {
    var yesCount = 0;
    var noCount = 0;
    var unsureCount = 0;
    var actionItems = [];

    for (var i = 1; i <= totalQuestions; i++) {
      var name = "q" + i;
      var selected = document.querySelector('input[name="' + name + '"]:checked');

      if (!selected) {
        alert("Please answer all questions before checking compliance.");
        return;
      }

      var value = selected.value;
      var meta = questionMeta[name];

      if (value === "yes") {
        yesCount++;
      } else if (value === "no") {
        noCount++;
        actionItems.push({
          priority: meta.category,
          title: meta.title,
          status: "non-compliant",
        });
      } else {
        unsureCount++;
        actionItems.push({
          priority: meta.category,
          title: meta.title + " (needs clarification)",
          status: "uncertain",
        });
      }
    }

    var complianceScore = Math.round((yesCount / totalQuestions) * 100);

    displayResults(complianceScore, yesCount, noCount, unsureCount, actionItems);
  }

  function displayResults(score, yes, no, unsure, actions) {
    document.getElementById("results-section").style.display = "block";

    var badge = document.getElementById("compliance-badge");
    var badgeIcon = document.getElementById("badge-icon");
    var badgeStatus = document.getElementById("badge-status");

    if (score >= 90) {
      badge.className = "compliance-badge badge-compliant";
      badgeIcon.innerHTML = "✓";
      badgeStatus.textContent = "GDPR Ready";
    } else if (score >= 60) {
      badge.className = "compliance-badge badge-warning";
      badgeIcon.innerHTML = "⚠";
      badgeStatus.textContent = "Action Needed";
    } else {
      badge.className = "compliance-badge badge-risk";
      badgeIcon.innerHTML = "✗";
      badgeStatus.textContent = "High Risk";
    }

    animateScore("compliance-score", score);

    document.getElementById("yes-count").textContent = yes;
    document.getElementById("no-count").textContent = no;
    document.getElementById("unsure-count").textContent = unsure;

    var priorityOrder = { critical: 1, high: 2, medium: 3 };
    actions.sort(function sortActions(a, b) {
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

    var actionList = document.getElementById("action-list");
    if (actions.length > 0) {
      actionList.innerHTML = actions.map(function renderAction(action) {
        var priorityLabel = action.priority.charAt(0).toUpperCase() + action.priority.slice(1);
        var statusClass = action.status === "non-compliant" ? "action-critical" : "action-warning";
        return '<div class="action-item ' + statusClass + '">' +
          '<span class="action-priority priority-' + action.priority + '">' + priorityLabel + '</span>' +
          '<span class="action-title">' + action.title + '</span>' +
          '</div>';
      }).join("");
    } else {
      actionList.innerHTML = '<div class="action-item action-success"><span class="action-title">No action items - you\\\\'re fully compliant!</span></div>';
    }

    document.getElementById("results-section").scrollIntoView({ behavior: "smooth", block: "start" });

    document.getElementById("copy-results").onclick = function copyResults() {
      var text = "GDPR Cold Email Compliance Check\\\\n";
      text += "================================\\\\n";
      text += "Compliance Score: " + score + "%\\\\n";
      text += "Status: " + document.getElementById("badge-status").textContent + "\\\\n\\\\n";
      text += "Breakdown:\\\\n";
      text += "- Compliant: " + yes + "\\\\n";
      text += "- Non-Compliant: " + no + "\\\\n";
      text += "- Uncertain: " + unsure + "\\\\n\\\\n";
      if (actions.length > 0) {
        text += "Action Items:\\\\n";
        actions.forEach(function addAction(a) {
          text += "- [" + a.priority.toUpperCase() + "] " + a.title + "\\\\n";
        });
      }
      text += "\\\\nChecked with FindForce GDPR Checklist\\\\nhttps://findforce.io/tools/gdpr-cold-email-checklist";

      navigator.clipboard.writeText(text).then(function onCopy() {
        var btn = document.getElementById("copy-results");
        btn.textContent = "Copied!";
        setTimeout(function resetBtn() {
          btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy Results';
        }, 2000);
      });
    };

    document.getElementById("restart-btn").onclick = function restart() {
      document.querySelectorAll('input[type="radio"]').forEach(function clearRadio(radio) {
        radio.checked = false;
        radio.closest(".option-btn").classList.remove("selected");
      });
      document.getElementById("results-section").style.display = "none";
      updateProgress();
      window.scrollTo({ top: 0, behavior: "smooth" });
    };

    if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
      window.pirsch("gdpr_checklist_completed", {
        meta: {
          compliance_score: score,
          yes_count: yes,
          no_count: no,
          unsure_count: unsure,
        },
      });
    }
  }

  function animateScore(elementId, targetValue) {
    var element = document.getElementById(elementId);
    var current = 0;
    var increment = targetValue / 30;
    var interval = setInterval(function updateScore() {
      current += increment;
      if (current >= targetValue) {
        current = targetValue;
        clearInterval(interval);
      }
      element.textContent = Math.round(current);
    }, 20);
  }

  document.addEventListener("DOMContentLoaded", function initChecklist() {
    document.querySelectorAll('input[type="radio"]').forEach(function setupRadio(radio) {
      radio.addEventListener("change", function handleChange() {
        var name = radio.name;
        document.querySelectorAll('input[name="' + name + '"]').forEach(function updateBtn(r) {
          r.closest(".option-btn").classList.remove("selected");
        });
        radio.closest(".option-btn").classList.add("selected");
        updateProgress();
      });
    });

    document.getElementById("calculate-btn").addEventListener("click", calculateCompliance);

    document.getElementById("total-count").textContent = totalQuestions;
  });
<\/script> `])), renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": pageTitle, "description": pageDescription, "canonical": "https://findforce.io/tools/gdpr-cold-email-checklist", "structuredData": structuredData, "data-astro-cid-qmnojfpz": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="checklist-page" data-astro-cid-qmnojfpz> <div class="container" data-astro-cid-qmnojfpz> <header class="header" data-astro-cid-qmnojfpz> ${renderComponent($$result2, "Logo", $$Logo, { "size": "lg", "data-astro-cid-qmnojfpz": true })} <h1 data-astro-cid-qmnojfpz>GDPR Cold Email Compliance Checklist</h1> <p class="subtitle" data-astro-cid-qmnojfpz>
Answer 12 questions to check if your B2B cold outreach is GDPR
          compliant. Get instant feedback with prioritized action items.
</p> </header> <div class="checklist-wrapper" data-astro-cid-qmnojfpz> <div class="progress-indicator" data-astro-cid-qmnojfpz> <div class="progress-text" data-astro-cid-qmnojfpz> <span id="answered-count" data-astro-cid-qmnojfpz>0</span> of <span id="total-count" data-astro-cid-qmnojfpz>12</span> answered
</div> <div class="progress-bar" data-astro-cid-qmnojfpz> <div class="progress-fill" id="progress-fill" data-astro-cid-qmnojfpz></div> </div> </div> <form id="checklist-form" data-astro-cid-qmnojfpz> <div class="checklist-section" data-astro-cid-qmnojfpz> <h2 class="section-title" data-astro-cid-qmnojfpz>Legal Basis</h2> <div class="checklist-item" data-category="critical" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>1</span> <span class="item-question" data-astro-cid-qmnojfpz>Do you have a documented Legitimate Interest Assessment (LIA) for your cold email activities?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q1" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q1" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q1" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> Under GDPR Article 6(1)(f), B2B cold outreach requires documented legitimate interest. Without an LIA, each email could be a violation.
</div> </div> <div class="checklist-item" data-category="critical" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>2</span> <span class="item-question" data-astro-cid-qmnojfpz>Do you only contact prospects with a clear business relevance to your offering?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q2" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q2" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q2" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> Random prospecting fails the legitimate interest test. You must demonstrate why each contact would reasonably expect to hear from you.
</div> </div> </div> <div class="checklist-section" data-astro-cid-qmnojfpz> <h2 class="section-title" data-astro-cid-qmnojfpz>Data Sources</h2> <div class="checklist-item" data-category="high" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>3</span> <span class="item-question" data-astro-cid-qmnojfpz>Can you document the source of every email address in your prospect list?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q3" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q3" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q3" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> GDPR Article 14 requires you to inform prospects where you obtained their data. Undocumented sources are compliance risks.
</div> </div> <div class="checklist-item" data-category="critical" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>4</span> <span class="item-question" data-astro-cid-qmnojfpz>Do you avoid using purchased email lists or scraped data?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q4" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q4" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q4" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> Purchased lists and scraped data rarely have valid consent chains. Using them exposes you to significant fine risk.
</div> </div> </div> <div class="checklist-section" data-astro-cid-qmnojfpz> <h2 class="section-title" data-astro-cid-qmnojfpz>Email Content & Process</h2> <div class="checklist-item" data-category="high" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>5</span> <span class="item-question" data-astro-cid-qmnojfpz>Does every cold email include a clear, working opt-out mechanism?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q5" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q5" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q5" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> One-click unsubscribe is required. Making opt-out difficult (requiring email replies, multiple clicks) violates GDPR.
</div> </div> <div class="checklist-item" data-category="medium" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>6</span> <span class="item-question" data-astro-cid-qmnojfpz>Do you honor opt-out requests within 24 hours?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q6" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q6" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q6" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> Continued emails after opt-out are clear violations. Automating this process protects you.
</div> </div> <div class="checklist-item" data-category="medium" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>7</span> <span class="item-question" data-astro-cid-qmnojfpz>Do your emails clearly identify your company and provide contact information?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q7" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q7" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q7" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> Transparency is a core GDPR principle. Anonymous or misleading emails are non-compliant.
</div> </div> </div> <div class="checklist-section" data-astro-cid-qmnojfpz> <h2 class="section-title" data-astro-cid-qmnojfpz>Data Management</h2> <div class="checklist-item" data-category="high" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>8</span> <span class="item-question" data-astro-cid-qmnojfpz>Do you have a data retention policy that deletes prospect data after a defined period?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q8" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q8" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q8" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> GDPR requires data minimization. Keeping prospect data indefinitely violates this principle. 90 days is a common standard.
</div> </div> <div class="checklist-item" data-category="medium" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>9</span> <span class="item-question" data-astro-cid-qmnojfpz>Can you fulfill a data subject access request (DSAR) within 30 days?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q9" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q9" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q9" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> Prospects can request all data you hold on them. Having a process ready is required.
</div> </div> </div> <div class="checklist-section" data-astro-cid-qmnojfpz> <h2 class="section-title" data-astro-cid-qmnojfpz>Vendor & Tool Compliance</h2> <div class="checklist-item" data-category="high" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>10</span> <span class="item-question" data-astro-cid-qmnojfpz>Do you have Data Processing Agreements (DPAs) with all email tools and data providers?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q10" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q10" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q10" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> GDPR Article 28 requires written agreements with any vendor processing personal data on your behalf.
</div> </div> <div class="checklist-item" data-category="medium" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>11</span> <span class="item-question" data-astro-cid-qmnojfpz>Do you verify that your tools store data in GDPR-compliant jurisdictions (EU/EEA or adequate countries)?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q11" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q11" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q11" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> Data transfers outside the EU require additional safeguards. US-based tools need Standard Contractual Clauses.
</div> </div> </div> <div class="checklist-section" data-astro-cid-qmnojfpz> <h2 class="section-title" data-astro-cid-qmnojfpz>Training & Awareness</h2> <div class="checklist-item" data-category="medium" data-astro-cid-qmnojfpz> <div class="item-header" data-astro-cid-qmnojfpz> <span class="item-number" data-astro-cid-qmnojfpz>12</span> <span class="item-question" data-astro-cid-qmnojfpz>Has your sales team received GDPR training specific to cold outreach?</span> </div> <div class="item-options" data-astro-cid-qmnojfpz> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q12" value="yes" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Yes</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q12" value="no" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>No</span> </label> <label class="option-btn" data-astro-cid-qmnojfpz> <input type="radio" name="q12" value="unsure" data-astro-cid-qmnojfpz> <span data-astro-cid-qmnojfpz>Not sure</span> </label> </div> <div class="item-info" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Why it matters:</strong> Human error causes most breaches. Regular training reduces risk and demonstrates compliance effort.
</div> </div> </div> <button type="button" id="calculate-btn" class="calculate-btn" data-astro-cid-qmnojfpz>
Check My Compliance Status
</button> </form> <div class="results-section" id="results-section" style="display: none;" data-astro-cid-qmnojfpz> <div class="compliance-badge" id="compliance-badge" data-astro-cid-qmnojfpz> <div class="badge-icon" id="badge-icon" data-astro-cid-qmnojfpz></div> <div class="badge-status" id="badge-status" data-astro-cid-qmnojfpz>Checking...</div> <div class="badge-score" data-astro-cid-qmnojfpz> <span id="compliance-score" data-astro-cid-qmnojfpz>0</span>% Compliant
</div> </div> <div class="score-breakdown" data-astro-cid-qmnojfpz> <div class="breakdown-item" data-astro-cid-qmnojfpz> <span class="breakdown-label" data-astro-cid-qmnojfpz>Compliant</span> <span class="breakdown-value compliant" id="yes-count" data-astro-cid-qmnojfpz>0</span> </div> <div class="breakdown-item" data-astro-cid-qmnojfpz> <span class="breakdown-label" data-astro-cid-qmnojfpz>Non-Compliant</span> <span class="breakdown-value non-compliant" id="no-count" data-astro-cid-qmnojfpz>0</span> </div> <div class="breakdown-item" data-astro-cid-qmnojfpz> <span class="breakdown-label" data-astro-cid-qmnojfpz>Uncertain</span> <span class="breakdown-value uncertain" id="unsure-count" data-astro-cid-qmnojfpz>0</span> </div> </div> <div class="action-items" id="action-items" data-astro-cid-qmnojfpz> <h3 data-astro-cid-qmnojfpz>Priority Action Items</h3> <div id="action-list" data-astro-cid-qmnojfpz></div> </div> <div class="share-section" data-astro-cid-qmnojfpz> <button id="copy-results" class="share-btn" data-astro-cid-qmnojfpz> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-qmnojfpz> <rect width="14" height="14" x="8" y="8" rx="2" ry="2" data-astro-cid-qmnojfpz></rect> <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" data-astro-cid-qmnojfpz></path> </svg>
Copy Results
</button> <button id="restart-btn" class="restart-btn" data-astro-cid-qmnojfpz>
Start Over
</button> </div> </div> </div> <div class="disclaimer" data-astro-cid-qmnojfpz> <strong data-astro-cid-qmnojfpz>Disclaimer:</strong> This checklist provides general guidance only and does not constitute legal advice. Consult with a qualified legal professional for specific compliance requirements.
</div> ${renderComponent($$result2, "Newsletter", $$Newsletter, { "title": "Get GDPR updates before they affect your sales team", "subtitle": "Join 2,000+ EU sales professionals staying ahead of compliance changes.", "source": "gdpr_checklist", "variant": "gdpr_checklist", "colorScheme": "green", "data-astro-cid-qmnojfpz": true })} <div class="cta-section" data-astro-cid-qmnojfpz> <h3 data-astro-cid-qmnojfpz>Use GDPR-compliant email verification</h3> <p data-astro-cid-qmnojfpz>
FindForce is built in the EU, hosted in the EU, with DPA ready on day
          one. 95% accuracy guarantee at €49/month flat.
</p> <a href="https://findforce.io?utm_source=tools&utm_medium=gdpr_checklist" class="cta-button" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="gdpr_checklist" data-astro-cid-qmnojfpz>
Start Free Trial
</a> </div> <div class="back-link" data-astro-cid-qmnojfpz> <a href="/tools" data-astro-cid-qmnojfpz>← Back to all tools</a> </div> </div> </section> ` }));
}, "/home/runner/work/landing-page/landing-page/src/pages/tools/gdpr-cold-email-checklist.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/tools/gdpr-cold-email-checklist.astro";
const $$url = "/tools/gdpr-cold-email-checklist.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$GdprColdEmailChecklist,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
