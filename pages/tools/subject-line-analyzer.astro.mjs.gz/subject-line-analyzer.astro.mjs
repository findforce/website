import { a as createComponent, d as renderTemplate, r as renderComponent, m as maybeRenderHead } from "../../js/astro/server.CiUvenb_.js";
import "kleur/colors";
import { $ as $$BaseLayout, a as $$Logo } from "../../js/BaseLayout.DZxjPdiE.js";
import { $ as $$Newsletter } from "../../js/Newsletter.C7Q9rGOC.js";
/* empty css                                               */
import { renderers } from "../../renderers.mjs";
var __freeze = Object.freeze;
var __defProp = Object.defineProperty;
var __template = (cooked, raw) => __freeze(__defProp(cooked, "raw", { value: __freeze(raw || cooked.slice()) }));
var _a;
const $$SubjectLineAnalyzer = createComponent(($$result, $$props, $$slots) => {
  var pageTitle = "Cold Email Subject Line Analyzer - Free Spam Check Tool";
  var pageDescription = "Check your cold email subject line for spam triggers and engagement signals. Get instant feedback on deliverability and open rate potential. Free, no signup.";
  var structuredData = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: "Cold Email Subject Line Analyzer",
    description: pageDescription,
    url: "https://findforce.io/tools/subject-line-analyzer",
    applicationCategory: "BusinessApplication",
    offers: {
      "@type": "Offer",
      price: "0",
      priceCurrency: "EUR"
    },
    creator: {
      "@type": "Organization",
      name: "FindForce",
      url: "https://findforce.io"
    }
  };
  return renderTemplate(_a || (_a = __template(["", ` <script>
  var spamTriggerWords = [
    "free", "act now", "limited time", "urgent", "winner", "congratulations",
    "click here", "buy now", "order now", "subscribe", "unsubscribe",
    "earn money", "make money", "cash", "credit", "loan", "discount",
    "save big", "best price", "cheap", "bargain", "deal", "offer",
    "guarantee", "no obligation", "risk free", "100%", "double your",
    "million", "billion", "lottery", "prize", "reward", "bonus",
    "gift", "amazing", "incredible", "miracle", "revolutionary",
    "breakthrough", "secret", "exclusive", "vip", "special promotion"
  ];

  var powerWords = [
    "you", "your", "quick", "question", "idea", "thought", "insight",
    "strategy", "results", "proven", "research", "data", "case study",
    "opportunity", "partnership", "collaboration", "intro", "connection"
  ];

  function analyzeSubjectLine() {
    var input = document.getElementById("subject-line");
    var subjectLine = input.value.trim();

    if (!subjectLine) {
      alert("Please enter a subject line to analyze");
      return;
    }

    var deliverabilityScore = 100;
    var engagementScore = 50;
    var analysisItems = [];
    var suggestions = [];

    var length = subjectLine.length;
    if (length < 20) {
      deliverabilityScore -= 5;
      engagementScore -= 10;
      analysisItems.push({
        type: "warning",
        text: "Too short (" + length + " chars). Aim for 30-50 characters.",
      });
      suggestions.push("Add more context to reach 30-50 characters for optimal open rates.");
    } else if (length >= 20 && length <= 50) {
      engagementScore += 15;
      analysisItems.push({
        type: "success",
        text: "Good length (" + length + " chars). Optimal range is 30-50.",
      });
    } else if (length > 50 && length <= 70) {
      engagementScore += 5;
      analysisItems.push({
        type: "info",
        text: "Slightly long (" + length + " chars). May get truncated on mobile.",
      });
    } else {
      engagementScore -= 10;
      analysisItems.push({
        type: "warning",
        text: "Too long (" + length + " chars). Will be truncated on most devices.",
      });
      suggestions.push("Shorten to under 50 characters to avoid truncation on mobile.");
    }

    var lowerSubject = subjectLine.toLowerCase();
    var foundSpamWords = [];
    spamTriggerWords.forEach(function checkSpam(word) {
      if (lowerSubject.includes(word.toLowerCase())) {
        foundSpamWords.push(word);
      }
    });

    if (foundSpamWords.length > 0) {
      deliverabilityScore -= foundSpamWords.length * 15;
      analysisItems.push({
        type: "error",
        text: "Spam triggers found: " + foundSpamWords.join(", "),
      });
      suggestions.push("Remove or replace spam trigger words: " + foundSpamWords.slice(0, 3).join(", "));
    } else {
      analysisItems.push({
        type: "success",
        text: "No spam trigger words detected.",
      });
    }

    var capsRatio = (subjectLine.match(/[A-Z]/g) || []).length / subjectLine.length;
    if (capsRatio > 0.5) {
      deliverabilityScore -= 25;
      engagementScore -= 15;
      analysisItems.push({
        type: "error",
        text: "Too many capital letters (" + Math.round(capsRatio * 100) + "%). Looks like shouting.",
      });
      suggestions.push("Use sentence case instead of ALL CAPS.");
    } else if (capsRatio > 0.3) {
      deliverabilityScore -= 10;
      analysisItems.push({
        type: "warning",
        text: "High capital letter ratio (" + Math.round(capsRatio * 100) + "%). Consider reducing.",
      });
    }

    var exclamationCount = (subjectLine.match(/!/g) || []).length;
    if (exclamationCount > 1) {
      deliverabilityScore -= exclamationCount * 10;
      analysisItems.push({
        type: "error",
        text: exclamationCount + " exclamation marks. Major spam signal.",
      });
      suggestions.push("Remove extra exclamation marks. Use at most one, or none.");
    } else if (exclamationCount === 1) {
      deliverabilityScore -= 5;
      analysisItems.push({
        type: "warning",
        text: "Contains exclamation mark. Use sparingly in cold emails.",
      });
    }

    var hasPersonalization = /\\{\\{.*?\\}\\}|\\[.*?\\]|%.*?%/.test(subjectLine);
    if (hasPersonalization) {
      engagementScore += 20;
      analysisItems.push({
        type: "success",
        text: "Contains personalization tokens. Great for engagement!",
      });
    } else {
      suggestions.push("Add personalization like {{first_name}} or {{company}} to boost opens.");
    }

    var hasQuestion = subjectLine.includes("?");
    if (hasQuestion) {
      engagementScore += 10;
      analysisItems.push({
        type: "success",
        text: "Question format increases curiosity and open rates.",
      });
    }

    var hasNumber = /\\d/.test(subjectLine);
    if (hasNumber) {
      engagementScore += 5;
      analysisItems.push({
        type: "info",
        text: "Contains numbers. Can increase specificity and trust.",
      });
    }

    var foundPowerWords = [];
    powerWords.forEach(function checkPower(word) {
      if (lowerSubject.includes(word.toLowerCase())) {
        foundPowerWords.push(word);
      }
    });

    if (foundPowerWords.length > 0) {
      engagementScore += Math.min(foundPowerWords.length * 5, 15);
      analysisItems.push({
        type: "success",
        text: "Power words found: " + foundPowerWords.slice(0, 3).join(", "),
      });
    }

    var wordCount = subjectLine.split(/\\s+/).length;
    if (wordCount >= 4 && wordCount <= 9) {
      analysisItems.push({
        type: "success",
        text: wordCount + " words is optimal for readability.",
      });
    } else if (wordCount < 4) {
      analysisItems.push({
        type: "info",
        text: "Only " + wordCount + " words. Consider adding more context.",
      });
    } else {
      analysisItems.push({
        type: "info",
        text: wordCount + " words is a bit wordy. Consider trimming.",
      });
    }

    deliverabilityScore = Math.max(0, Math.min(100, deliverabilityScore));
    engagementScore = Math.max(0, Math.min(100, engagementScore));

    displayResults(deliverabilityScore, engagementScore, analysisItems, suggestions, subjectLine);
  }

  function displayResults(deliverability, engagement, items, suggestions, subjectLine) {
    var resultsSection = document.getElementById("results-section");
    resultsSection.style.display = "block";

    animateScore("deliverability-score", deliverability);
    animateScore("engagement-score", engagement);

    var deliverabilityFill = document.getElementById("deliverability-fill");
    var engagementFill = document.getElementById("engagement-fill");

    setTimeout(function animateFills() {
      deliverabilityFill.style.width = deliverability + "%";
      deliverabilityFill.className = "score-fill " + getScoreClass(deliverability);

      engagementFill.style.width = engagement + "%";
      engagementFill.className = "score-fill " + getScoreClass(engagement);
    }, 100);

    document.getElementById("deliverability-hint").textContent = getScoreHint(deliverability, "deliverability");
    document.getElementById("engagement-hint").textContent = getScoreHint(engagement, "engagement");

    var analysisContainer = document.getElementById("analysis-items");
    analysisContainer.innerHTML = items.map(function renderItem(item) {
      var icon = item.type === "success" ? "✓" : item.type === "error" ? "✗" : item.type === "warning" ? "⚠" : "ℹ";
      return '<div class="analysis-item ' + item.type + '"><span class="item-icon">' + icon + '</span><span>' + item.text + '</span></div>';
    }).join("");

    var suggestionsSection = document.getElementById("suggestions-section");
    var suggestionsList = document.getElementById("suggestions-list");

    if (suggestions.length > 0) {
      suggestionsSection.style.display = "block";
      suggestionsList.innerHTML = suggestions.map(function renderSuggestion(s) {
        return '<div class="suggestion-item"><span class="suggestion-icon">→</span><span>' + s + '</span></div>';
      }).join("");
    } else {
      suggestionsSection.style.display = "none";
    }

    resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });

    document.getElementById("copy-results").onclick = function copyResults() {
      var text = "Subject Line: " + subjectLine + "\\n";
      text += "Deliverability Score: " + deliverability + "/100\\n";
      text += "Engagement Score: " + engagement + "/100\\n";
      text += "\\nAnalyzed with FindForce Subject Line Analyzer\\nhttps://findforce.io/tools/subject-line-analyzer";

      navigator.clipboard.writeText(text).then(function onCopy() {
        var btn = document.getElementById("copy-results");
        btn.textContent = "Copied!";
        setTimeout(function resetBtn() {
          btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy Results';
        }, 2000);
      }).catch(function onCopyError(err) {
        var btn = document.getElementById("copy-results");
        btn.textContent = "Copy failed";
        setTimeout(function resetBtn() {
          btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy Results';
        }, 2000);
      });
    };

    if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
      window.pirsch("subject_line_analyzed", {
        meta: {
          deliverability_score: deliverability,
          engagement_score: engagement,
          subject_length: subjectLine.length,
        },
      });
    }
  }

  function animateScore(elementId, targetValue) {
    var element = document.getElementById(elementId);
    var current = 0;
    var increment = targetValue / 30;
    var interval = setInterval(function updateScore() {
      current += increment;
      if (current >= targetValue) {
        current = targetValue;
        clearInterval(interval);
      }
      element.textContent = Math.round(current);
    }, 20);
  }

  function getScoreClass(score) {
    if (score >= 80) return "score-high";
    if (score >= 50) return "score-medium";
    return "score-low";
  }

  function getScoreHint(score, type) {
    if (type === "deliverability") {
      if (score >= 80) return "Excellent! Low spam risk.";
      if (score >= 50) return "Good, but room for improvement.";
      return "High spam risk. Review suggestions.";
    } else {
      if (score >= 80) return "High open rate potential!";
      if (score >= 50) return "Average engagement expected.";
      return "Low engagement likely. Add hooks.";
    }
  }

  document.addEventListener("DOMContentLoaded", function initAnalyzer() {
    var input = document.getElementById("subject-line");
    var charCount = document.getElementById("char-count");
    var analyzeBtn = document.getElementById("analyze-btn");

    input.addEventListener("input", function updateCount() {
      charCount.textContent = input.value.length;
    });

    input.addEventListener("keypress", function handleEnter(e) {
      if (e.key === "Enter") {
        analyzeSubjectLine();
      }
    });

    analyzeBtn.addEventListener("click", analyzeSubjectLine);

    document.querySelectorAll(".example-btn").forEach(function setupExample(btn) {
      btn.addEventListener("click", function useExample() {
        input.value = btn.dataset.example;
        charCount.textContent = input.value.length;
        analyzeSubjectLine();
      });
    });
  });
<\/script> `], ["", ` <script>
  var spamTriggerWords = [
    "free", "act now", "limited time", "urgent", "winner", "congratulations",
    "click here", "buy now", "order now", "subscribe", "unsubscribe",
    "earn money", "make money", "cash", "credit", "loan", "discount",
    "save big", "best price", "cheap", "bargain", "deal", "offer",
    "guarantee", "no obligation", "risk free", "100%", "double your",
    "million", "billion", "lottery", "prize", "reward", "bonus",
    "gift", "amazing", "incredible", "miracle", "revolutionary",
    "breakthrough", "secret", "exclusive", "vip", "special promotion"
  ];

  var powerWords = [
    "you", "your", "quick", "question", "idea", "thought", "insight",
    "strategy", "results", "proven", "research", "data", "case study",
    "opportunity", "partnership", "collaboration", "intro", "connection"
  ];

  function analyzeSubjectLine() {
    var input = document.getElementById("subject-line");
    var subjectLine = input.value.trim();

    if (!subjectLine) {
      alert("Please enter a subject line to analyze");
      return;
    }

    var deliverabilityScore = 100;
    var engagementScore = 50;
    var analysisItems = [];
    var suggestions = [];

    var length = subjectLine.length;
    if (length < 20) {
      deliverabilityScore -= 5;
      engagementScore -= 10;
      analysisItems.push({
        type: "warning",
        text: "Too short (" + length + " chars). Aim for 30-50 characters.",
      });
      suggestions.push("Add more context to reach 30-50 characters for optimal open rates.");
    } else if (length >= 20 && length <= 50) {
      engagementScore += 15;
      analysisItems.push({
        type: "success",
        text: "Good length (" + length + " chars). Optimal range is 30-50.",
      });
    } else if (length > 50 && length <= 70) {
      engagementScore += 5;
      analysisItems.push({
        type: "info",
        text: "Slightly long (" + length + " chars). May get truncated on mobile.",
      });
    } else {
      engagementScore -= 10;
      analysisItems.push({
        type: "warning",
        text: "Too long (" + length + " chars). Will be truncated on most devices.",
      });
      suggestions.push("Shorten to under 50 characters to avoid truncation on mobile.");
    }

    var lowerSubject = subjectLine.toLowerCase();
    var foundSpamWords = [];
    spamTriggerWords.forEach(function checkSpam(word) {
      if (lowerSubject.includes(word.toLowerCase())) {
        foundSpamWords.push(word);
      }
    });

    if (foundSpamWords.length > 0) {
      deliverabilityScore -= foundSpamWords.length * 15;
      analysisItems.push({
        type: "error",
        text: "Spam triggers found: " + foundSpamWords.join(", "),
      });
      suggestions.push("Remove or replace spam trigger words: " + foundSpamWords.slice(0, 3).join(", "));
    } else {
      analysisItems.push({
        type: "success",
        text: "No spam trigger words detected.",
      });
    }

    var capsRatio = (subjectLine.match(/[A-Z]/g) || []).length / subjectLine.length;
    if (capsRatio > 0.5) {
      deliverabilityScore -= 25;
      engagementScore -= 15;
      analysisItems.push({
        type: "error",
        text: "Too many capital letters (" + Math.round(capsRatio * 100) + "%). Looks like shouting.",
      });
      suggestions.push("Use sentence case instead of ALL CAPS.");
    } else if (capsRatio > 0.3) {
      deliverabilityScore -= 10;
      analysisItems.push({
        type: "warning",
        text: "High capital letter ratio (" + Math.round(capsRatio * 100) + "%). Consider reducing.",
      });
    }

    var exclamationCount = (subjectLine.match(/!/g) || []).length;
    if (exclamationCount > 1) {
      deliverabilityScore -= exclamationCount * 10;
      analysisItems.push({
        type: "error",
        text: exclamationCount + " exclamation marks. Major spam signal.",
      });
      suggestions.push("Remove extra exclamation marks. Use at most one, or none.");
    } else if (exclamationCount === 1) {
      deliverabilityScore -= 5;
      analysisItems.push({
        type: "warning",
        text: "Contains exclamation mark. Use sparingly in cold emails.",
      });
    }

    var hasPersonalization = /\\\\{\\\\{.*?\\\\}\\\\}|\\\\[.*?\\\\]|%.*?%/.test(subjectLine);
    if (hasPersonalization) {
      engagementScore += 20;
      analysisItems.push({
        type: "success",
        text: "Contains personalization tokens. Great for engagement!",
      });
    } else {
      suggestions.push("Add personalization like {{first_name}} or {{company}} to boost opens.");
    }

    var hasQuestion = subjectLine.includes("?");
    if (hasQuestion) {
      engagementScore += 10;
      analysisItems.push({
        type: "success",
        text: "Question format increases curiosity and open rates.",
      });
    }

    var hasNumber = /\\\\d/.test(subjectLine);
    if (hasNumber) {
      engagementScore += 5;
      analysisItems.push({
        type: "info",
        text: "Contains numbers. Can increase specificity and trust.",
      });
    }

    var foundPowerWords = [];
    powerWords.forEach(function checkPower(word) {
      if (lowerSubject.includes(word.toLowerCase())) {
        foundPowerWords.push(word);
      }
    });

    if (foundPowerWords.length > 0) {
      engagementScore += Math.min(foundPowerWords.length * 5, 15);
      analysisItems.push({
        type: "success",
        text: "Power words found: " + foundPowerWords.slice(0, 3).join(", "),
      });
    }

    var wordCount = subjectLine.split(/\\\\s+/).length;
    if (wordCount >= 4 && wordCount <= 9) {
      analysisItems.push({
        type: "success",
        text: wordCount + " words is optimal for readability.",
      });
    } else if (wordCount < 4) {
      analysisItems.push({
        type: "info",
        text: "Only " + wordCount + " words. Consider adding more context.",
      });
    } else {
      analysisItems.push({
        type: "info",
        text: wordCount + " words is a bit wordy. Consider trimming.",
      });
    }

    deliverabilityScore = Math.max(0, Math.min(100, deliverabilityScore));
    engagementScore = Math.max(0, Math.min(100, engagementScore));

    displayResults(deliverabilityScore, engagementScore, analysisItems, suggestions, subjectLine);
  }

  function displayResults(deliverability, engagement, items, suggestions, subjectLine) {
    var resultsSection = document.getElementById("results-section");
    resultsSection.style.display = "block";

    animateScore("deliverability-score", deliverability);
    animateScore("engagement-score", engagement);

    var deliverabilityFill = document.getElementById("deliverability-fill");
    var engagementFill = document.getElementById("engagement-fill");

    setTimeout(function animateFills() {
      deliverabilityFill.style.width = deliverability + "%";
      deliverabilityFill.className = "score-fill " + getScoreClass(deliverability);

      engagementFill.style.width = engagement + "%";
      engagementFill.className = "score-fill " + getScoreClass(engagement);
    }, 100);

    document.getElementById("deliverability-hint").textContent = getScoreHint(deliverability, "deliverability");
    document.getElementById("engagement-hint").textContent = getScoreHint(engagement, "engagement");

    var analysisContainer = document.getElementById("analysis-items");
    analysisContainer.innerHTML = items.map(function renderItem(item) {
      var icon = item.type === "success" ? "✓" : item.type === "error" ? "✗" : item.type === "warning" ? "⚠" : "ℹ";
      return '<div class="analysis-item ' + item.type + '"><span class="item-icon">' + icon + '</span><span>' + item.text + '</span></div>';
    }).join("");

    var suggestionsSection = document.getElementById("suggestions-section");
    var suggestionsList = document.getElementById("suggestions-list");

    if (suggestions.length > 0) {
      suggestionsSection.style.display = "block";
      suggestionsList.innerHTML = suggestions.map(function renderSuggestion(s) {
        return '<div class="suggestion-item"><span class="suggestion-icon">→</span><span>' + s + '</span></div>';
      }).join("");
    } else {
      suggestionsSection.style.display = "none";
    }

    resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });

    document.getElementById("copy-results").onclick = function copyResults() {
      var text = "Subject Line: " + subjectLine + "\\\\n";
      text += "Deliverability Score: " + deliverability + "/100\\\\n";
      text += "Engagement Score: " + engagement + "/100\\\\n";
      text += "\\\\nAnalyzed with FindForce Subject Line Analyzer\\\\nhttps://findforce.io/tools/subject-line-analyzer";

      navigator.clipboard.writeText(text).then(function onCopy() {
        var btn = document.getElementById("copy-results");
        btn.textContent = "Copied!";
        setTimeout(function resetBtn() {
          btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy Results';
        }, 2000);
      }).catch(function onCopyError(err) {
        var btn = document.getElementById("copy-results");
        btn.textContent = "Copy failed";
        setTimeout(function resetBtn() {
          btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg> Copy Results';
        }, 2000);
      });
    };

    if (typeof window !== "undefined" && typeof window.pirsch !== "undefined") {
      window.pirsch("subject_line_analyzed", {
        meta: {
          deliverability_score: deliverability,
          engagement_score: engagement,
          subject_length: subjectLine.length,
        },
      });
    }
  }

  function animateScore(elementId, targetValue) {
    var element = document.getElementById(elementId);
    var current = 0;
    var increment = targetValue / 30;
    var interval = setInterval(function updateScore() {
      current += increment;
      if (current >= targetValue) {
        current = targetValue;
        clearInterval(interval);
      }
      element.textContent = Math.round(current);
    }, 20);
  }

  function getScoreClass(score) {
    if (score >= 80) return "score-high";
    if (score >= 50) return "score-medium";
    return "score-low";
  }

  function getScoreHint(score, type) {
    if (type === "deliverability") {
      if (score >= 80) return "Excellent! Low spam risk.";
      if (score >= 50) return "Good, but room for improvement.";
      return "High spam risk. Review suggestions.";
    } else {
      if (score >= 80) return "High open rate potential!";
      if (score >= 50) return "Average engagement expected.";
      return "Low engagement likely. Add hooks.";
    }
  }

  document.addEventListener("DOMContentLoaded", function initAnalyzer() {
    var input = document.getElementById("subject-line");
    var charCount = document.getElementById("char-count");
    var analyzeBtn = document.getElementById("analyze-btn");

    input.addEventListener("input", function updateCount() {
      charCount.textContent = input.value.length;
    });

    input.addEventListener("keypress", function handleEnter(e) {
      if (e.key === "Enter") {
        analyzeSubjectLine();
      }
    });

    analyzeBtn.addEventListener("click", analyzeSubjectLine);

    document.querySelectorAll(".example-btn").forEach(function setupExample(btn) {
      btn.addEventListener("click", function useExample() {
        input.value = btn.dataset.example;
        charCount.textContent = input.value.length;
        analyzeSubjectLine();
      });
    });
  });
<\/script> `])), renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": pageTitle, "description": pageDescription, "canonical": "https://findforce.io/tools/subject-line-analyzer", "structuredData": structuredData, "data-astro-cid-ojty2eam": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="analyzer-page" data-astro-cid-ojty2eam> <div class="container" data-astro-cid-ojty2eam> <header class="header" data-astro-cid-ojty2eam> ${renderComponent($$result2, "Logo", $$Logo, { "size": "lg", "data-astro-cid-ojty2eam": true })} <h1 data-astro-cid-ojty2eam>Cold Email Subject Line Analyzer</h1> <p class="subtitle" data-astro-cid-ojty2eam>
Check for spam triggers and engagement signals. Get instant feedback
          on deliverability and open rate potential.
</p> </header> <div class="analyzer-wrapper" data-astro-cid-ojty2eam> <div class="input-section" data-astro-cid-ojty2eam> <div class="form-group" data-astro-cid-ojty2eam> <label for="subject-line" data-astro-cid-ojty2eam>Your Subject Line</label> <input type="text" id="subject-line" placeholder="e.g., Quick question about {{company}}'s sales process" maxlength="150" autocomplete="off" data-astro-cid-ojty2eam> <div class="char-count" data-astro-cid-ojty2eam> <span id="char-count" data-astro-cid-ojty2eam>0</span>/150 characters
</div> </div> <button id="analyze-btn" class="analyze-btn" data-astro-cid-ojty2eam>
Analyze Subject Line
</button> <div class="examples" data-astro-cid-ojty2eam> <p class="examples-label" data-astro-cid-ojty2eam>Try these examples:</p> <button class="example-btn" data-example="Quick question about your sales process" data-astro-cid-ojty2eam>Quick question about your sales process</button> <button class="example-btn" data-example="FREE OFFER!!! Act NOW before it's too late!!!" data-astro-cid-ojty2eam>FREE OFFER!!! Act NOW before it's too late!!!</button> <button class="example-btn" data-example="{{first_name}}, saw your post on LinkedIn" data-astro-cid-ojty2eam>${"{{first_name}}, saw your post on LinkedIn"}</button> </div> </div> <div class="results-section" id="results-section" style="display: none;" data-astro-cid-ojty2eam> <div class="scores-grid" data-astro-cid-ojty2eam> <div class="score-card deliverability" data-astro-cid-ojty2eam> <div class="score-label" data-astro-cid-ojty2eam>Deliverability Score</div> <div class="score-value" id="deliverability-score" data-astro-cid-ojty2eam>0</div> <div class="score-bar" data-astro-cid-ojty2eam> <div class="score-fill" id="deliverability-fill" data-astro-cid-ojty2eam></div> </div> <div class="score-hint" id="deliverability-hint" data-astro-cid-ojty2eam>Analyzing...</div> </div> <div class="score-card engagement" data-astro-cid-ojty2eam> <div class="score-label" data-astro-cid-ojty2eam>Engagement Score</div> <div class="score-value" id="engagement-score" data-astro-cid-ojty2eam>0</div> <div class="score-bar" data-astro-cid-ojty2eam> <div class="score-fill" id="engagement-fill" data-astro-cid-ojty2eam></div> </div> <div class="score-hint" id="engagement-hint" data-astro-cid-ojty2eam>Analyzing...</div> </div> </div> <div class="analysis-details" data-astro-cid-ojty2eam> <h3 data-astro-cid-ojty2eam>Analysis Details</h3> <div id="analysis-items" data-astro-cid-ojty2eam></div> </div> <div class="suggestions" id="suggestions-section" style="display: none;" data-astro-cid-ojty2eam> <h3 data-astro-cid-ojty2eam>Suggestions to Improve</h3> <div id="suggestions-list" data-astro-cid-ojty2eam></div> </div> <div class="share-section" data-astro-cid-ojty2eam> <button id="copy-results" class="share-btn" data-astro-cid-ojty2eam> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" data-astro-cid-ojty2eam> <rect width="14" height="14" x="8" y="8" rx="2" ry="2" data-astro-cid-ojty2eam></rect> <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" data-astro-cid-ojty2eam></path> </svg>
Copy Results
</button> </div> </div> </div> ${renderComponent($$result2, "Newsletter", $$Newsletter, { "title": "Get weekly high-converting subject line templates", "subtitle": "Join 2,000+ sales professionals getting weekly deliverability tips.", "source": "subject_line_analyzer", "variant": "subject_line_analyzer", "colorScheme": "blue", "data-astro-cid-ojty2eam": true })} <div class="cta-section" data-astro-cid-ojty2eam> <h3 data-astro-cid-ojty2eam>Verify your prospect emails get delivered</h3> <p data-astro-cid-ojty2eam>
95% accuracy guarantee with unlimited verifications at €49/month flat.
          Reduce bounces, protect your sender reputation.
</p> <a href="https://findforce.io?utm_source=tools&utm_medium=subject_line_analyzer" class="cta-button" data-pirsch-event="webstore_clicked" data-pirsch-meta-source="subject_line_analyzer" data-astro-cid-ojty2eam>
Start Free Trial
</a> </div> <div class="back-link" data-astro-cid-ojty2eam> <a href="/tools" data-astro-cid-ojty2eam>← Back to all tools</a> </div> </div> </section> ` }));
}, "/home/runner/work/landing-page/landing-page/src/pages/tools/subject-line-analyzer.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/tools/subject-line-analyzer.astro";
const $$url = "/tools/subject-line-analyzer.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$SubjectLineAnalyzer,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
