import { c as createAstro, a as createComponent, r as renderComponent, b as renderScript, d as renderTemplate, m as maybeRenderHead, e as addAttribute } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { $ as $$BaseLayout } from "../js/BaseLayout.Ci_Dh1rG.js";
/* empty css                                    */
import { renderers } from "../renderers.mjs";
const $$Astro = createAstro("https://findforce.io");
const $$UpgradeError = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$UpgradeError;
  var searchParams = Astro2.url.searchParams;
  var errorType = searchParams.get("error") || "unknown";
  var isFounder = searchParams.get("founder") === "true";
  var errorMessages = {
    timeout: {
      title: "Connection Timeout",
      message: "The upgrade process took longer than expected. This sometimes happens during high traffic.",
      action: "Try Again",
      icon: "clock"
    },
    expired: {
      title: "Founder Pricing Expired",
      message: "The founder pricing period has ended, but you can still upgrade at our standard rate.",
      action: "View Standard Pricing",
      icon: "alert"
    },
    unavailable: {
      title: "Founder Spots Filled",
      message: "All founder pricing spots have been claimed. Join our waitlist for the next opportunity.",
      action: "Join Waitlist",
      icon: "users"
    },
    payment: {
      title: "Payment Issue",
      message: "There was a problem processing your payment. Your card was not charged.",
      action: "Try Different Payment",
      icon: "card"
    },
    unknown: {
      title: "Something Went Wrong",
      message: "An unexpected error occurred. Our team has been notified and will investigate.",
      action: "Contact Support",
      icon: "warning"
    }
  };
  var currentError = errorMessages[errorType] || errorMessages.unknown;
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": currentError.title + " - FindForce Upgrade", "description": "Upgrade error - FindForce will help you resolve this issue", "canonical": "https://findforce.io/upgrade-error", "noindex": true, "data-astro-cid-wmalsup5": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="error-page" data-astro-cid-wmalsup5> <div class="container" data-astro-cid-wmalsup5> <div class="error-content" data-astro-cid-wmalsup5> <div class="error-icon"${addAttribute(currentError.icon, "data-icon")} data-astro-cid-wmalsup5> ${currentError.icon === "clock" && renderTemplate`<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-wmalsup5> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" data-astro-cid-wmalsup5></path> </svg>`} ${currentError.icon === "alert" && renderTemplate`<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-wmalsup5> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.732-.833-2.464 0L4.732 18.5c-.77.833.192 2.5 1.732 2.5z" data-astro-cid-wmalsup5></path> </svg>`} ${currentError.icon === "users" && renderTemplate`<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-wmalsup5> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" data-astro-cid-wmalsup5></path> </svg>`} ${currentError.icon === "card" && renderTemplate`<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-wmalsup5> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" data-astro-cid-wmalsup5></path> </svg>`} ${currentError.icon === "warning" && renderTemplate`<svg fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-wmalsup5> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" data-astro-cid-wmalsup5></path> </svg>`} </div> <h1 class="title" data-astro-cid-wmalsup5>${currentError.title}</h1> <p class="message" data-astro-cid-wmalsup5>${currentError.message}</p> <div class="action-buttons" data-astro-cid-wmalsup5> <button class="primary-button" id="primary-action" data-astro-cid-wmalsup5> ${currentError.action} </button> ${errorType !== "expired" && errorType !== "unavailable" && renderTemplate`<button class="secondary-button" id="retry-action" data-astro-cid-wmalsup5>
Try Again
</button>`} </div> ${errorType === "expired" && renderTemplate`<div class="alternative-offer" data-astro-cid-wmalsup5> <div class="offer-badge" data-astro-cid-wmalsup5> <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20" data-astro-cid-wmalsup5> <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" data-astro-cid-wmalsup5></path> </svg> <span data-astro-cid-wmalsup5>Still 50% off regular price</span> </div> <p class="offer-text" data-astro-cid-wmalsup5>You can still save significantly compared to other email finder tools.</p> </div>`} ${errorType === "unavailable" && renderTemplate`<div class="waitlist-benefits" data-astro-cid-wmalsup5> <h3 data-astro-cid-wmalsup5>Join the Waitlist and Get:</h3> <ul data-astro-cid-wmalsup5> <li data-astro-cid-wmalsup5> <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20" data-astro-cid-wmalsup5> <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" data-astro-cid-wmalsup5></path> </svg>
Priority access to future founder pricing
</li> <li data-astro-cid-wmalsup5> <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20" data-astro-cid-wmalsup5> <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" data-astro-cid-wmalsup5></path> </svg>
Exclusive product updates and features
</li> <li data-astro-cid-wmalsup5> <svg width="16" height="16" fill="currentColor" viewBox="0 0 20 20" data-astro-cid-wmalsup5> <path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd" data-astro-cid-wmalsup5></path> </svg>
Free premium features trial
</li> </ul> </div>`} <div class="support-options" data-astro-cid-wmalsup5> <h3 data-astro-cid-wmalsup5>Need Help?</h3> <div class="support-grid" data-astro-cid-wmalsup5> <a href="mailto:support@findforce.io" class="support-item" data-astro-cid-wmalsup5> <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-wmalsup5> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" data-astro-cid-wmalsup5></path> </svg> <div data-astro-cid-wmalsup5> <span class="support-title" data-astro-cid-wmalsup5>Email Support</span> <span class="support-desc" data-astro-cid-wmalsup5>Get help within 2 hours</span> </div> </a> <a href="https://findforce.io/" class="support-item" data-astro-cid-wmalsup5> <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24" data-astro-cid-wmalsup5> <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" data-astro-cid-wmalsup5></path> </svg> <div data-astro-cid-wmalsup5> <span class="support-title" data-astro-cid-wmalsup5>Documentation</span> <span class="support-desc" data-astro-cid-wmalsup5>Setup guides & FAQs</span> </div> </a> </div> </div> <div class="error-details" data-astro-cid-wmalsup5> <details data-astro-cid-wmalsup5> <summary data-astro-cid-wmalsup5>Technical Details</summary> <div class="tech-info" data-astro-cid-wmalsup5> <p data-astro-cid-wmalsup5><strong data-astro-cid-wmalsup5>Error Type:</strong> ${errorType}</p> <p data-astro-cid-wmalsup5><strong data-astro-cid-wmalsup5>Timestamp:</strong> <span id="timestamp" data-astro-cid-wmalsup5></span></p> <p data-astro-cid-wmalsup5><strong data-astro-cid-wmalsup5>Session ID:</strong> <span id="session-id" data-astro-cid-wmalsup5></span></p> ${isFounder && renderTemplate`<p data-astro-cid-wmalsup5><strong data-astro-cid-wmalsup5>Founder Request:</strong> Yes</p>`} </div> </details> </div> </div> </div> </section> ` })}  ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/upgrade-error.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/runner/work/landing-page/landing-page/src/pages/upgrade-error.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/upgrade-error.astro";
const $$url = "/upgrade-error.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$UpgradeError,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
