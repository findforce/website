import { a as createComponent, r as renderComponent, b as renderScript, d as renderTemplate, m as maybeRenderHead } from "../js/astro/server.CL5zRllf.js";
import "kleur/colors";
import { $ as $$BaseLayout } from "../js/BaseLayout.Ci_Dh1rG.js";
/* empty css                              */
import { renderers } from "../renderers.mjs";
const $$Welcome = createComponent(($$result, $$props, $$slots) => {
  return renderTemplate`${renderComponent($$result, "BaseLayout", $$BaseLayout, { "title": "Welcome to FindForce - Start Finding Verified Emails in 30 Seconds", "description": "Get started with FindForce Chrome extension. Verify B2B emails directly from LinkedIn with 95% accuracy. Quick setup guide for sales professionals.", "canonical": "https://findforce.io/welcome", "noindex": true, "data-astro-cid-232m4wxw": true }, { "default": ($$result2) => renderTemplate` ${maybeRenderHead()}<section class="welcome-page" data-astro-cid-232m4wxw> <div class="container" data-astro-cid-232m4wxw> <div class="logo" data-astro-cid-232m4wxw> <div class="logo-icon" data-astro-cid-232m4wxw>@</div> <div class="logo-text" data-astro-cid-232m4wxw>FindForce</div> </div> <h1 data-astro-cid-232m4wxw>You're 30 seconds away from verified emails</h1> <p class="subtitle" data-astro-cid-232m4wxw>
Let's get your first email verification done. No credit card needed
        during beta.
</p> <div class="steps" data-astro-cid-232m4wxw> <div class="step" id="step1" data-astro-cid-232m4wxw> <h2 data-astro-cid-232m4wxw>Go to any LinkedIn profile</h2> <p data-astro-cid-232m4wxw>Open LinkedIn and navigate to any prospect's profile page.</p> <div class="demo-box" data-astro-cid-232m4wxw> <p data-astro-cid-232m4wxw>✓ Works on: <code data-astro-cid-232m4wxw>linkedin.com/in/[anyone]</code></p> <p data-astro-cid-232m4wxw>✓ The FindForce icon should appear in your Chrome toolbar</p> </div> </div> <div class="step" id="step2" data-astro-cid-232m4wxw> <h2 data-astro-cid-232m4wxw>Click the FindForce extension icon</h2> <p data-astro-cid-232m4wxw>
Click the blue @ icon in your Chrome toolbar while on a LinkedIn
            profile.
</p> <div class="shortcuts" data-astro-cid-232m4wxw> <div class="shortcut" data-astro-cid-232m4wxw>
Shortcut: <kbd data-astro-cid-232m4wxw>Cmd</kbd>+<kbd data-astro-cid-232m4wxw>Shift</kbd>+<kbd data-astro-cid-232m4wxw>F</kbd> (Mac)
</div> <div class="shortcut" data-astro-cid-232m4wxw>
Shortcut: <kbd data-astro-cid-232m4wxw>Ctrl</kbd>+<kbd data-astro-cid-232m4wxw>Shift</kbd>+<kbd data-astro-cid-232m4wxw>F</kbd> (Windows)
</div> </div> <div class="warning" data-astro-cid-232m4wxw> <strong data-astro-cid-232m4wxw>Not seeing the icon?</strong> Pin it by clicking the puzzle
            piece in Chrome toolbar → Pin FindForce
</div> </div> <div class="step" id="step3" data-astro-cid-232m4wxw> <h2 data-astro-cid-232m4wxw>Get your verified email instantly</h2> <p data-astro-cid-232m4wxw>
FindForce will analyze and verify the email with our 95% accuracy
            guarantee.
</p> <div class="demo-box" data-astro-cid-232m4wxw> <div class="success-metric" data-astro-cid-232m4wxw>✓ 95% accuracy rate</div> <div class="success-metric" data-astro-cid-232m4wxw>✓ Real-time verification</div> <div class="success-metric" data-astro-cid-232m4wxw>✓ Confidence score included</div> </div> <a href="https://www.linkedin.com/in/williamhgates/" target="_blank" class="cta-button" data-astro-cid-232m4wxw>
Try it on Bill Gates' Profile →
</a> </div> </div> <div class="pro-tip" data-astro-cid-232m4wxw> <h3 data-astro-cid-232m4wxw>🎯 Pro Tip for Beta Users</h3> <p data-astro-cid-232m4wxw>
You have 25 free verifications during beta. After your first
          successful verification, try these power features:
</p> <ul data-astro-cid-232m4wxw> <li data-astro-cid-232m4wxw>Copy emails with one click</li> <li data-astro-cid-232m4wxw>Check confidence scores (%85-%99)</li> <li data-astro-cid-232m4wxw>Export to CSV for your CRM</li> </ul> </div> <div class="help-links" data-astro-cid-232m4wxw> <a href="https://findforce.zulipchat.com" data-astro-cid-232m4wxw>Help Center</a> <a href="mailto:support@findforce.io" data-astro-cid-232m4wxw>Email Support</a> <a href="/privacy" data-astro-cid-232m4wxw>Privacy Policy</a> </div> </div> </section> ` })} ${renderScript($$result, "/home/runner/work/landing-page/landing-page/src/pages/welcome.astro?astro&type=script&index=0&lang.ts")} `;
}, "/home/runner/work/landing-page/landing-page/src/pages/welcome.astro", void 0);
const $$file = "/home/runner/work/landing-page/landing-page/src/pages/welcome.astro";
const $$url = "/welcome.html";
const _page = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: $$Welcome,
  file: $$file,
  url: $$url
}, Symbol.toStringTag, { value: "Module" }));
const page = () => _page;
export {
  page,
  renderers
};
